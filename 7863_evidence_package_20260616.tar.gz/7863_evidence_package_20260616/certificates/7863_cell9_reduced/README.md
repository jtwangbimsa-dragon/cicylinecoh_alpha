# CICY 7863 Cell 9 reduced certificate package

Date: 2026-06-12.

This folder organizes the certificate material for the CICY 7863 Cell 9
endpoint computation for \(c=8,9,10\).  The current status is:

> Over the finite field \(\mathbb F_{1000003}\), for the deterministic
> specialization `mode=sparseL_denseQ`, `seed=7863`, the reduced endpoint
> complex verifies the predicted numerator for \(c=8,9,10\).  Shifted degree
> \(4\) has zero Koszul homology in all three cases.  This is a degree-4 tail
> check, not by itself a proof that no later higher-degree tail can occur.

The proof package is computational: it records the source hash, the
specialization, the reduced module dimensions, the ranks, the Koszul homology,
and the JSON artifacts that reproduce each check.  For a publication-grade
generic characteristic-zero theorem, the remaining work includes an all-degree
regularity/no-tail propagation argument, in addition to the usual
characteristic-zero packaging of the rank computations.

For the detailed explanation of how the endpoint Hilbert numerator is computed
from the three q-rank matrices \(q_2,q_3,q_4\), see
`../7863_cell9_strict_replay/README.md`.

## Endpoint statement

For \(a=-m-4\), \(b=c\), Cell 9 uses endpoint

\[
s=6c-4.
\]

The conjectural endpoint numerator is

\[
n_c(t)=A_c t^s-B_c t^{s+1}+C_c t^{s+2}-G_c t^{s+3},
\]

where

\[
A_c=\frac{c(c^2+11)}3,\qquad
B_c=c^3-3c^2+8c-4,\qquad
C_c=(c-1)(c-2)(c-3),\qquad
G_c=\frac{(c-6)(c-2)(c-1)}3.
\]

The verified cases are:

| \(c\) | \(s\) | verified numerator |
|---:|---:|---|
| 8 | 44 | \(200t^{44}-380t^{45}+210t^{46}-28t^{47}\) |
| 9 | 50 | \(276t^{50}-554t^{51}+336t^{52}-56t^{53}\) |
| 10 | 56 | \(370t^{56}-776t^{57}+504t^{58}-96t^{59}\) |

## Reduced construction being certified

The calculation replaces the large ambient quotient by the rank-two quotient
\(\mathcal E\)

\[
0\to \mathcal O(-1)^2\xrightarrow{(L_1,L_2)}\mathcal O^4\to\mathcal E\to0.
\]

Write

\[
B(n,t)=H^0(\operatorname{Sym}^n\mathcal E(t)).
\]

After descending \(Q\) to

\[
q\in H^0(\operatorname{Sym}^2\mathcal E(2)),
\]

the shifted endpoint modules are

\[
M_d=N_c(s+d).
\]

For \(d=2,3,4\), the certificate uses

\[
M_d=\operatorname{coker}\left(q_d:B(c-2,d-2)\to B(c,d)\right),
\]

and verifies that each \(q_d\) has full column rank.  The \(d=1\) term is

\[
M_1=B(c,1).
\]

The \(d=0\) term has the extra top cohomology correction

\[
M_0=B(c,0)\oplus H^1(\operatorname{Sym}^{c-2}\mathcal E(-2)).
\]

That correction is not inserted as a raw vector.  It is closed as a total
degree-one Cech/cone cocycle first, and then the products \(q a\) and \(x_j a\)
are solved as total boundaries.  This is the key fix that made the \(M_0\)
square commute.

Finally the four coordinate multiplications build the reduced Koszul complex
through shifted degree \(4\).  The numerator coefficients are the Euler
coefficients of this Koszul homology.

## Core finite-field results

All computations below use \(p=1000003\), `mode=sparseL_denseQ`, `seed=7863`,
`sparse_l_terms=8`, and `sparse_q_terms=20`.

### c=8

- \(M_0,\ldots,M_4=(200,420,690,1012,1388)\).
- \(q_d\) ranks for \(d=2,3,4\): \(84/84,\ 224/224,\ 427/427\).
- \(M_0=165+35\), with the top correction included.
- Koszul homology:
  - degree 1: \(H_1=380\).
  - degree 2: \(H_1=4,\ H_2=214\).
  - degree 3: \(H_2=4,\ H_3=32\).
  - degree 4: all zero.
- Euler coefficients: \(-380,\ 210,\ -28,\ 0\).

### c=9

- \(M_0,\ldots,M_4=(276,550,880,1268,1716)\).
- \(q_d\) ranks for \(d=2,3,4\): \(120/120,\ 312/312,\ 584/584\).
- \(M_0=220+56\), with the top correction included.
- Koszul homology:
  - degree 1: \(H_1=554\).
  - degree 2: \(H_1=4,\ H_2=340\).
  - degree 3: \(H_2=4,\ H_3=60\).
  - degree 4: all zero.
- Euler coefficients: \(-554,\ 336,\ -56,\ 0\).

### c=10

- \(M_0,\ldots,M_4=(370,704,1100,1560,2086)\).
- \(q_d\) ranks for \(d=2,3,4\): \(165/165,\ 420/420,\ 774/774\).
- \(M_0=286+84\), with the top correction included.
- Koszul homology:
  - degree 1: \(H_1=776\).
  - degree 2: \(H_1=4,\ H_2=508\).
  - degree 3: \(H_2=4,\ H_3=100\).
  - degree 4: all zero.
- Euler coefficients: \(-776,\ 504,\ -96,\ 0\).

## Meaning of the stable +4

The repeated `+4` is real in the Koszul homology, but it cancels in the Euler
coefficient.  Concretely:

| \(c\) | degree 2 pair | degree 3 pair |
|---:|---|---|
| 8 | \(H_2=214=210+4,\ H_1=4\) | \(H_3=32=28+4,\ H_2=4\) |
| 9 | \(H_2=340=336+4,\ H_1=4\) | \(H_3=60=56+4,\ H_2=4\) |
| 10 | \(H_2=508=504+4,\ H_1=4\) | \(H_3=100=96+4,\ H_2=4\) |

So the endpoint numerator sees \(210,336,504\) and \(28,56,96\), not the raw
uncancelled dimensions \(214,340,508\) and \(32,60,100\).  This is why the
observed `+4` does not create a new numerator term.

## Certificate inventory

The machine-readable inventory is in `manifest.json`.  The essential present
certificates are:

1. Source hashes:
   - `7863_reduced_q_rank_probe.py`
   - `7863_reduced_endpoint_dimensions.py`
2. Full reduced Koszul certificates:
   - `tmp/7863_reduced_full_koszul_c8.json`
   - `tmp/7863_reduced_full_koszul_c9.json`
   - `tmp/7863_reduced_full_koszul_c10.json`
3. Supporting reduced certificates:
   - `tmp/7863_reduced_q_rank_c8_c10.json`
   - `tmp/7863_reduced_positive_mu_c8.json`
   - `tmp/7863_reduced_positive_mu_c9_c10.json`
   - `tmp/7863_reduced_m0_top_c8.json`
   - `tmp/7863_reduced_m0_top_c9_c10.json`
4. Direct c=8 bridge certificates against the old large quotient:
   - `tmp/7863_weight_quotient_kernel_replay/c8_m44_factor_max_target200_basis_cert.json`
   - `tmp/7863_weight_quotient_kernel_replay/c8_m44_factor_max_target200_unlimited_summary.json`
   - `tmp/7863_weight_quotient_kernel_replay/c8_m44_to_m45_generated_span_deg1_relations.json`
   - `tmp/7863_weight_quotient_kernel_replay/c8_second_syzygies_times_s1_rank1306_relations.json`
   - `tmp/7863_weight_quotient_kernel_replay/c8_third_syzygies_times_s1_rank824_relations.json`
   - `tmp/7863_weight_quotient_kernel_replay/c8_fourth_syzygies_times_s1_rank128_no_relations.json`

The old raw c=8 replay artifact is very large and is intentionally not copied
into this package.  It can be archived separately if needed.

## Replay commands

From the repository root:

```bash
python3 7863_reduced_q_rank_probe.py 8 --full-koszul --out tmp/7863_reduced_full_koszul_c8.json
python3 7863_reduced_q_rank_probe.py 9 --full-koszul --out tmp/7863_reduced_full_koszul_c9.json
python3 7863_reduced_q_rank_probe.py 10 --full-koszul --out tmp/7863_reduced_full_koszul_c10.json

python3 7863_reduced_q_rank_probe.py 8 --m0-top --out tmp/7863_reduced_m0_top_c8.json
python3 7863_reduced_q_rank_probe.py 9 10 --m0-top --out tmp/7863_reduced_m0_top_c9_c10.json

python3 7863_reduced_q_rank_probe.py 8 --positive-mu --out tmp/7863_reduced_positive_mu_c8.json
python3 7863_reduced_q_rank_probe.py 9 10 --positive-mu --out tmp/7863_reduced_positive_mu_c9_c10.json

python3 7863_reduced_q_rank_probe.py 8 9 10 --out tmp/7863_reduced_q_rank_c8_c10.json
```

The source file also supports `--seed`, `--mode`, `--sparse-l-terms`, and
`--sparse-q-terms`; the certificate values above use the defaults recorded in
the JSON artifacts.

## What remains for a final paper certificate

The current JSON files are reproducible runtime summaries.  To turn this into a
fully portable proof-of-computation, add:

1. Pivot row/column hashes, or explicit pivot certificates, for every rank used
   in the \(q_d\), multiplication, \(M_0\), and Koszul computations.
2. A compact nonzero-minor certificate: enough data to verify that the recorded
   rank lower bounds are certified by nonzero determinants modulo \(p\).
3. A second independent replay over another prime or another deterministic
   dense \(Q\) seed, if we want a robustness check beyond the single
   specialization.
4. Optional c=9 and c=10 direct bridges to the original large quotient, if the
   reduced construction itself is not accepted as the primary mathematical
   reduction.
