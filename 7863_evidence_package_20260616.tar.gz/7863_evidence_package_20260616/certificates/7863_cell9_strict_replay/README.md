# CICY 7863 Cell 9 endpoint proof and certificates

This folder contains the strict q-rank replay certificates used to audit the
right-endpoint Hilbert numerator for Cell 9.  The same information is summarized
in `../../7863_minor_status.md`; this README explains both the analytic proof
of the endpoint numerator/no-tail statement and the finite-field certificate
layers.

## 0. Current proof route

The right endpoint is controlled by two linear rows \(L_1,L_2\) and one
quadratic row \(Q\).  Let

\[
R=A\otimes \operatorname{Sym}(V_y^\vee),
\qquad
A=\mathbb C[x_0,\ldots,x_3],
\qquad
M=R/(L_1,L_2).
\]

The theorem-level proof should not start from the three finite-field matrices
\(q_2,q_3,q_4\).  Those are useful audit checks.  The proof starts from the
endpoint reduction

\[
E_b^\bullet(s)\simeq
\left[
M_{s-2,b-2}\xrightarrow{\;Q\;}M_{s,b}
\right]
\oplus
\delta_{s,0}\operatorname{Sym}^{b-4}V_y^\vee .
\]

Thus the endpoint Hilbert function is

\[
H_s
=
\delta_{s,0}P(b-4)
+
\dim\operatorname{coker}
\left(
M_{s-2,b-2}\xrightarrow{\;Q\;}M_{s,b}
\right),
\]

where \(P(r)=\binom{r+3}{3}\) for \(r\ge0\), and \(P(r)=0\) for \(r<0\).

### 0.1 Endpoint reduction by BR/Bott

The two linear rows define

\[
0\to
\mathcal O_{\mathbb P^3_x}(-1)^{\oplus2}
\xrightarrow{(L_1,L_2)}
V_y^\vee\otimes\mathcal O_{\mathbb P^3_x}
\to E\to0.
\]

For \(n\ge2\), the symmetric Buchsbaum--Rim/Koszul resolution is

\[
0\to
\mathcal O_x(t-2)\otimes\operatorname{Sym}^{n-2}V_y^\vee
\to
\mathcal O_x(t-1)^{\oplus2}\otimes\operatorname{Sym}^{n-1}V_y^\vee
\to
\mathcal O_x(t)\otimes\operatorname{Sym}^{n}V_y^\vee
\to
\operatorname{Sym}^nE(t)
\to0.
\]

Bott cohomology on \(\mathbb P^3_x\) gives exactly three cases needed here:

- for \(t\ge0\), only \(H^0\) survives, and its cokernel is
  \(M_{t,n}\);
- for \(t=-1\), all three line bundles are acyclic;
- for \(t=-2\), the only surviving group is
  \(H^3(\mathcal O_x(-4))\otimes\operatorname{Sym}^{n-2}V_y^\vee\).

Apply this to the target strand \((n,t)=(b,s)\) and the shifted source strand
\((n,t)=(b-2,s-2)\).  Since \(s\ge0\), the target strand always contributes the
ordinary quotient piece \(M_{s,b}\).  The source strand contributes:

- the isolated top class \(\operatorname{Sym}^{b-4}V_y^\vee\) when \(s=0\);
- nothing when \(s=1\);
- the ordinary quotient piece \(M_{s-2,b-2}\) when \(s\ge2\).

This also explains why there is no second correction at \(s=2\): at \(s=2\)
the source twist is \(t=0\), so it is already an ordinary \(H^0\) term, not a
top-Cech term.

The isolated top class has zero incoming and outgoing differential.  Internally,
the only possible outgoing BR map lands in \(H^\bullet(\mathcal O_x(-3))\),
which is zero.  Externally, multiplication by \(Q\) increases the \(x\)-twist
by \(2\); on the top-Cech page the image would land in \(H^3\) of twists
\(\mathcal O_x(-2)\), \(\mathcal O_x(-1)\), or \(\mathcal O_x\), all of which
have zero \(H^3\).  Therefore the top class is an isolated summand and the
remaining endpoint map is multiplication by \(Q\) on the reduced quotient
module \(M\).

### 0.2 No-tail from the nonzerodivisor condition

If

\[
(L_1,L_2):Q=(L_1,L_2),
\]

then \(Q\) is a nonzerodivisor on \(M=R/(L_1,L_2)\).  Hence every graded map

\[
Q:M_{s-2,b-2}\to M_{s,b}
\]

is injective.  This proves the all-degree no-tail statement for the reduced
endpoint: no later cokernel contribution can appear beyond the Hilbert series
computed below.  Consequently

\[
H_s
=
\delta_{s,0}P(b-4)+\dim M_{s,b}-\dim M_{s-2,b-2}.
\]

For general coefficients this is a Zariski-open condition.  One can show
nonemptiness by a monomial specialization, for example

\[
L_1=x_0y_0,\qquad L_2=x_1y_1,\qquad Q=x_2^2y_2^2,
\]

where these three monomials form a regular sequence.  Intersecting this open
condition with the smooth complete-intersection locus gives the desired
statement for a general smooth CICY \(7863\).

### 0.3 Hilbert numerator

Since \(L_1,L_2\) are a regular sequence of bidegree \((1,1)\),

\[
\operatorname{HS}_M(u,v)=
\frac{(1-uv)^2}{(1-u)^4(1-v)^4}.
\]

Taking the coefficient of \(v^n\) gives

\[
\operatorname{HS}(M_{*,n};t)=
\frac{P(n)-2P(n-1)t+P(n-2)t^2}{(1-t)^4}.
\]

Therefore

\[
\sum_{s\ge0}H_st^s
=
P(b-4)
+
\operatorname{HS}(M_{*,b};t)
-
t^2\operatorname{HS}(M_{*,b-2};t).
\]

Putting this over \((1-t)^4\) gives

\[
\sum_{s\ge0}H_st^s=
\frac{n_{b,0}+n_{b,1}t+n_{b,2}t^2+n_{b,3}t^3}{(1-t)^4},
\]

where

\[
n_{b,0}=\frac{b(b^2+11)}3,\qquad
n_{b,1}=-(b^3-3b^2+8b-4),
\]

\[
n_{b,2}=(b-1)(b-2)(b-3),\qquad
n_{b,3}=-\frac{(b-6)(b-1)(b-2)}3.
\]

The \(t^4\)-coefficient cancels identically, and there are no higher numerator
terms in this analytic derivation.

For \(b=4,\ldots,10\), this gives the table

\[
\begin{array}{c|rrrr}
b & n_{b,0} & n_{b,1} & n_{b,2} & n_{b,3}\\
\hline
4 & 36  & -44  & 6   & 4\\
5 & 60  & -86  & 24  & 4\\
6 & 94  & -152 & 60  & 0\\
7 & 140 & -248 & 120 & -10\\
8 & 200 & -380 & 210 & -28\\
9 & 276 & -554 & 336 & -56\\
10& 370 & -776 & 504 & -96.
\end{array}
\]

With the original endpoint shift, this means

\[
\sum_{m\ge0}N_b(m)t^m
=
t^{6b-4}
\frac{n_{b,0}+n_{b,1}t+n_{b,2}t^2+n_{b,3}t^3}{(1-t)^4}.
\]

### 0.4 Initial-ideal finite-field audit

The script `../../7863_initial_ideal_hilbert_check.py` gives an independent
finite-field audit of the numerator.  It computes, over a finite field,

\[
I=(L_1,L_2,Q)\subset
\mathbb F_p[x_0,\ldots,x_3,y_0,\ldots,y_3],
\]

takes a Groebner basis, extracts the leading monomial ideal
\(\operatorname{in}(I)\), and counts standard monomials of bidegree
\((s,b)\).  Then it adds the isolated correction \(P(b-4)\) in shifted degree
\(s=0\), and takes fourth finite differences to recover the numerator.

The following runs all agree with the table above for \(b=4,\ldots,10\) and
for every \(s=0,\ldots,50\):

| prime | max \(s\) | leading monomials | result |
|---:|---:|---:|---|
| 1000003 | 50 | 8 | match |
| 1000033 | 50 | 8 | match |
| 1000037 | 50 | 8 | match |
| 1000039 | 50 | 8 | match |
| 1000081 | 50 | 8 | match |

For \(p=1000003\), the leading monomials are

\[
x_1y_1,\quad x_0y_0,\quad x_1^2y_0^2,\quad x_0^3y_1^2,
\]

\[
x_2^2y_0^2y_1,\quad x_1^3x_2y_0y_2,\quad
x_0^4x_2y_1y_2,\quad x_0^4x_1^2y_2^2.
\]

This initial-ideal check is a strong finite-field audit of the displayed
Hilbert numerator and of the no-tail formula through the tested window.  It is
not the source of the characteristic-zero theorem; the theorem-level no-tail
statement comes from the BR/Bott endpoint reduction plus the nonzerodivisor
bridge above.

## 1. What endpoint number are we computing?

For Cell 9 we write

\[
a=-m-4,\qquad m\ge0.
\]

The reduced complex has right endpoint \(C_1\to C_0\).  The cokernel dimension
of that endpoint is computed by dualizing the map.  After dualization, the
number we want is

\[
N_b(m)=\dim\ker\alpha_b(m),
\]

where

\[
\alpha_b(m):
A_m\otimes\operatorname{Sym}^b(\mathbb C_y^4)^\vee
\longrightarrow
\left(A_{m+1}\otimes\operatorname{Sym}^{b-1}(\mathbb C_y^4)^\vee\right)^2
\oplus
A_{m+2}\otimes\operatorname{Sym}^{b-2}(\mathbb C_y^4)^\vee .
\]

The three rows of this map are multiplication by \(L_1,L_2,Q\), where \(L_1\)
and \(L_2\) are linear in the \(x\)-variables and \(Q\) is quadratic in the
\(x\)-variables.  The endpoint Hilbert series is written as

\[
\sum_{m\ge0}N_b(m)t^m
=
\frac{t^{6b-4}(n_{b,0}+n_{b,1}t+n_{b,2}t^2+n_{b,3}t^3)}{(1-t)^4}.
\]

So the computation is a Hilbert-series computation for the graded module
\(\ker\alpha_b\), not a fit of finitely many unrelated values.

Set

\[
s_0=6b-4,\qquad H_s=N_b(s_0+s).
\]

The coefficients \(n_{b,i}\) are obtained from the shifted values \(H_s\).

## 2. Why the two linear rows are removed first

The direct matrix for \(\alpha_b(m)\) is large.  The special structure is that
two rows are linear.  We quotient by those two rows first:

\[
B(n,t)=
\frac{A_t\otimes\operatorname{Sym}^n(\mathbb C_y^4)^\vee}
{L_1(A_{t-1}\otimes\operatorname{Sym}^{n-1}(\mathbb C_y^4)^\vee)
 +L_2(A_{t-1}\otimes\operatorname{Sym}^{n-1}(\mathbb C_y^4)^\vee)} .
\]

This is the Buchsbaum--Rim quotient model.  Informally:

- before quotienting, vectors are polynomials in the source of \(\alpha_b\);
- the two linear rows generate an obvious image;
- \(B(n,t)\) is the remaining quotient space after this image is removed.

Once this has been done, the only row still acting is the quadratic row \(Q\).
Thus \(Q\) descends to maps between the quotient spaces \(B(n,t)\).

## 3. Why there are exactly three q-rank matrices

In shifted degree \(0\), no \(Q\)-source exists.  The first value is structural:

\[
H_0=P(b)+P(b-4),
\qquad
P(r)=\binom{r+3}{3}.
\]

The \(P(b)\) term is the ordinary piece.  The \(P(b-4)\) term is the additional
top/Cech summand in \(M_0\).

In shifted degree \(1\), there is still no \(Q\)-source, so

\[
H_1=\dim B(b,1).
\]

Starting in shifted degree \(2\), the quadratic row acts.  Because \(Q\) has
y-degree \(2\) and x-degree \(2\), its source in shifted degree \(s\) is
\(B(b-2,s-2)\), and its target is \(B(b,s)\).  Therefore the three first
quadratic maps are

\[
q_2:B(b-2,0)\longrightarrow B(b,2),
\]

\[
q_3:B(b-2,1)\longrightarrow B(b,3),
\]

\[
q_4:B(b-2,2)\longrightarrow B(b,4).
\]

For \(s=2,3,4\),

\[
H_s=\dim B(b,s)-\operatorname{rank}(q_s).
\]

The certificate proves that each \(q_s\) has full column rank.  Hence

\[
H_s=\dim B(b,s)-\dim B(b-2,s-2).
\]

This is why the folder contains \(7\times3=21\) q-rank certificates: one for
each \(b=4,\ldots,10\) and one for each \(s=2,3,4\).

## 4. How the numerator is reconstructed

Since the denominator is \((1-t)^4\), the numerator coefficients are fourth
finite differences of the shifted Hilbert function:

\[
n_{b,0}=H_0,
\]

\[
n_{b,1}=H_1-4H_0,
\]

\[
n_{b,2}=H_2-4H_1+6H_0,
\]

\[
n_{b,3}=H_3-4H_2+6H_1-4H_0.
\]

The \(q_4\) certificate gives \(H_4\), which checks the first possible
coefficient after the printed numerator:

\[
n_{b,4}=H_4-4H_3+6H_2-4H_1+H_0.
\]

For the recorded certificates this value is zero.  This is only a first
consistency check after the printed numerator.  It does not by itself control
the later maps \(q_5,q_6,\ldots\), nor does it prove a full no-tail or
regularity statement.  Such a propagation statement would need a separate
regularity argument, a resolution/initial-module certificate, or further rank
certificates in higher shifted degrees.

## 5. Worked example: b=4

For \(b=4\),

\[
s_0=6b-4=20.
\]

The structural values are

\[
H_0=P(4)+P(0)=35+1=36,
\qquad
H_1=\dim B(4,1)=100.
\]

The q-rank certificates in this folder say:

- \(q_2\) has matrix size `200 x 10` and full column rank `10`;
- \(q_3\) has matrix size `340 x 32` and full column rank `32`;
- \(q_4\) has matrix size `525 x 69` and full column rank `69`.

Therefore

\[
H_2=200-10=190,
\]

\[
H_3=340-32=308,
\]

\[
H_4=525-69=456.
\]

Now take finite differences:

\[
n_{4,0}=36,
\]

\[
n_{4,1}=100-4\cdot36=-44,
\]

\[
n_{4,2}=190-4\cdot100+6\cdot36=6,
\]

\[
n_{4,3}=308-4\cdot190+6\cdot100-4\cdot36=4.
\]

The next coefficient is

\[
n_{4,4}=456-4\cdot308+6\cdot190-4\cdot100+36=0.
\]

So the endpoint numerator is

\[
36t^{20}-44t^{21}+6t^{22}+4t^{23}.
\]

The cases \(b=5,\ldots,10\) are computed in the same way, using their
corresponding `q_2`, `q_3`, and `q_4` certificate files.

## 6. What each certificate proves

Each q-rank certificate:

- rebuilds the quotient matrix over \(\mathbb F_{1000003}\);
- checks the matrix hash;
- records pivot rows for a square full-column-rank minor;
- computes the determinant of that minor modulo `1000003`;
- checks that this determinant is nonzero.

The nonzero determinant proves the required rank over the finite field.  Since
the determinant is obtained from the universal integer-coefficient matrix by
specialization, a nonzero value modulo `1000003` proves that the corresponding
determinant polynomial is not identically zero.  This gives a nonempty
Zariski-open condition in characteristic zero.

Thus these certificates supply a replayable low-degree rank/audit layer for
the endpoint Hilbert numerator.  They check the basis conventions, shifts,
the first numerator coefficients, and the first vanishing coefficient
\(n_{b,4}=0\).  The all-degree no-tail theorem is the analytic result proved
by the BR/Bott reduction and the nonzerodivisor argument in Section 0 of this
README.
