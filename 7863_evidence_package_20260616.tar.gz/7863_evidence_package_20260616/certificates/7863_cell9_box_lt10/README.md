# CICY 7863 Cell 9 finite box c<10 certificate

Date: 2026-06-12.

This package seals the finite box

\[
\text{Cell 9:}\qquad a=-m-4,\quad m\ge0,\quad 4\le b=c<10
\]

in the reduced finite-field certificate sense.  By Calabi--Yau Serre duality it
also seals the corresponding Cell 73 box

\[
\text{Cell 73:}\qquad a=m+4,\quad m\ge0,\quad -10<b=-c\le -4.
\]

The six covered slices are

\[
c=4,5,6,7,8,9.
\]

Each fixed \(c\)-slice contains infinitely many line bundles, one for every
\(m\ge0\).  The point of the certificate is that the endpoint Hilbert numerator
candidate and the reduced Koszul degree-4 check are replayable on the recorded
finite-field specialization.  A separate regularity/no-tail propagation
argument is still required to turn these finite shifted-degree checks into a
full all-\(m\) slice theorem.

For the detailed explanation of how the endpoint Hilbert numerator is computed
from the three q-rank matrices \(q_2,q_3,q_4\), see
`../7863_cell9_strict_replay/README.md`.

## Status

Over \(\mathbb F_{1000003}\), for the deterministic specialization
`mode=sparseL_denseQ`, `seed=7863`, `sparse_l_terms=8`,
`sparse_q_terms=20`, the reduced endpoint complex verifies the predicted
numerator for every \(4\le c<10\).  In every covered slice, shifted degree
\(4\) Koszul homology is zero.  This is a degree-4 tail check, not by itself a
proof that no later higher-degree tail can occur.

Thus, in the computational finite-field certificate sense used here, the
recorded finite shifted-degree layers support the Cell 9 and Cell 73 endpoint
formulae on the slices below:

> Cell 9 is checked for \(4\le b<10\), and Cell 73 is checked for
> \(-10<b\le -4\), modulo the missing all-degree propagation step.

The separate \(c=10\) certificate exists in
`certificates/7863_cell9_reduced/`; it is outside the strict `c<10` box.

## Numerators

For endpoint \(s=6c-4\), the verified numerator is

\[
n_c(t)=A_ct^s-B_ct^{s+1}+C_ct^{s+2}-G_ct^{s+3},
\]

with

\[
A_c=\frac{c(c^2+11)}3,\qquad
B_c=c^3-3c^2+8c-4,\qquad
C_c=(c-1)(c-2)(c-3),\qquad
G_c=\frac{(c-6)(c-2)(c-1)}3.
\]

Concrete verified cases:

| \(c\) | \(s\) | numerator |
|---:|---:|---|
| 4 | 20 | \(36t^{20}-44t^{21}+6t^{22}+4t^{23}\) |
| 5 | 26 | \(60t^{26}-86t^{27}+24t^{28}+4t^{29}\) |
| 6 | 32 | \(94t^{32}-152t^{33}+60t^{34}\) |
| 7 | 38 | \(140t^{38}-248t^{39}+120t^{40}-10t^{41}\) |
| 8 | 44 | \(200t^{44}-380t^{45}+210t^{46}-28t^{47}\) |
| 9 | 50 | \(276t^{50}-554t^{51}+336t^{52}-56t^{53}\) |

## Module dimensions

The reduced modules \(M_0,\ldots,M_4\) are:

| \(c\) | \(M_0\) | \(M_1\) | \(M_2\) | \(M_3\) | \(M_4\) |
|---:|---:|---:|---:|---:|---:|
| 4 | 36 | 100 | 190 | 308 | 456 |
| 5 | 60 | 154 | 280 | 440 | 636 |
| 6 | 94 | 224 | 392 | 600 | 850 |
| 7 | 140 | 312 | 528 | 790 | 1100 |
| 8 | 200 | 420 | 690 | 1012 | 1388 |
| 9 | 276 | 550 | 880 | 1268 | 1716 |

The \(M_0\) decompositions \(B(c,0)\oplus H^1(\operatorname{Sym}^{c-2}E(-2))\)
are:

| \(c\) | regular part | top correction | total |
|---:|---:|---:|---:|
| 4 | 35 | 1 | 36 |
| 5 | 56 | 4 | 60 |
| 6 | 84 | 10 | 94 |
| 7 | 120 | 20 | 140 |
| 8 | 165 | 35 | 200 |
| 9 | 220 | 56 | 276 |

## Koszul homology and Euler coefficients

| \(c\) | degree 1 | degree 2 | degree 3 | degree 4 | Euler coefficients |
|---:|---|---|---|---|---|
| 4 | \(H_1=44\) | \(H_1=4,H_2=10\) | \(H_2=4,H_3=0\) | all zero | \(-44,6,4,0\) |
| 5 | \(H_1=86\) | \(H_1=4,H_2=28\) | \(H_2=4,H_3=0\) | all zero | \(-86,24,4,0\) |
| 6 | \(H_1=152\) | \(H_1=4,H_2=64\) | \(H_2=4,H_3=4\) | all zero | \(-152,60,0,0\) |
| 7 | \(H_1=248\) | \(H_1=4,H_2=124\) | \(H_2=4,H_3=14\) | all zero | \(-248,120,-10,0\) |
| 8 | \(H_1=380\) | \(H_1=4,H_2=214\) | \(H_2=4,H_3=32\) | all zero | \(-380,210,-28,0\) |
| 9 | \(H_1=554\) | \(H_1=4,H_2=340\) | \(H_2=4,H_3=60\) | all zero | \(-554,336,-56,0\) |

The stable \(+4\) terms are cancellable Koszul pairs.  They are visible in
homology, but they do not add numerator terms.

## Certificate artifacts

The machine-readable inventory is in `manifest.json`.

Core files:

- `tmp/7863_reduced_full_koszul_c4_c7.json`
- `tmp/7863_reduced_full_koszul_c8.json`
- `tmp/7863_reduced_full_koszul_c9.json`
- `tmp/7863_reduced_m0_top_c4_c7.json`
- `tmp/7863_reduced_positive_mu_c4_c7.json`
- `tmp/7863_reduced_q_rank_c4_c7.json`
- existing c=8/9 supporting artifacts listed in the manifest.

The helper `7863_hard_cell_calculator.py` has also been updated so it no
longer reports \(b=6,7,8,9\) as unresolved.

## Replay commands

From the repository root:

```bash
python3 7863_reduced_q_rank_probe.py 4 5 6 7 --full-koszul --out tmp/7863_reduced_full_koszul_c4_c7.json
python3 7863_reduced_q_rank_probe.py 8 --full-koszul --out tmp/7863_reduced_full_koszul_c8.json
python3 7863_reduced_q_rank_probe.py 9 --full-koszul --out tmp/7863_reduced_full_koszul_c9.json

python3 7863_reduced_q_rank_probe.py 4 5 6 7 --m0-top --out tmp/7863_reduced_m0_top_c4_c7.json
python3 7863_reduced_q_rank_probe.py 4 5 6 7 --positive-mu --out tmp/7863_reduced_positive_mu_c4_c7.json
python3 7863_reduced_q_rank_probe.py 4 5 6 7 --out tmp/7863_reduced_q_rank_c4_c7.json
```

## Publication-grade caveat

This seals the box in the current finite-field reduced-certificate framework.
For a portable publication-grade generic characteristic-zero proof, the usual
additional packaging remains: export pivot/minor witnesses for the rank
computations, and optionally replay over a second specialization.
