#!/usr/bin/env python3
"""Search for a characteristic-zero CICY 7863 K3 endpoint witness.

This is a scratch search helper.  It fixes the split-linear diagonal
L1,L2 used by the finite-field certificate and samples small-integer Q's.
For each sample it builds the j=3 endpoint kernel computation in Singular:

    KL = syz(ML)
    QK = MQ * KL
    T  = syz(QK)
    K  = KL * T
    G  = std(K)

The target quotient Hilbert series is

    HS(A^20/K;t) = (20 - 20 t^14 + 20 t^15 - 2 t^17)/(1-t)^4.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import random
import re
import subprocess
import time
from functools import lru_cache


ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "tmp" / "7863_k3_rational_search"
SINGULAR = pathlib.Path("/opt/homebrew/bin/Singular")

TARGET_NUMERATOR = "-2t17+20t15-20t14+20"


@lru_cache(maxsize=None)
def monoms_deg(n: int, vars_count: int = 4) -> tuple[tuple[int, ...], ...]:
    if n < 0:
        return ()
    out: list[tuple[int, ...]] = []

    def rec(i: int, rem: int, acc: list[int]) -> None:
        if i == vars_count - 1:
            out.append(tuple(acc + [rem]))
            return
        for k in range(rem + 1):
            rec(i + 1, rem - k, acc + [k])

    rec(0, n, [])
    return tuple(out)


def sub_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...] | None:
    out = tuple(x - y for x, y in zip(a, b))
    return None if any(x < 0 for x in out) else out


def falling_for_multi(beta: tuple[int, ...], nu: tuple[int, ...]) -> int:
    coeff = 1
    for b, n in zip(beta, nu):
        if n > b:
            return 0
        for j in range(n):
            coeff *= b - j
    return coeff


def monomial_str(exp: tuple[int, ...]) -> str:
    pieces = []
    for i, power in enumerate(exp):
        if power == 1:
            pieces.append(f"x{i}")
        elif power > 1:
            pieces.append(f"x{i}^{power}")
    return "*".join(pieces) if pieces else "1"


def polynomial_str(poly: dict[tuple[int, ...], int]) -> str:
    pieces = []
    for exp, coeff in sorted(poly.items()):
        if coeff == 0:
            continue
        monom = monomial_str(exp)
        if monom == "1":
            term = str(abs(coeff))
        elif abs(coeff) == 1:
            term = monom
        else:
            term = f"{abs(coeff)}*{monom}"
        if not pieces:
            pieces.append(term if coeff > 0 else f"-{term}")
        else:
            pieces.append(("+" if coeff > 0 else "-") + term)
    return "".join(pieces) if pieces else "0"


def add_poly_term(poly: dict[tuple[int, ...], int], exp: tuple[int, ...], coeff: int) -> None:
    if coeff == 0:
        return
    new_value = poly.get(exp, 0) + coeff
    if new_value:
        poly[exp] = new_value
    elif exp in poly:
        del poly[exp]


def sample_q(seed: int, bound: int, density: float) -> list[tuple[int, tuple[int, ...], tuple[int, ...]]]:
    rng = random.Random(seed)
    x2 = monoms_deg(2)
    y2 = monoms_deg(2)
    terms = []
    for xe in x2:
        for ye in y2:
            if rng.random() <= density:
                coeff = 0
                while coeff == 0:
                    coeff = rng.randint(-bound, bound)
                terms.append((coeff, xe, ye))
    return terms


def endpoint_columns(q_terms: list[tuple[int, tuple[int, ...], tuple[int, ...]]]):
    c = 3
    e = monoms_deg(1)
    l1 = [(1, e[i], e[i]) for i in range(4)]
    l2 = [(i + 1, e[i], e[i]) for i in range(4)]
    y_dom = monoms_deg(c)
    y_l = monoms_deg(c - 1)
    y_q = monoms_deg(c - 2)
    rows = 2 * len(y_l) + len(y_q)
    cols: list[list[dict[tuple[int, ...], int]]] = []
    for beta in y_dom:
        col = [{} for _ in range(rows)]
        for block, lin_terms in enumerate((l1, l2)):
            for coeff, xop, yop in lin_terms:
                ynew = sub_exp(beta, yop)
                if ynew is None:
                    continue
                ycoeff = falling_for_multi(beta, yop)
                if not ycoeff:
                    continue
                row = block * len(y_l) + y_l.index(ynew)
                add_poly_term(col[row], xop, coeff * ycoeff)
        for coeff, xop, yop in q_terms:
            ynew = sub_exp(beta, yop)
            if ynew is None:
                continue
            ycoeff = falling_for_multi(beta, yop)
            if not ycoeff:
                continue
            row = 2 * len(y_l) + y_q.index(ynew)
            add_poly_term(col[row], xop, coeff * ycoeff)
        cols.append(col)
    return cols


def module_columns_to_singular(cols: list[list[dict[tuple[int, ...], int]]]) -> str:
    return ",".join("[" + ",".join(polynomial_str(poly) for poly in col) + "]" for col in cols)


def singular_script(
    seed: int,
    bound: int,
    density: float,
    characteristic: int,
    augment: bool = False,
) -> str:
    cols = endpoint_columns(sample_q(seed, bound, density))
    y_l_count = len(monoms_deg(2))
    lin_rows = 2 * y_l_count
    ml_cols = [col[:lin_rows] for col in cols]
    mq_cols = [col[lin_rows:] for col in cols]
    lines = [
            f"// K3 rational search seed={seed}, bound={bound}, density={density}",
            f"ring r={characteristic},(x0,x1,x2,x3),dp;",
            "option(redSB);",
            f"module ML={module_columns_to_singular(ml_cols)};",
            f"module MQ={module_columns_to_singular(mq_cols)};",
            "module KL=syz(ML);",
            'print("KL_SIZE_BEGIN");',
            "print(size(KL));",
            'print("KL_SIZE_END");',
            "matrix QKmat=matrix(MQ)*matrix(KL);",
            "module QK=module(QKmat);",
            "module T=syz(QK);",
            'print("T_SIZE_BEGIN");',
            "print(size(T));",
            'print("T_SIZE_END");',
            "module K=module(matrix(KL)*matrix(T));",
            "module G=std(K);",
            'print("K_SIZE_BEGIN");',
            "print(size(K));",
            'print("K_SIZE_END");',
            'print("STD_SIZE_BEGIN");',
            "print(size(G));",
            'print("STD_SIZE_END");',
            'print("HILB_QUOT_BEGIN");',
            "hilb(G);",
            'print("HILB_QUOT_END");',
    ]
    if augment:
        lines.extend(
            [
                'print("BETTI_BEGIN");',
                "resolution R=mres(G,0);",
                'print(betti(R),"betti");',
                'print("BETTI_END");',
                'print("MINRES_BETTI_BEGIN");',
                "resolution MR=minres(R);",
                'print(betti(MR),"betti");',
                'print("MINRES_BETTI_END");',
                'print("LEAD_TERMS_BEGIN");',
                "int k3_i;",
                "for (k3_i=1; k3_i<=size(G); k3_i++)",
                "{",
                '  print("LT_BEGIN");',
                "  print(k3_i);",
                "  print(leadmonom(G[k3_i]));",
                "  print(leadcoef(G[k3_i]));",
                '  print("LT_END");',
                "}",
                'print("LEAD_TERMS_END");',
            ]
        )
    lines.extend(["quit;", ""])
    return "\n".join(lines)


def marker_int(stdout: str, begin: str, end: str) -> int | None:
    match = re.search(re.escape(begin) + r"\s*([0-9]+)\s*" + re.escape(end), stdout)
    return int(match.group(1)) if match else None


def parse_hilb(stdout: str) -> str | None:
    if "HILB_QUOT_BEGIN" not in stdout:
        return None
    block = stdout.split("HILB_QUOT_BEGIN", 1)[1].split("HILB_QUOT_END", 1)[0]
    for line in block.splitlines():
        line = line.strip().replace(" ", "")
        if line.startswith("(") and ")/(1-t)^4" in line:
            return line.split(")/(1-t)^4", 1)[0].strip("()")
    return None


def run_case(
    seed: int,
    bound: int,
    density: float,
    characteristic: int,
    timeout: int,
    keep: bool,
    augment: bool,
):
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"k3_char{characteristic}_seed{seed}_b{bound}_d{str(density).replace('.', 'p')}"
    script_path = OUT_DIR / f"{stem}.sing"
    out_path = OUT_DIR / f"{stem}.out"
    err_path = OUT_DIR / f"{stem}.err"
    script_path.write_text(
        singular_script(seed, bound, density, characteristic, augment), encoding="utf-8"
    )
    t0 = time.time()
    try:
        proc = subprocess.run(
            [str(SINGULAR), "-q", str(script_path)],
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        proc = subprocess.CompletedProcess(
            args=[str(SINGULAR), "-q", str(script_path)],
            returncode=-999,
            stdout=exc.stdout if isinstance(exc.stdout, str) else "",
            stderr=exc.stderr if isinstance(exc.stderr, str) else "",
        )
        timed_out = True
    seconds = round(time.time() - t0, 3)
    if keep or parse_hilb(proc.stdout) == TARGET_NUMERATOR:
        out_path.write_text(proc.stdout, encoding="utf-8")
        err_path.write_text(proc.stderr, encoding="utf-8")
    else:
        script_path.unlink(missing_ok=True)
    hilb = parse_hilb(proc.stdout)
    return {
        "seed": seed,
        "bound": bound,
        "density": density,
        "characteristic": characteristic,
        "seconds": seconds,
        "returncode": proc.returncode,
        "timed_out": timed_out,
        "kl": marker_int(proc.stdout, "KL_SIZE_BEGIN", "KL_SIZE_END"),
        "t": marker_int(proc.stdout, "T_SIZE_BEGIN", "T_SIZE_END"),
        "k": marker_int(proc.stdout, "K_SIZE_BEGIN", "K_SIZE_END"),
        "std": marker_int(proc.stdout, "STD_SIZE_BEGIN", "STD_SIZE_END"),
        "hilb": hilb,
        "hit": hilb == TARGET_NUMERATOR,
        "script": str(script_path),
        "stdout_tail": proc.stdout[-600:],
        "stderr_tail": proc.stderr[-600:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, default=1)
    parser.add_argument("--count", type=int, default=20)
    parser.add_argument("--bound", type=int, default=3)
    parser.add_argument("--density", type=float, default=1.0)
    parser.add_argument("--characteristic", type=int, default=0)
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument("--keep", action="store_true")
    parser.add_argument("--augment", action="store_true")
    args = parser.parse_args()

    for seed in range(args.start, args.start + args.count):
        record = run_case(
            seed,
            args.bound,
            args.density,
            args.characteristic,
            args.timeout,
            args.keep,
            args.augment,
        )
        print(json.dumps(record, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
