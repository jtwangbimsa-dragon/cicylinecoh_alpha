# CICY 7863 K3 endpoint characteristic-zero witness

This folder records the characteristic-zero witness for the \(j=3\) endpoint
module used for the \(N_3\) numerator in the paper.

The replay file is

```bash
Singular -q k3_char0_seed1_b3_d1p0.sing
```

It fixes the diagonal split-linear \(L_1,L_2\) part and uses a dense
small-integer rational \(Q\).  The script computes

```text
KL = syz(ML)
QK = MQ * KL
T  = syz(QK)
K  = KL * T
G  = std(K)
```

The output verifies the quotient Betti table for \(A^{20}/K\), equivalently
the minimal free resolution of \(K\):

```text
0 -> A(-16)^4 + A(-17)^2
  -> A(-15)^20 + A(-16)^4
  -> A(-14)^20
  -> K -> 0.
```

In particular

```text
HS(A^20/K;t) = (20 - 20 t^14 + 20 t^15 - 2 t^17)/(1-t)^4.
```

Therefore

```text
HS(K;t) = (20 t^14 - 20 t^15 + 2 t^17)/(1-t)^4.
```

The standard basis has 32 leading monomials, matching the earlier finite-field
search witness, with all leading coefficients nonzero over \(\mathbb Q\).
