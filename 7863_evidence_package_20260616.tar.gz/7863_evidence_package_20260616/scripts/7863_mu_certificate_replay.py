#!/usr/bin/env python3
"""Generate and replay standalone M0/positive multiplication certificates.

The full-Koszul replay rebuilds the M0 top-correction and positive
multiplication maps internally.  This script gives those layers their own
stored-witness replay package: matrix hashes, exact ranks, pivot-row hashes,
and commutativity checks are stored and then independently recomputed during
replay.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import sys
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
QREPLAY_PATH = ROOT / "7863_qrank_certificate_replay.py"
SPEC = importlib.util.spec_from_file_location("qreplay7863_mu", QREPLAY_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_qrank_certificate_replay.py")
qreplay = importlib.util.module_from_spec(SPEC)
sys.modules["qreplay7863_mu"] = qreplay
SPEC.loader.exec_module(qreplay)

probe = qreplay.probe
P = qreplay.P
Vector = dict[int, int]


def matrix_entry(name: str, rows: int, cols: list[Vector], meta: dict[str, Any] | None = None) -> dict[str, Any]:
    pivots = probe.build_pivots(cols)
    pivot_rows = [int(row) for row in pivots.keys()]
    entry = {
        "name": name,
        "rows": int(rows),
        "cols": len(cols),
        "rank": len(pivots),
        "matrix_sparse_columns_sha256": qreplay.matrix_hash(cols),
        "pivot_rows_sha256": qreplay.sha256_json(pivot_rows),
        "max_col_fill": max((len(col) for col in cols), default=0),
    }
    if meta:
        entry["meta"] = meta
    return entry


def build_mu_data(c: int, seed: int, mode: str, sparse_l_terms: int, sparse_q_terms: int) -> dict[str, Any]:
    modules, q_meta = probe.build_positive_modules(c, seed, mode, sparse_l_terms, sparse_q_terms)
    mu0 = {
        x_var: probe.mu0_columns(c, x_var, seed, mode, sparse_l_terms, sparse_q_terms)
        for x_var in range(4)
    }
    positive_mu: dict[int, dict[int, list[Vector]]] = {}
    for d in (1, 2, 3):
        positive_mu[d] = {}
        for x_var in range(4):
            positive_mu[d][x_var] = probe.positive_mu_columns(modules, d, x_var)

    m0_entries = [
        matrix_entry(
            f"mu0_x{x_var}",
            modules[1].dim,
            mu0[x_var],
            {"x_var": x_var, "source": "M0", "target": "M1"},
        )
        for x_var in range(4)
    ]
    positive_entries = []
    for d in (1, 2, 3):
        for x_var in range(4):
            positive_entries.append(
                matrix_entry(
                    f"mu_d{d}_x{x_var}",
                    modules[d + 1].dim,
                    positive_mu[d][x_var],
                    {"x_var": x_var, "source": f"M{d}", "target": f"M{d + 1}"},
                )
            )

    m0_commutativity = []
    for i in range(4):
        for j in range(i + 1, 4):
            left = probe.compose_columns(positive_mu[1][i], mu0[j])
            right = probe.compose_columns(positive_mu[1][j], mu0[i])
            m0_commutativity.append({
                "i": i,
                "j": j,
                "commutes": probe.columns_equal(left, right),
                "left_hash": qreplay.matrix_hash(left),
                "right_hash": qreplay.matrix_hash(right),
            })

    positive_commutativity = []
    for d in (1, 2):
        for i in range(4):
            for j in range(i + 1, 4):
                left = probe.compose_columns(positive_mu[d + 1][i], positive_mu[d][j])
                right = probe.compose_columns(positive_mu[d + 1][j], positive_mu[d][i])
                positive_commutativity.append({
                    "d": d,
                    "i": i,
                    "j": j,
                    "commutes": probe.columns_equal(left, right),
                    "left_hash": qreplay.matrix_hash(left),
                    "right_hash": qreplay.matrix_hash(right),
                })

    return {
        "m0_dim": len(mu0[0]),
        "regular_dim": probe.build_br_space(c, 0, seed, mode, sparse_l_terms, sparse_q_terms).dim,
        "top_dim": len(probe.top_basis(c)),
        "module_dims_M1_to_M4": {str(d): modules[d].dim for d in range(1, 5)},
        "q_quotient_meta": q_meta,
        "m0_entries": m0_entries,
        "positive_entries": positive_entries,
        "m0_commutativity": m0_commutativity,
        "positive_commutativity": positive_commutativity,
        "all_m0_m1_squares_commute": all(row["commutes"] for row in m0_commutativity),
        "all_positive_squares_commute": all(row["commutes"] for row in positive_commutativity),
    }


def make_certificate(args: argparse.Namespace) -> dict[str, Any]:
    started = time.time()
    data = build_mu_data(args.c, args.seed, args.mode, args.sparse_l_terms, args.sparse_q_terms)
    return {
        "certificate_type": "cicy_7863_cell9_mu_m0_positive_replay_v1",
        "statement": "standalone M0-top and positive multiplication maps over F_p",
        "cicy": 7863,
        "cell": 9,
        "c": args.c,
        "prime": P,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "data": data,
        "source_files": {
            "generator_checker": pathlib.Path(__file__).name,
            "generator_checker_sha256": qreplay.sha256_file(pathlib.Path(__file__)),
            "qrank_replay_helper": QREPLAY_PATH.name,
            "qrank_replay_helper_sha256": qreplay.sha256_file(QREPLAY_PATH),
            "matrix_recipe": qreplay.PROBE_PATH.name,
            "matrix_recipe_sha256": qreplay.sha256_file(qreplay.PROBE_PATH),
        },
        "seconds": round(time.time() - started, 6),
    }


def entries_by_name(entries: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {entry["name"]: entry for entry in entries}


def compare_entries(observed: list[dict[str, Any]], expected: list[dict[str, Any]]) -> dict[str, dict[str, bool]]:
    obs_map = entries_by_name(observed)
    exp_map = entries_by_name(expected)
    out = {}
    for name, exp in exp_map.items():
        obs = obs_map[name]
        out[name] = {
            "rows_match": obs["rows"] == exp["rows"],
            "cols_match": obs["cols"] == exp["cols"],
            "rank_match": obs["rank"] == exp["rank"],
            "matrix_hash_match": obs["matrix_sparse_columns_sha256"] == exp["matrix_sparse_columns_sha256"],
            "pivot_rows_hash_match": obs["pivot_rows_sha256"] == exp["pivot_rows_sha256"],
            "max_col_fill_match": obs["max_col_fill"] == exp["max_col_fill"],
        }
    return out


def replay_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    started = time.time()
    if cert.get("certificate_type") != "cicy_7863_cell9_mu_m0_positive_replay_v1":
        raise ValueError("unexpected certificate_type")
    if int(cert["prime"]) != P:
        raise ValueError("prime mismatch")
    observed = build_mu_data(
        int(cert["c"]),
        int(cert["seed"]),
        str(cert["mode"]),
        int(cert["sparse_l_terms"]),
        int(cert["sparse_q_terms"]),
    )
    expected = cert["data"]
    m0_checks = compare_entries(observed["m0_entries"], expected["m0_entries"])
    positive_checks = compare_entries(observed["positive_entries"], expected["positive_entries"])
    checks = {
        "m0_dims_match": observed["m0_dim"] == expected["m0_dim"]
        and observed["regular_dim"] == expected["regular_dim"]
        and observed["top_dim"] == expected["top_dim"],
        "module_dims_match": observed["module_dims_M1_to_M4"] == expected["module_dims_M1_to_M4"],
        "q_quotient_meta_match": qreplay.sha256_json(observed["q_quotient_meta"])
        == qreplay.sha256_json(expected["q_quotient_meta"]),
        "m0_entries_match": all(all(row.values()) for row in m0_checks.values()),
        "positive_entries_match": all(all(row.values()) for row in positive_checks.values()),
        "m0_commutativity_match": observed["m0_commutativity"] == expected["m0_commutativity"],
        "positive_commutativity_match": observed["positive_commutativity"] == expected["positive_commutativity"],
        "all_m0_m1_squares_commute": observed["all_m0_m1_squares_commute"],
        "all_positive_squares_commute": observed["all_positive_squares_commute"],
    }
    passed = all(checks.values())
    return {
        "status": "passed" if passed else "failed",
        "certificate_type": cert["certificate_type"],
        "cicy": cert["cicy"],
        "cell": cert["cell"],
        "c": cert["c"],
        "prime": P,
        "checks": checks,
        "m0_entry_checks": m0_checks,
        "positive_entry_checks": positive_checks,
        "m0_dim": observed["m0_dim"],
        "regular_dim": observed["regular_dim"],
        "top_dim": observed["top_dim"],
        "module_dims_M1_to_M4": observed["module_dims_M1_to_M4"],
        "all_m0_m1_squares_commute": observed["all_m0_m1_squares_commute"],
        "all_positive_squares_commute": observed["all_positive_squares_commute"],
        "seconds": round(time.time() - started, 6),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--c", type=int, required=True)
    common.add_argument("--seed", type=int, default=7863)
    common.add_argument(
        "--mode",
        choices=["diagonal", "sparseL_denseQ", "random_sparse", "dense"],
        default="sparseL_denseQ",
    )
    common.add_argument("--sparse-l-terms", type=int, default=8)
    common.add_argument("--sparse-q-terms", type=int, default=20)

    gen = sub.add_parser("generate", parents=[common])
    gen.add_argument("--out", type=pathlib.Path, required=True)

    rep = sub.add_parser("replay")
    rep.add_argument("certificate", type=pathlib.Path)
    rep.add_argument("--out", type=pathlib.Path)

    args = parser.parse_args()
    if args.cmd == "generate":
        cert = make_certificate(args)
        qreplay.write_json(args.out, cert)
        print(json.dumps({"status": "generated", "path": str(args.out), "seconds": cert["seconds"]}, sort_keys=True))
    elif args.cmd == "replay":
        cert = json.loads(args.certificate.read_text())
        result = replay_certificate(cert)
        if args.out:
            qreplay.write_json(args.out, result)
        print(json.dumps(result, indent=2, sort_keys=True))
        if result["status"] != "passed":
            raise SystemExit(1)


if __name__ == "__main__":
    main()
