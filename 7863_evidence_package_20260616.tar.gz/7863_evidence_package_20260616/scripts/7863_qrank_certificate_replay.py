#!/usr/bin/env python3
"""Generate and replay strict q-rank certificates for CICY 7863 Cell 9.

The existing ``7863_reduced_q_rank_probe.py`` recomputes rank summaries.  This
script adds a stored witness layer: a certificate records the construction
parameters, a canonical hash of the rebuilt sparse matrix, pivot rows for a
full-column-rank minor, and the nonzero determinant modulo the certificate
prime.  Replay consumes that stored certificate and independently rebuilds the
matrix from the recorded recipe before checking the witness.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import pathlib
import sys
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
PROBE_PATH = ROOT / "7863_reduced_q_rank_probe.py"
SPEC = importlib.util.spec_from_file_location("qrank7863", PROBE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_reduced_q_rank_probe.py")
probe = importlib.util.module_from_spec(SPEC)
sys.modules["qrank7863"] = probe
SPEC.loader.exec_module(probe)

P = probe.P
Vector = dict[int, int]


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_columns(cols: list[Vector]) -> list[list[list[int]]]:
    return [
        [[int(row), int(value) % P] for row, value in sorted(col.items()) if value % P]
        for col in cols
    ]


def sha256_json(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def matrix_hash(cols: list[Vector]) -> str:
    return sha256_json(canonical_columns(cols))


def dense_minor(cols: list[Vector], pivot_rows: list[int]) -> list[list[int]]:
    return [
        [int(cols[col].get(row, 0)) % P for col in range(len(cols))]
        for row in pivot_rows
    ]


def det_mod_p(mat: list[list[int]], p: int) -> int:
    n = len(mat)
    if any(len(row) != n for row in mat):
        raise ValueError("determinant requires a square matrix")
    work = [[value % p for value in row] for row in mat]
    det = 1
    for col in range(n):
        pivot = None
        for row in range(col, n):
            if work[row][col] % p:
                pivot = row
                break
        if pivot is None:
            return 0
        if pivot != col:
            work[col], work[pivot] = work[pivot], work[col]
            det = (-det) % p
        pv = work[col][col] % p
        det = (det * pv) % p
        inv = pow(pv, p - 2, p)
        for row in range(col + 1, n):
            factor = work[row][col] % p
            if not factor:
                continue
            scale = factor * inv % p
            for j in range(col, n):
                work[row][j] = (work[row][j] - scale * work[col][j]) % p
    return det % p


def build_q_data(
    c: int,
    d: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    source, target, cols, max_col_fill = probe.q_columns(
        c, d, seed, mode, sparse_l_terms, sparse_q_terms
    )
    return {
        "source": source,
        "target": target,
        "cols": cols,
        "max_col_fill": max_col_fill,
    }


def pivot_rows_from_columns(cols: list[Vector]) -> list[int]:
    pivots = probe.build_pivots(cols)
    return [int(row) for row in pivots.keys()]


def make_certificate(args: argparse.Namespace) -> dict[str, Any]:
    q = build_q_data(
        args.c,
        args.d,
        args.seed,
        args.mode,
        args.sparse_l_terms,
        args.sparse_q_terms,
    )
    cols: list[Vector] = q["cols"]
    source = q["source"]
    target = q["target"]
    pivot_rows = pivot_rows_from_columns(cols)
    minor = dense_minor(cols, pivot_rows)
    det = det_mod_p(minor, P)
    if len(pivot_rows) != source.dim or det == 0:
        raise RuntimeError("generated witness does not prove full-column rank")
    return {
        "certificate_type": "cicy_7863_cell9_reduced_q_rank_full_column_rank_v1",
        "statement": "q_d: B(c-2,d-2) -> B(c,d) has full column rank over F_p",
        "cicy": 7863,
        "cell": 9,
        "c": args.c,
        "d": args.d,
        "prime": P,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "construction": {
            "map": "q_d",
            "source": {
                "name": "B(c-2,d-2)",
                "n": source.n,
                "t": source.t,
                "ambient_dim": source.ambient_dim,
                "relation_rank": source.relation_rank,
                "dim": source.dim,
                "free_rows_sha256": sha256_json(list(source.free_rows)),
            },
            "target": {
                "name": "B(c,d)",
                "n": target.n,
                "t": target.t,
                "ambient_dim": target.ambient_dim,
                "relation_rank": target.relation_rank,
                "dim": target.dim,
                "free_rows_sha256": sha256_json(list(target.free_rows)),
            },
            "matrix_rows": target.dim,
            "matrix_cols": source.dim,
            "max_col_fill_after_br": q["max_col_fill"],
            "matrix_sparse_columns_sha256": matrix_hash(cols),
        },
        "witness": {
            "kind": "full_column_rank_minor_mod_p",
            "pivot_rows": pivot_rows,
            "column_order": "source quotient basis order 0..matrix_cols-1",
            "det_mod_p": det,
        },
        "source_files": {
            "generator_checker": str(pathlib.Path(__file__).name),
            "generator_checker_sha256": sha256_file(pathlib.Path(__file__)),
            "matrix_recipe": str(PROBE_PATH.name),
            "matrix_recipe_sha256": sha256_file(PROBE_PATH),
        },
        "created_unix_time": time.time(),
    }


def replay_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    required_type = "cicy_7863_cell9_reduced_q_rank_full_column_rank_v1"
    if cert.get("certificate_type") != required_type:
        raise ValueError("unexpected certificate_type")
    if cert.get("prime") != P:
        raise ValueError("certificate prime does not match checker prime")
    q = build_q_data(
        int(cert["c"]),
        int(cert["d"]),
        int(cert["seed"]),
        str(cert["mode"]),
        int(cert["sparse_l_terms"]),
        int(cert["sparse_q_terms"]),
    )
    cols: list[Vector] = q["cols"]
    source = q["source"]
    target = q["target"]
    construction = cert["construction"]
    witness = cert["witness"]
    observed_matrix_hash = matrix_hash(cols)
    pivot_rows = [int(row) for row in witness["pivot_rows"]]
    minor = dense_minor(cols, pivot_rows)
    observed_det = det_mod_p(minor, P)
    checks = {
        "matrix_rows_match": target.dim == int(construction["matrix_rows"]),
        "matrix_cols_match": source.dim == int(construction["matrix_cols"]),
        "source_dim_match": source.dim == int(construction["source"]["dim"]),
        "target_dim_match": target.dim == int(construction["target"]["dim"]),
        "source_free_rows_hash_match": sha256_json(list(source.free_rows))
        == construction["source"]["free_rows_sha256"],
        "target_free_rows_hash_match": sha256_json(list(target.free_rows))
        == construction["target"]["free_rows_sha256"],
        "matrix_hash_match": observed_matrix_hash
        == construction["matrix_sparse_columns_sha256"],
        "pivot_row_count_match": len(pivot_rows) == source.dim,
        "pivot_rows_in_bounds": all(0 <= row < target.dim for row in pivot_rows),
        "determinant_matches_certificate": observed_det == int(witness["det_mod_p"]),
        "determinant_nonzero": observed_det % P != 0,
        "structural_upper_bound": source.dim == len(cols),
    }
    passed = all(checks.values())
    return {
        "status": "passed" if passed else "failed",
        "certificate_type": cert["certificate_type"],
        "cicy": cert["cicy"],
        "cell": cert["cell"],
        "c": cert["c"],
        "d": cert["d"],
        "prime": P,
        "matrix_rows": target.dim,
        "matrix_cols": source.dim,
        "rank_lower_bound_from_minor": source.dim if checks["determinant_nonzero"] else 0,
        "rank_upper_bound_from_source_dim": source.dim,
        "full_column_rank": passed,
        "observed_det_mod_p": observed_det,
        "observed_matrix_sparse_columns_sha256": observed_matrix_hash,
        "checks": checks,
    }


def write_json(path: pathlib.Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--c", type=int, required=True)
    common.add_argument("--d", type=int, required=True)
    common.add_argument("--seed", type=int, default=7863)
    common.add_argument(
        "--mode",
        choices=["diagonal", "sparseL_denseQ", "random_sparse", "dense"],
        default="sparseL_denseQ",
    )
    common.add_argument("--sparse-l-terms", type=int, default=8)
    common.add_argument("--sparse-q-terms", type=int, default=20)

    gen = sub.add_parser("generate", parents=[common])
    gen.add_argument("--out", type=pathlib.Path, required=True)

    rep = sub.add_parser("replay")
    rep.add_argument("certificate", type=pathlib.Path)
    rep.add_argument("--out", type=pathlib.Path)

    args = parser.parse_args()
    if args.cmd == "generate":
        cert = make_certificate(args)
        write_json(args.out, cert)
        print(json.dumps({"status": "generated", "path": str(args.out)}, sort_keys=True))
    elif args.cmd == "replay":
        cert = json.loads(args.certificate.read_text())
        result = replay_certificate(cert)
        if args.out:
            write_json(args.out, result)
        print(json.dumps(result, indent=2, sort_keys=True))
        if result["status"] != "passed":
            raise SystemExit(1)


if __name__ == "__main__":
    main()
