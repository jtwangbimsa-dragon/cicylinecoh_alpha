#!/usr/bin/env python3
"""Generate and replay full reduced Koszul rank certificates for CICY 7863.

This is a strict Python replay layer for the finite-field full-Koszul data used
in the Cell 9 reduced endpoint calculation.  A certificate stores the recipe,
module dimensions, sparse matrix hashes, exact ranks, and pivot-row hashes for
the ten Koszul differentials.  Replay consumes the stored certificate, rebuilds
the matrices, recomputes exact ranks over F_1000003, checks complex
compositions, and recomputes the homology table.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import sys
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
QREPLAY_PATH = ROOT / "7863_qrank_certificate_replay.py"
SPEC = importlib.util.spec_from_file_location("qreplay7863", QREPLAY_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_qrank_certificate_replay.py")
qreplay = importlib.util.module_from_spec(SPEC)
sys.modules["qreplay7863"] = qreplay
SPEC.loader.exec_module(qreplay)

probe = qreplay.probe
P = qreplay.P
Vector = dict[int, int]


def rank_entry(name: str, rows: int, cols: list[Vector]) -> dict[str, Any]:
    pivots = probe.build_pivots(cols)
    pivot_rows = [int(row) for row in pivots.keys()]
    return {
        "name": name,
        "rows": int(rows),
        "cols": len(cols),
        "rank": len(pivots),
        "matrix_sparse_columns_sha256": qreplay.matrix_hash(cols),
        "pivot_rows_sha256": qreplay.sha256_json(pivot_rows),
    }


def target_rows(module_dims: dict[int, int], r: int, d: int) -> int:
    return len(probe.wedge_basis(r - 1)) * module_dims[d + 1]


def build_full_koszul(c: int, seed: int, mode: str, sparse_l_terms: int, sparse_q_terms: int) -> dict[str, Any]:
    modules, _q_meta = probe.build_positive_modules(c, seed, mode, sparse_l_terms, sparse_q_terms)
    module_dims = {0: probe.pbinom(c) + probe.pbinom(c - 4)}
    module_dims.update({d: modules[d].dim for d in range(1, 5)})

    mu: dict[int, dict[int, list[Vector]]] = {0: {}}
    for x_var in range(4):
        mu[0][x_var] = probe.mu0_columns(c, x_var, seed, mode, sparse_l_terms, sparse_q_terms)
    for d in (1, 2, 3):
        mu[d] = {}
        for x_var in range(4):
            mu[d][x_var] = probe.positive_mu_columns(modules, d, x_var)

    matrix_specs = [
        ("d_WM0_to_M1", 1, 0),
        ("d_L2M0_to_WM1", 2, 0),
        ("d_WM1_to_M2", 1, 1),
        ("d_L3M0_to_L2M1", 3, 0),
        ("d_L2M1_to_WM2", 2, 1),
        ("d_WM2_to_M3", 1, 2),
        ("d_L4M0_to_L3M1", 4, 0),
        ("d_L3M1_to_L2M2", 3, 1),
        ("d_L2M2_to_WM3", 2, 2),
        ("d_WM3_to_M4", 1, 3),
    ]
    matrices: dict[str, list[Vector]] = {}
    entries: list[dict[str, Any]] = []
    ranks: dict[str, int] = {}
    for name, r, d in matrix_specs:
        cols = probe.koszul_diff_columns(r, d, module_dims, mu)
        matrices[name] = cols
        entry = rank_entry(name, target_rows(module_dims, r, d), cols)
        entry["source"] = {"wedge_rank": r, "module_degree": d}
        entries.append(entry)
        ranks[name] = entry["rank"]

    d10 = matrices["d_WM0_to_M1"]
    d20 = matrices["d_L2M0_to_WM1"]
    d11 = matrices["d_WM1_to_M2"]
    d30 = matrices["d_L3M0_to_L2M1"]
    d21 = matrices["d_L2M1_to_WM2"]
    d12 = matrices["d_WM2_to_M3"]
    d40 = matrices["d_L4M0_to_L3M1"]
    d31 = matrices["d_L3M1_to_L2M2"]
    d22 = matrices["d_L2M2_to_WM3"]
    d13 = matrices["d_WM3_to_M4"]

    h_deg1 = {
        "H1": len(d10) - ranks["d_WM0_to_M1"],
        "H0": module_dims[1] - ranks["d_WM0_to_M1"],
    }
    h_deg2 = {
        "H2": len(d20) - ranks["d_L2M0_to_WM1"],
        "H1": len(d11) - ranks["d_WM1_to_M2"] - ranks["d_L2M0_to_WM1"],
        "H0": module_dims[2] - ranks["d_WM1_to_M2"],
    }
    h_deg3 = {
        "H3": len(d30) - ranks["d_L3M0_to_L2M1"],
        "H2": len(d21) - ranks["d_L2M1_to_WM2"] - ranks["d_L3M0_to_L2M1"],
        "H1": len(d12) - ranks["d_WM2_to_M3"] - ranks["d_L2M1_to_WM2"],
        "H0": module_dims[3] - ranks["d_WM2_to_M3"],
    }
    h_deg4 = {
        "H4": len(d40) - ranks["d_L4M0_to_L3M1"],
        "H3": len(d31) - ranks["d_L3M1_to_L2M2"] - ranks["d_L4M0_to_L3M1"],
        "H2": len(d22) - ranks["d_L2M2_to_WM3"] - ranks["d_L3M1_to_L2M2"],
        "H1": len(d13) - ranks["d_WM3_to_M4"] - ranks["d_L2M2_to_WM3"],
        "H0": module_dims[4] - ranks["d_WM3_to_M4"],
    }

    def euler(homology: dict[str, int]) -> int:
        total = 0
        for key, value in homology.items():
            total += ((-1) ** int(key[1:])) * value
        return total

    complex_checks = {
        "d11_after_d20_nonzero_cols": probe.composition_nonzero_count(d11, d20),
        "d21_after_d30_nonzero_cols": probe.composition_nonzero_count(d21, d30),
        "d12_after_d21_nonzero_cols": probe.composition_nonzero_count(d12, d21),
        "d31_after_d40_nonzero_cols": probe.composition_nonzero_count(d31, d40),
        "d22_after_d31_nonzero_cols": probe.composition_nonzero_count(d22, d31),
        "d13_after_d22_nonzero_cols": probe.composition_nonzero_count(d13, d22),
    }

    homology = {
        "degree_1": h_deg1,
        "degree_2": h_deg2,
        "degree_3": h_deg3,
        "degree_4": h_deg4,
    }
    return {
        "module_dims_M0_to_M4": {str(d): module_dims[d] for d in range(5)},
        "rank_entries": entries,
        "ranks": ranks,
        "koszul_homology_by_degree": homology,
        "numerator_coefficients_from_euler": {
            "degree_1": euler(h_deg1),
            "degree_2": euler(h_deg2),
            "degree_3": euler(h_deg3),
            "degree_4": euler(h_deg4),
        },
        "complex_checks": complex_checks,
    }


def make_certificate(args: argparse.Namespace) -> dict[str, Any]:
    started = time.time()
    data = build_full_koszul(args.c, args.seed, args.mode, args.sparse_l_terms, args.sparse_q_terms)
    return {
        "certificate_type": "cicy_7863_cell9_full_koszul_exact_rank_v1",
        "statement": "full reduced Koszul differential ranks and homology over F_p",
        "cicy": 7863,
        "cell": 9,
        "c": args.c,
        "prime": P,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "data": data,
        "source_files": {
            "generator_checker": pathlib.Path(__file__).name,
            "generator_checker_sha256": qreplay.sha256_file(pathlib.Path(__file__)),
            "qrank_replay_helper": QREPLAY_PATH.name,
            "qrank_replay_helper_sha256": qreplay.sha256_file(QREPLAY_PATH),
            "matrix_recipe": qreplay.PROBE_PATH.name,
            "matrix_recipe_sha256": qreplay.sha256_file(qreplay.PROBE_PATH),
        },
        "seconds": round(time.time() - started, 6),
    }


def replay_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    started = time.time()
    if cert.get("certificate_type") != "cicy_7863_cell9_full_koszul_exact_rank_v1":
        raise ValueError("unexpected certificate_type")
    if int(cert["prime"]) != P:
        raise ValueError("prime mismatch")
    observed = build_full_koszul(
        int(cert["c"]),
        int(cert["seed"]),
        str(cert["mode"]),
        int(cert["sparse_l_terms"]),
        int(cert["sparse_q_terms"]),
    )
    expected = cert["data"]
    expected_entries = {entry["name"]: entry for entry in expected["rank_entries"]}
    observed_entries = {entry["name"]: entry for entry in observed["rank_entries"]}
    rank_checks = {}
    for name, exp in expected_entries.items():
        obs = observed_entries[name]
        rank_checks[name] = {
            "rows_match": obs["rows"] == exp["rows"],
            "cols_match": obs["cols"] == exp["cols"],
            "rank_match": obs["rank"] == exp["rank"],
            "matrix_hash_match": obs["matrix_sparse_columns_sha256"] == exp["matrix_sparse_columns_sha256"],
            "pivot_rows_hash_match": obs["pivot_rows_sha256"] == exp["pivot_rows_sha256"],
        }
    checks = {
        "module_dims_match": observed["module_dims_M0_to_M4"] == expected["module_dims_M0_to_M4"],
        "ranks_match": observed["ranks"] == expected["ranks"],
        "homology_match": observed["koszul_homology_by_degree"] == expected["koszul_homology_by_degree"],
        "euler_match": observed["numerator_coefficients_from_euler"] == expected["numerator_coefficients_from_euler"],
        "complex_checks_match": observed["complex_checks"] == expected["complex_checks"],
        "complex_compositions_zero": all(value == 0 for value in observed["complex_checks"].values()),
        "rank_entries_match": all(all(row.values()) for row in rank_checks.values()),
    }
    passed = all(checks.values())
    return {
        "status": "passed" if passed else "failed",
        "certificate_type": cert["certificate_type"],
        "cicy": cert["cicy"],
        "cell": cert["cell"],
        "c": cert["c"],
        "prime": P,
        "checks": checks,
        "rank_checks": rank_checks,
        "ranks": observed["ranks"],
        "module_dims_M0_to_M4": observed["module_dims_M0_to_M4"],
        "koszul_homology_by_degree": observed["koszul_homology_by_degree"],
        "numerator_coefficients_from_euler": observed["numerator_coefficients_from_euler"],
        "complex_checks": observed["complex_checks"],
        "seconds": round(time.time() - started, 6),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--c", type=int, required=True)
    common.add_argument("--seed", type=int, default=7863)
    common.add_argument(
        "--mode",
        choices=["diagonal", "sparseL_denseQ", "random_sparse", "dense"],
        default="sparseL_denseQ",
    )
    common.add_argument("--sparse-l-terms", type=int, default=8)
    common.add_argument("--sparse-q-terms", type=int, default=20)

    gen = sub.add_parser("generate", parents=[common])
    gen.add_argument("--out", type=pathlib.Path, required=True)

    rep = sub.add_parser("replay")
    rep.add_argument("certificate", type=pathlib.Path)
    rep.add_argument("--out", type=pathlib.Path)

    args = parser.parse_args()
    if args.cmd == "generate":
        cert = make_certificate(args)
        qreplay.write_json(args.out, cert)
        print(json.dumps({"status": "generated", "path": str(args.out), "seconds": cert["seconds"]}, sort_keys=True))
    elif args.cmd == "replay":
        cert = json.loads(args.certificate.read_text())
        result = replay_certificate(cert)
        if args.out:
            qreplay.write_json(args.out, result)
        print(json.dumps(result, indent=2, sort_keys=True))
        if result["status"] != "passed":
            raise SystemExit(1)


if __name__ == "__main__":
    main()
