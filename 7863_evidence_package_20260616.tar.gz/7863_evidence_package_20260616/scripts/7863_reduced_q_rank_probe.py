#!/usr/bin/env python3
"""Reduced q_d rank probe for CICY 7863 Cell 9.

This implements the positive-degree part of the reduced E/q certificate:

    B(n,t) = H^0(Sym^n E(t))
           = coker((R_{t-1} Sym^{n-1} V)^2 -> R_t Sym^n V),

then checks that multiplication by Q gives full-column-rank maps

    q_d: B(c-2,d-2) -> B(c,d),  d=2,3,4.

It intentionally does not implement the M_0 Cech/top correction.  That part is
needed for the full Koszul certificate, but not for these injectivity checks.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import time
from dataclasses import dataclass
from functools import lru_cache
from math import comb
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("endpoint7863", ROOT / "7863_endpoint_nc_probe.py")
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_endpoint_nc_probe.py")
endpoint = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(endpoint)

P = endpoint.P
Vector = dict[int, int]
Exp = tuple[int, int, int, int]
CechKey = tuple[tuple[int, ...], Exp, Exp, int]
Cech = dict[CechKey, int]
CechTuple = tuple[Cech, Cech, Cech]


def add_value(vec: Vector, idx: int, value: int) -> None:
    value %= P
    if not value:
        return
    new = (vec.get(idx, 0) + value) % P
    if new:
        vec[idx] = new
    else:
        vec.pop(idx, None)


def vector_add_scaled(dst: Vector, src: Vector, scalar: int) -> None:
    scalar %= P
    if not scalar:
        return
    for i, v in src.items():
        add_value(dst, i, scalar * v)


def vector_scale(vec: Vector, scalar: int) -> Vector:
    scalar %= P
    if not scalar:
        return {}
    return {i: (scalar * v) % P for i, v in vec.items() if v % P}


def add_exp(a: Exp, b: Exp) -> Exp:
    return tuple(x + y for x, y in zip(a, b))  # type: ignore[return-value]


def exp_degree(a: Exp) -> int:
    return sum(a)


def pbinom(r: int) -> int:
    return comb(r + 3, 3) if r >= 0 else 0


def h_sym_e(n: int, t: int) -> int:
    if n < 0 or t < 0:
        return 0
    return pbinom(n) * pbinom(t) - 2 * pbinom(n - 1) * pbinom(t - 1) + pbinom(n - 2) * pbinom(t - 2)


def build_pivots(vecs: list[Vector]) -> dict[int, Vector]:
    pivots: dict[int, Vector] = {}
    for raw in vecs:
        vec = {i: v % P for i, v in raw.items() if v % P}
        while vec:
            pc = min(vec)
            pv = vec[pc] % P
            prow = pivots.get(pc)
            if prow is None:
                inv = pow(pv, P - 2, P)
                pivots[pc] = vector_scale(vec, inv)
                break
            vector_add_scaled(vec, prow, -pv)
    return pivots


def reduce_by_pivots(vec: Vector, pivots: dict[int, Vector]) -> Vector:
    out = {i: v % P for i, v in vec.items() if v % P}
    while out:
        candidates = [i for i in out if i in pivots]
        if not candidates:
            return out
        pc = min(candidates)
        pv = out[pc] % P
        vector_add_scaled(out, pivots[pc], -pv)
    return out


def rank_of_columns(cols: list[Vector]) -> int:
    return len(build_pivots(cols))


@dataclass
class BRSpace:
    n: int
    t: int
    x_basis: tuple[Exp, ...]
    y_basis: tuple[Exp, ...]
    pivots: dict[int, Vector]
    free_rows: tuple[int, ...]
    free_index: dict[int, int]
    ambient_dim: int
    relation_rank: int

    @property
    def dim(self) -> int:
        return len(self.free_rows)

    def ambient_index(self, x_exp: Exp, y_exp: Exp) -> int:
        return self._x_index[x_exp] * len(self.y_basis) + self._y_index[y_exp]

    def reduce_br(self, vec: Vector) -> Vector:
        reduced = reduce_by_pivots(vec, self.pivots)
        out: Vector = {}
        for row, value in reduced.items():
            qidx = self.free_index.get(row)
            if qidx is None:
                raise RuntimeError(f"BR reduction left pivot row {row} in B({self.n},{self.t})")
            add_value(out, qidx, value)
        return out

    def lift_basis_vector(self, quotient_index: int) -> Vector:
        return {self.free_rows[quotient_index]: 1}

    def attach_indexes(self) -> None:
        self._x_index = {exp: i for i, exp in enumerate(self.x_basis)}
        self._y_index = {exp: i for i, exp in enumerate(self.y_basis)}


@dataclass
class QuotientSpace:
    """A quotient of a coordinate space by a column span."""

    base_dim: int
    pivots: dict[int, Vector]
    free_rows: tuple[int, ...]
    free_index: dict[int, int]

    @property
    def dim(self) -> int:
        return len(self.free_rows)

    @property
    def relation_rank(self) -> int:
        return len(self.pivots)

    def reduce(self, vec: Vector) -> Vector:
        reduced = reduce_by_pivots(vec, self.pivots)
        out: Vector = {}
        for row, value in reduced.items():
            qidx = self.free_index.get(row)
            if qidx is None:
                raise RuntimeError(f"quotient reduction left pivot row {row}")
            add_value(out, qidx, value)
        return out

    def lift_basis_vector(self, quotient_index: int) -> Vector:
        return {self.free_rows[quotient_index]: 1}


@dataclass
class ModuleSpace:
    """M_d represented as a quotient of B(c,d)."""

    d: int
    b_space: BRSpace
    quotient: QuotientSpace

    @property
    def dim(self) -> int:
        return self.quotient.dim

    def reduce_b(self, b_vec: Vector) -> Vector:
        return self.quotient.reduce(b_vec)

    def lift_basis_to_b(self, quotient_index: int) -> Vector:
        return self.quotient.lift_basis_vector(quotient_index)


def quotient_space(base_dim: int, relation_cols: list[Vector] | None = None) -> QuotientSpace:
    pivots = build_pivots(relation_cols or [])
    free_rows = tuple(i for i in range(base_dim) if i not in pivots)
    return QuotientSpace(
        base_dim=base_dim,
        pivots=pivots,
        free_rows=free_rows,
        free_index={row: i for i, row in enumerate(free_rows)},
    )


def relation_columns(
    n: int,
    t: int,
    l_terms: tuple[list[tuple[int, Exp, Exp]], list[tuple[int, Exp, Exp]]],
    x_basis: tuple[Exp, ...],
    y_basis: tuple[Exp, ...],
) -> list[Vector]:
    if n <= 0 or t <= 0:
        return []
    src_x = endpoint.monoms_deg(t - 1)
    src_y = endpoint.monoms_deg(n - 1)
    x_index = {exp: i for i, exp in enumerate(x_basis)}
    y_index = {exp: i for i, exp in enumerate(y_basis)}
    cols: list[Vector] = []
    for terms in l_terms:
        for x_exp in src_x:
            for y_exp in src_y:
                col: Vector = {}
                for coeff, lx, ly in terms:
                    tx = add_exp(x_exp, lx)
                    ty = add_exp(y_exp, ly)
                    row = x_index[tx] * len(y_basis) + y_index[ty]
                    add_value(col, row, coeff)
                cols.append(col)
    return cols


@lru_cache(maxsize=None)
def build_br_space_cached(
    n: int,
    t: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> BRSpace:
    if n < 0 or t < 0:
        raise ValueError("BR space needs n,t >= 0")
    l1, l2, _q_terms = endpoint.terms(seed, mode, sparse_l_terms, sparse_q_terms)
    x_basis = endpoint.monoms_deg(t)
    y_basis = endpoint.monoms_deg(n)
    ambient_dim = len(x_basis) * len(y_basis)
    rel_cols = relation_columns(n, t, (l1, l2), x_basis, y_basis)
    pivots = build_pivots(rel_cols)
    free_rows = tuple(i for i in range(ambient_dim) if i not in pivots)
    space = BRSpace(
        n=n,
        t=t,
        x_basis=x_basis,
        y_basis=y_basis,
        pivots=pivots,
        free_rows=free_rows,
        free_index={row: i for i, row in enumerate(free_rows)},
        ambient_dim=ambient_dim,
        relation_rank=len(pivots),
    )
    space.attach_indexes()
    return space


def build_br_space(
    n: int,
    t: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> BRSpace:
    return build_br_space_cached(n, t, seed, mode, sparse_l_terms, sparse_q_terms)


def multiply_q_column(
    source_ambient: Vector,
    source: BRSpace,
    target: BRSpace,
    q_terms: list[tuple[int, Exp, Exp]],
) -> Vector:
    out: Vector = {}
    for row, scalar in source_ambient.items():
        x_pos = row // len(source.y_basis)
        y_pos = row % len(source.y_basis)
        x_exp = source.x_basis[x_pos]
        y_exp = source.y_basis[y_pos]
        for coeff, qx, qy in q_terms:
            tx = add_exp(x_exp, qx)
            ty = add_exp(y_exp, qy)
            target_row = target.ambient_index(tx, ty)
            add_value(out, target_row, scalar * coeff)
    return out


def multiply_x_ambient(source_ambient: Vector, source: BRSpace, target: BRSpace, x_var: int) -> Vector:
    out: Vector = {}
    x_op = tuple(1 if i == x_var else 0 for i in range(4))  # type: ignore[assignment]
    for row, scalar in source_ambient.items():
        x_pos = row // len(source.y_basis)
        y_pos = row % len(source.y_basis)
        x_exp = source.x_basis[x_pos]
        y_exp = source.y_basis[y_pos]
        tx = add_exp(x_exp, x_op)
        target_row = target.ambient_index(tx, y_exp)
        add_value(out, target_row, scalar)
    return out


def lift_b_to_ambient(b_vec: Vector, b_space: BRSpace) -> Vector:
    out: Vector = {}
    for b_idx, value in b_vec.items():
        add_value(out, b_space.free_rows[b_idx], value)
    return out


def q_columns(
    c: int,
    d: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> tuple[BRSpace, BRSpace, list[Vector], int]:
    _l1, _l2, q_terms = endpoint.terms(seed, mode, sparse_l_terms, sparse_q_terms)
    source = build_br_space(c - 2, d - 2, seed, mode, sparse_l_terms, sparse_q_terms)
    target = build_br_space(c, d, seed, mode, sparse_l_terms, sparse_q_terms)
    cols: list[Vector] = []
    max_col_fill = 0
    for j in range(source.dim):
        ambient = source.lift_basis_vector(j)
        image = multiply_q_column(ambient, source, target, q_terms)
        reduced = target.reduce_br(image)
        max_col_fill = max(max_col_fill, len(reduced))
        cols.append(reduced)
    return source, target, cols, max_col_fill


def q_rank(
    c: int,
    d: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    source, target, cols, max_col_fill = q_columns(c, d, seed, mode, sparse_l_terms, sparse_q_terms)
    rank = rank_of_columns(cols)
    return {
        "d": d,
        "source_B": {
            "n": source.n,
            "t": source.t,
            "ambient_dim": source.ambient_dim,
            "relation_rank": source.relation_rank,
            "dim": source.dim,
            "expected_dim": h_sym_e(source.n, source.t),
        },
        "target_B": {
            "n": target.n,
            "t": target.t,
            "ambient_dim": target.ambient_dim,
            "relation_rank": target.relation_rank,
            "dim": target.dim,
            "expected_dim": h_sym_e(target.n, target.t),
        },
        "matrix_rows": target.dim,
        "matrix_cols": source.dim,
        "rank": rank,
        "target_rank": source.dim,
        "full_column_rank": rank == source.dim,
        "max_col_fill_after_br": max_col_fill,
    }


def build_positive_modules(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> tuple[dict[int, ModuleSpace], dict[int, dict[str, Any]]]:
    b_spaces = {
        d: build_br_space(c, d, seed, mode, sparse_l_terms, sparse_q_terms)
        for d in range(1, 5)
    }
    modules: dict[int, ModuleSpace] = {
        1: ModuleSpace(1, b_spaces[1], quotient_space(b_spaces[1].dim))
    }
    q_meta: dict[int, dict[str, Any]] = {}
    for d in range(2, 5):
        _source, target, cols, max_col_fill = q_columns(c, d, seed, mode, sparse_l_terms, sparse_q_terms)
        q_quotient = quotient_space(target.dim, cols)
        modules[d] = ModuleSpace(d, target, q_quotient)
        q_meta[d] = {
            "image_rank": q_quotient.relation_rank,
            "image_cols": len(cols),
            "target_dim": target.dim,
            "module_dim": modules[d].dim,
            "max_col_fill_after_br": max_col_fill,
        }
    return modules, q_meta


def positive_mu_columns(modules: dict[int, ModuleSpace], d: int, x_var: int) -> list[Vector]:
    source_m = modules[d]
    target_m = modules[d + 1]
    cols: list[Vector] = []
    for j in range(source_m.dim):
        source_b = source_m.lift_basis_to_b(j)
        source_ambient = lift_b_to_ambient(source_b, source_m.b_space)
        target_ambient = multiply_x_ambient(source_ambient, source_m.b_space, target_m.b_space, x_var)
        target_b = target_m.b_space.reduce_br(target_ambient)
        cols.append(target_m.reduce_b(target_b))
    return cols


def compose_columns(left: list[Vector], right: list[Vector]) -> list[Vector]:
    """Compose source --right--> middle --left--> target."""
    out: list[Vector] = []
    for col in right:
        composed: Vector = {}
        for mid_idx, coeff in col.items():
            vector_add_scaled(composed, left[mid_idx], coeff)
        out.append(composed)
    return out


def apply_columns(cols: list[Vector], vec: Vector) -> Vector:
    out: Vector = {}
    for idx, coeff in vec.items():
        vector_add_scaled(out, cols[idx], coeff)
    return out


def columns_equal(a: list[Vector], b: list[Vector]) -> bool:
    if len(a) != len(b):
        return False
    return all(
        {i: v % P for i, v in x.items() if v % P}
        == {i: v % P for i, v in y.items() if v % P}
        for x, y in zip(a, b)
    )


def wedge_basis(r: int) -> list[tuple[int, ...]]:
    if r == 0:
        return [()]
    out: list[tuple[int, ...]] = []

    def rec(start: int, acc: list[int]) -> None:
        if len(acc) == r:
            out.append(tuple(acc))
            return
        for i in range(start, 4):
            rec(i + 1, acc + [i])

    rec(0, [])
    return out


def koszul_diff_columns(
    r: int,
    d: int,
    module_dims: dict[int, int],
    mu: dict[int, dict[int, list[Vector]]],
) -> list[Vector]:
    """Columns for Λ^r W ⊗ M_d -> Λ^{r-1} W ⊗ M_{d+1}."""
    if r <= 0:
        return []
    source_wedges = wedge_basis(r)
    target_wedges = wedge_basis(r - 1)
    target_wedge_index = {wedge: i for i, wedge in enumerate(target_wedges)}
    source_dim = module_dims[d]
    target_dim = module_dims[d + 1]
    cols: list[Vector] = []
    for wedge in source_wedges:
        for m_idx in range(source_dim):
            col: Vector = {}
            for pos, x_var in enumerate(wedge):
                target_wedge = tuple(v for v in wedge if v != x_var)
                sign = -1 if pos % 2 else 1
                offset = target_wedge_index[target_wedge] * target_dim
                image = mu[d][x_var][m_idx]
                for row, value in image.items():
                    add_value(col, offset + row, sign * value)
            cols.append(col)
    return cols


def composition_nonzero_count(left: list[Vector], right: list[Vector]) -> int:
    count = 0
    for col in right:
        if apply_columns(left, col):
            count += 1
    return count


def cech_add_value(cochain: Cech, key: CechKey, value: int) -> None:
    value %= P
    if not value:
        return
    new = (cochain.get(key, 0) + value) % P
    if new:
        cochain[key] = new
    else:
        cochain.pop(key, None)


def cech_scale(cochain: Cech, scalar: int) -> Cech:
    scalar %= P
    if not scalar:
        return {}
    return {key: (value * scalar) % P for key, value in cochain.items() if value % P}


def cech_add_scaled(dst: Cech, src: Cech, scalar: int) -> None:
    scalar %= P
    if not scalar:
        return
    for key, value in src.items():
        cech_add_value(dst, key, scalar * value)


def cech_tuple_scale(tup: CechTuple, scalar: int) -> CechTuple:
    return tuple(cech_scale(part, scalar) for part in tup)  # type: ignore[return-value]


def cech_tuple_add(a: CechTuple, b: CechTuple) -> CechTuple:
    out = tuple(dict(part) for part in a)  # type: ignore[assignment]
    for i in range(3):
        cech_add_scaled(out[i], b[i], 1)
    return out  # type: ignore[return-value]


def cech_kappa(cochain: Cech) -> Cech:
    out: Cech = {}
    for (subset, x_exp, y_exp, comp), value in cochain.items():
        non_negative = [i for i, exponent in enumerate(x_exp) if exponent >= 0]
        if not non_negative:
            raise RuntimeError(f"kappa called on top-supported Laurent monomial {x_exp}")
        r = min(non_negative)
        if r not in subset:
            continue
        pos = subset.index(r)
        sign = -1 if pos % 2 else 1
        new_subset = tuple(i for i in subset if i != r)
        cech_add_value(out, (new_subset, x_exp, y_exp, comp), sign * value)
    return out


def cech_delta(cochain: Cech) -> Cech:
    out: Cech = {}
    for (subset, x_exp, y_exp, comp), value in cochain.items():
        remaining = [i for i in range(4) if i not in subset]
        for r in remaining:
            new_subset = tuple(sorted(subset + (r,)))
            pos = new_subset.index(r)
            sign = -1 if pos % 2 else 1
            cech_add_value(out, (new_subset, x_exp, y_exp, comp), sign * value)
    return out


def cech_nonzero_count(cochain: Cech) -> int:
    return sum(1 for value in cochain.values() if value % P)


def cech_residual_add(a: Cech, b: Cech, scalar: int = 1) -> Cech:
    out = dict(a)
    cech_add_scaled(out, b, scalar)
    return out


def descend_residual_counts(
    z_level2: Cech,
    descended: CechTuple,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> dict[str, int]:
    b2, b1, b0 = descended
    top = cech_residual_add(cech_delta(b2), z_level2, -1)
    mid = cech_residual_add(br_d2_cech(b2, l1_terms, l2_terms), cech_delta(b1), 1)
    low = cech_residual_add(cech_delta(b0), br_d1_cech(b1, l1_terms, l2_terms), -1)
    return {
        "delta_b2_minus_z": cech_nonzero_count(top),
        "d2_b2_plus_delta_b1": cech_nonzero_count(mid),
        "delta_b0_minus_d1_b1": cech_nonzero_count(low),
    }


def total_cocycle_residual_counts(
    beta: CechTuple,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> dict[str, int]:
    beta2, beta1, beta0 = beta
    top = cech_delta(beta2)
    mid = cech_residual_add(br_d2_cech(beta2, l1_terms, l2_terms), cech_delta(beta1), 1)
    low = cech_residual_add(cech_delta(beta0), br_d1_cech(beta1, l1_terms, l2_terms), -1)
    return {
        "delta_beta2": cech_nonzero_count(top),
        "d2_beta2_plus_delta_beta1": cech_nonzero_count(mid),
        "delta_beta0_minus_d1_beta1": cech_nonzero_count(low),
    }


def total_degree_one_cocycle_residual_counts(
    alpha: CechTuple,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> dict[str, int]:
    alpha2, alpha1, alpha0 = alpha
    top = cech_delta(alpha2)
    mid = cech_residual_add(cech_delta(alpha1), br_d2_cech(alpha2, l1_terms, l2_terms), -1)
    low = cech_residual_add(cech_delta(alpha0), br_d1_cech(alpha1, l1_terms, l2_terms), 1)
    return {
        "delta_alpha2": cech_nonzero_count(top),
        "delta_alpha1_minus_d2_alpha2": cech_nonzero_count(mid),
        "delta_alpha0_plus_d1_alpha1": cech_nonzero_count(low),
    }


def total_boundary_residual_counts(
    rhs: CechTuple,
    candidate: CechTuple,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> dict[str, int]:
    z2, z1, z0 = rhs
    b2, b1, b0 = candidate
    top = cech_residual_add(cech_delta(b2), z2, -1)
    mid = cech_residual_add(br_d2_cech(b2, l1_terms, l2_terms), cech_delta(b1), 1)
    cech_add_scaled(mid, z1, -1)
    low = cech_residual_add(cech_delta(b0), br_d1_cech(b1, l1_terms, l2_terms), -1)
    cech_add_scaled(low, z0, -1)
    return {
        "delta_b2_minus_z2": cech_nonzero_count(top),
        "d2_b2_plus_delta_b1_minus_z1": cech_nonzero_count(mid),
        "delta_b0_minus_d1_b1_minus_z0": cech_nonzero_count(low),
    }


def cech_multiply_x(cochain: Cech, x_var: int) -> Cech:
    x_op = tuple(1 if i == x_var else 0 for i in range(4))  # type: ignore[assignment]
    out: Cech = {}
    for (subset, x_exp, y_exp, comp), value in cochain.items():
        cech_add_value(out, (subset, add_exp(x_exp, x_op), y_exp, comp), value)
    return out


def cech_tuple_multiply_x(tup: CechTuple, x_var: int) -> CechTuple:
    return tuple(cech_multiply_x(part, x_var) for part in tup)  # type: ignore[return-value]


def cech_multiply_q(cochain: Cech, q_terms: list[tuple[int, Exp, Exp]]) -> Cech:
    out: Cech = {}
    for (subset, x_exp, y_exp, comp), value in cochain.items():
        for coeff, qx, qy in q_terms:
            cech_add_value(out, (subset, add_exp(x_exp, qx), add_exp(y_exp, qy), comp), value * coeff)
    return out


def cech_tuple_multiply_q(tup: CechTuple, q_terms: list[tuple[int, Exp, Exp]]) -> CechTuple:
    return tuple(cech_multiply_q(part, q_terms) for part in tup)  # type: ignore[return-value]


def br_d2_cech(level2: Cech, l1_terms: list[tuple[int, Exp, Exp]], l2_terms: list[tuple[int, Exp, Exp]]) -> Cech:
    """BR d2: F2 -> F1 with d2(h)=L2 h in u1 minus L1 h in u2."""
    out: Cech = {}
    for (subset, x_exp, y_exp, _comp), value in level2.items():
        for coeff, lx, ly in l2_terms:
            cech_add_value(out, (subset, add_exp(x_exp, lx), add_exp(y_exp, ly), 0), value * coeff)
        for coeff, lx, ly in l1_terms:
            cech_add_value(out, (subset, add_exp(x_exp, lx), add_exp(y_exp, ly), 1), -value * coeff)
    return out


def br_d1_cech(level1: Cech, l1_terms: list[tuple[int, Exp, Exp]], l2_terms: list[tuple[int, Exp, Exp]]) -> Cech:
    """BR d1: F1 -> F0 with d1(a,b)=L1 a + L2 b."""
    out: Cech = {}
    for (subset, x_exp, y_exp, comp), value in level1.items():
        terms = l1_terms if comp == 0 else l2_terms
        for coeff, lx, ly in terms:
            cech_add_value(out, (subset, add_exp(x_exp, lx), add_exp(y_exp, ly), 0), value * coeff)
    return out


def descend_cech(
    z_level2: Cech,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> CechTuple:
    b2 = cech_kappa(z_level2)
    tmp1 = br_d2_cech(b2, l1_terms, l2_terms)
    b1 = cech_scale(cech_kappa(tmp1), -1)
    tmp0 = br_d1_cech(b1, l1_terms, l2_terms)
    b0 = cech_kappa(tmp0)
    return b2, b1, b0


def close_top_class(
    z_level2: Cech,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> CechTuple:
    """Complete a top C^3(F2) class to a total-degree-one cocycle."""
    a2 = dict(z_level2)
    a1 = cech_kappa(br_d2_cech(a2, l1_terms, l2_terms))
    a0_rhs = br_d1_cech(a1, l1_terms, l2_terms)
    a0 = cech_scale(cech_kappa(a0_rhs), -1)
    return a2, a1, a0


def solve_total_boundary(
    rhs: CechTuple,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> CechTuple:
    """Solve D(out)=rhs for a closed total-degree-one rhs."""
    z2, z1, z0 = rhs
    b2 = cech_kappa(z2)
    res1 = cech_residual_add(z1, br_d2_cech(b2, l1_terms, l2_terms), -1)
    b1 = cech_kappa(res1)
    res0 = cech_residual_add(z0, br_d1_cech(b1, l1_terms, l2_terms), 1)
    b0 = cech_kappa(res0)
    return b2, b1, b0


def normalize_to_h0_b1(
    beta: CechTuple,
    c: int,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
) -> Vector:
    beta2, beta1, beta0 = (dict(beta[0]), dict(beta[1]), dict(beta[2]))
    r2 = cech_kappa(beta2)
    cech_add_scaled(beta1, br_d2_cech(r2, l1_terms, l2_terms), 1)
    r1 = cech_kappa(beta1)
    cech_add_scaled(beta0, br_d1_cech(r1, l1_terms, l2_terms), -1)

    grouped: dict[tuple[Exp, Exp], dict[int, int]] = {}
    needs_local_solve = False
    for (subset, x_exp, y_exp, comp), value in beta0.items():
        if comp != 0:
            raise RuntimeError("level-0 normalization found nonzero U component")
        if len(subset) != 1:
            raise RuntimeError(f"expected Cech C0 singleton, got {subset}")
        if any(exponent < 0 for exponent in x_exp):
            needs_local_solve = True
            continue
        if exp_degree(x_exp) != 1 or exp_degree(y_exp) != c:
            needs_local_solve = True
            continue
        grouped.setdefault((x_exp, y_exp), {})[subset[0]] = value % P

    b1_space = build_br_space(c, 1, normalize_to_h0_b1.seed, normalize_to_h0_b1.mode, normalize_to_h0_b1.sparse_l_terms, normalize_to_h0_b1.sparse_q_terms)  # type: ignore[attr-defined]
    if needs_local_solve:
        return solve_global_ambient_from_c0(beta0, c, l1_terms, l2_terms, b1_space)
    ambient: Vector = {}
    for (x_exp, y_exp), by_open in grouped.items():
        values = [by_open.get(i, 0) % P for i in range(4)]
        if len(set(values)) != 1:
            return solve_global_ambient_from_c0(beta0, c, l1_terms, l2_terms, b1_space)
        coeff = values[0]
        if coeff:
            add_value(ambient, b1_space.ambient_index(x_exp, y_exp), coeff)
    return ambient


def negative_support_subset(x_exp: Exp, chart: int) -> bool:
    return all(exponent >= 0 or i == chart for i, exponent in enumerate(x_exp))


def solve_sparse_system(columns: list[Vector], rhs: Vector, nrows: int, ncols: int) -> Vector:
    rows: list[Vector] = [dict() for _ in range(nrows)]
    for col_idx, col in enumerate(columns):
        for row_idx, value in col.items():
            add_value(rows[row_idx], col_idx, value)
    for row_idx, value in rhs.items():
        add_value(rows[row_idx], ncols, value)

    pivot_row = 0
    pivot_cols: list[int] = []
    for col in range(ncols):
        pivot = None
        for row_idx in range(pivot_row, nrows):
            if rows[row_idx].get(col, 0) % P:
                pivot = row_idx
                break
        if pivot is None:
            continue
        rows[pivot_row], rows[pivot] = rows[pivot], rows[pivot_row]
        pv = rows[pivot_row][col] % P
        inv = pow(pv, P - 2, P)
        rows[pivot_row] = vector_scale(rows[pivot_row], inv)
        for row_idx in range(nrows):
            if row_idx == pivot_row:
                continue
            factor = rows[row_idx].get(col, 0) % P
            if factor:
                vector_add_scaled(rows[row_idx], rows[pivot_row], -factor)
        pivot_cols.append(col)
        pivot_row += 1
        if pivot_row == nrows:
            break

    for row in rows:
        coeffs = {k: v for k, v in row.items() if k != ncols and v % P}
        if not coeffs and row.get(ncols, 0) % P:
            raise RuntimeError("local-to-global linear solve is inconsistent")

    solution: Vector = {}
    for idx, col in enumerate(pivot_cols):
        value = rows[idx].get(ncols, 0) % P
        if value:
            solution[col] = value
    return solution


def solve_global_ambient_from_c0(
    beta0: Cech,
    c: int,
    l1_terms: list[tuple[int, Exp, Exp]],
    l2_terms: list[tuple[int, Exp, Exp]],
    b1_space: BRSpace,
) -> Vector:
    """Find global g with beta0_i = g + d1(local F1_i)."""
    row_terms: set[tuple[int, Exp, Exp]] = set()
    for (subset, x_exp, y_exp, comp), value in beta0.items():
        if value % P:
            if comp != 0 or len(subset) != 1:
                raise RuntimeError("bad Cech C0 term for local solve")
            row_terms.add((subset[0], x_exp, y_exp))
    for x_exp in b1_space.x_basis:
        for y_exp in b1_space.y_basis:
            for chart in range(4):
                row_terms.add((chart, x_exp, y_exp))

    source_terms: set[tuple[int, Exp, Exp, int]] = set()
    changed = True
    l_by_comp = (l1_terms, l2_terms)
    while changed:
        changed = False
        current_rows = list(row_terms)
        for chart, x_exp, y_exp in current_rows:
            if exp_degree(x_exp) != 1 or exp_degree(y_exp) != c:
                continue
            if not negative_support_subset(x_exp, chart):
                continue
            for comp, terms in enumerate(l_by_comp):
                for _coeff, lx, ly in terms:
                    src_y = tuple(y_exp[i] - ly[i] for i in range(4))
                    if any(v < 0 for v in src_y):
                        continue
                    src_x = tuple(x_exp[i] - lx[i] for i in range(4))
                    if exp_degree(src_x) != 0 or not negative_support_subset(src_x, chart):
                        continue
                    src_key = (chart, src_x, src_y, comp)  # type: ignore[arg-type]
                    if src_key not in source_terms:
                        source_terms.add(src_key)
                        changed = True
                    for coeff2, lx2, ly2 in terms:
                        tx = add_exp(src_x, lx2)  # type: ignore[arg-type]
                        ty = add_exp(src_y, ly2)  # type: ignore[arg-type]
                        row_key = (chart, tx, ty)
                        if row_key not in row_terms:
                            row_terms.add(row_key)
                            changed = True

    row_list = sorted(row_terms)
    row_index = {key: i for i, key in enumerate(row_list)}
    columns: list[Vector] = []

    global_unknown_count = b1_space.ambient_dim
    for x_exp in b1_space.x_basis:
        for y_exp in b1_space.y_basis:
            col: Vector = {}
            for chart in range(4):
                add_value(col, row_index[(chart, x_exp, y_exp)], 1)
            columns.append(col)

    for chart, src_x, src_y, comp in sorted(source_terms):
        col = {}
        for coeff, lx, ly in l_by_comp[comp]:
            tx = add_exp(src_x, lx)
            ty = add_exp(src_y, ly)
            add_value(col, row_index[(chart, tx, ty)], coeff)
        columns.append(col)

    rhs: Vector = {}
    for (subset, x_exp, y_exp, _comp), value in beta0.items():
        add_value(rhs, row_index[(subset[0], x_exp, y_exp)], value)

    solution = solve_sparse_system(columns, rhs, len(row_list), len(columns))
    ambient: Vector = {}
    for col_idx, value in solution.items():
        if col_idx < global_unknown_count:
            add_value(ambient, col_idx, value)
    return ambient


def top_basis(c: int) -> tuple[Exp, ...]:
    return endpoint.monoms_deg(c - 4)


def top_cech_class(y_exp: Exp) -> Cech:
    return {((0, 1, 2, 3), (-1, -1, -1, -1), y_exp, 0): 1}


def mu0_top_column(
    c: int,
    y_exp: Exp,
    x_var: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> Vector:
    l1_terms, l2_terms, q_terms = endpoint.terms(seed, mode, sparse_l_terms, sparse_q_terms)
    normalize_to_h0_b1.seed = seed  # type: ignore[attr-defined]
    normalize_to_h0_b1.mode = mode  # type: ignore[attr-defined]
    normalize_to_h0_b1.sparse_l_terms = sparse_l_terms  # type: ignore[attr-defined]
    normalize_to_h0_b1.sparse_q_terms = sparse_q_terms  # type: ignore[attr-defined]

    a = close_top_class(top_cech_class(y_exp), l1_terms, l2_terms)
    b = cech_tuple_scale(solve_total_boundary(cech_tuple_multiply_q(a, q_terms), l1_terms, l2_terms), -1)
    h = solve_total_boundary(cech_tuple_multiply_x(a, x_var), l1_terms, l2_terms)
    beta = cech_tuple_add(cech_tuple_multiply_x(b, x_var), cech_tuple_multiply_q(h, q_terms))
    ambient_g = normalize_to_h0_b1(beta, c, l1_terms, l2_terms)
    b1_space = build_br_space(c, 1, seed, mode, sparse_l_terms, sparse_q_terms)
    return b1_space.reduce_br(ambient_g)


def mu0_regular_columns(
    c: int,
    x_var: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> list[Vector]:
    source = build_br_space(c, 0, seed, mode, sparse_l_terms, sparse_q_terms)
    target = build_br_space(c, 1, seed, mode, sparse_l_terms, sparse_q_terms)
    cols: list[Vector] = []
    for j in range(source.dim):
        source_ambient = source.lift_basis_vector(j)
        target_ambient = multiply_x_ambient(source_ambient, source, target, x_var)
        cols.append(target.reduce_br(target_ambient))
    return cols


def mu0_columns(
    c: int,
    x_var: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> list[Vector]:
    cols = mu0_regular_columns(c, x_var, seed, mode, sparse_l_terms, sparse_q_terms)
    for y_exp in top_basis(c):
        cols.append(mu0_top_column(c, y_exp, x_var, seed, mode, sparse_l_terms, sparse_q_terms))
    return cols


def m0_top_probe(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    started = time.time()
    modules, _q_meta = build_positive_modules(c, seed, mode, sparse_l_terms, sparse_q_terms)
    mu0 = {x_var: mu0_columns(c, x_var, seed, mode, sparse_l_terms, sparse_q_terms) for x_var in range(4)}
    mu1 = {x_var: positive_mu_columns(modules, 1, x_var) for x_var in range(4)}
    commutativity = []
    for i in range(4):
        for j in range(i + 1, 4):
            left = compose_columns(mu1[i], mu0[j])
            right = compose_columns(mu1[j], mu0[i])
            commutativity.append({"i": i, "j": j, "commutes": columns_equal(left, right)})
    mu0_meta = {
        f"x{x_var}": {
            "rows": modules[1].dim,
            "cols": len(mu0[x_var]),
            "rank": rank_of_columns(mu0[x_var]),
            "max_col_fill": max((len(col) for col in mu0[x_var]), default=0),
        }
        for x_var in range(4)
    }
    return {
        "m0_dim": len(mu0[0]),
        "regular_dim": build_br_space(c, 0, seed, mode, sparse_l_terms, sparse_q_terms).dim,
        "top_dim": len(top_basis(c)),
        "m1_dim": modules[1].dim,
        "mu0_meta": mu0_meta,
        "all_m0_m1_squares_commute": all(row["commutes"] for row in commutativity),
        "commutativity": commutativity,
        "seconds": round(time.time() - started, 6),
    }


def full_koszul_probe(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    started = time.time()
    modules, _q_meta = build_positive_modules(c, seed, mode, sparse_l_terms, sparse_q_terms)
    module_dims = {0: pbinom(c) + pbinom(c - 4)}
    module_dims.update({d: modules[d].dim for d in range(1, 5)})
    mu: dict[int, dict[int, list[Vector]]] = {0: {}}
    for x_var in range(4):
        mu[0][x_var] = mu0_columns(c, x_var, seed, mode, sparse_l_terms, sparse_q_terms)
    for d in (1, 2, 3):
        mu[d] = {}
        for x_var in range(4):
            mu[d][x_var] = positive_mu_columns(modules, d, x_var)

    d10 = koszul_diff_columns(1, 0, module_dims, mu)
    rank_d10 = rank_of_columns(d10)
    h_deg1 = {
        "H1": len(d10) - rank_d10,
        "H0": module_dims[1] - rank_d10,
    }

    d20 = koszul_diff_columns(2, 0, module_dims, mu)
    d11 = koszul_diff_columns(1, 1, module_dims, mu)
    rank_d20 = rank_of_columns(d20)
    rank_d11 = rank_of_columns(d11)
    h_deg2 = {
        "H2": len(d20) - rank_d20,
        "H1": len(d11) - rank_d11 - rank_d20,
        "H0": module_dims[2] - rank_d11,
    }

    d30 = koszul_diff_columns(3, 0, module_dims, mu)
    d21 = koszul_diff_columns(2, 1, module_dims, mu)
    d12 = koszul_diff_columns(1, 2, module_dims, mu)
    rank_d30 = rank_of_columns(d30)
    rank_d21 = rank_of_columns(d21)
    rank_d12 = rank_of_columns(d12)
    h_deg3 = {
        "H3": len(d30) - rank_d30,
        "H2": len(d21) - rank_d21 - rank_d30,
        "H1": len(d12) - rank_d12 - rank_d21,
        "H0": module_dims[3] - rank_d12,
    }

    d40 = koszul_diff_columns(4, 0, module_dims, mu)
    d31 = koszul_diff_columns(3, 1, module_dims, mu)
    d22 = koszul_diff_columns(2, 2, module_dims, mu)
    d13 = koszul_diff_columns(1, 3, module_dims, mu)
    rank_d40 = rank_of_columns(d40)
    rank_d31 = rank_of_columns(d31)
    rank_d22 = rank_of_columns(d22)
    rank_d13 = rank_of_columns(d13)
    h_deg4 = {
        "H4": len(d40) - rank_d40,
        "H3": len(d31) - rank_d31 - rank_d40,
        "H2": len(d22) - rank_d22 - rank_d31,
        "H1": len(d13) - rank_d13 - rank_d22,
        "H0": module_dims[4] - rank_d13,
    }

    def euler(homology: dict[str, int]) -> int:
        total = 0
        for key, value in homology.items():
            p = int(key[1:])
            total += ((-1) ** p) * value
        return total

    return {
        "module_dims_M0_to_M4": {str(d): module_dims[d] for d in range(5)},
        "ranks": {
            "d_WM0_to_M1": rank_d10,
            "d_L2M0_to_WM1": rank_d20,
            "d_WM1_to_M2": rank_d11,
            "d_L3M0_to_L2M1": rank_d30,
            "d_L2M1_to_WM2": rank_d21,
            "d_WM2_to_M3": rank_d12,
            "d_L4M0_to_L3M1": rank_d40,
            "d_L3M1_to_L2M2": rank_d31,
            "d_L2M2_to_WM3": rank_d22,
            "d_WM3_to_M4": rank_d13,
        },
        "koszul_homology_by_degree": {
            "degree_1": h_deg1,
            "degree_2": h_deg2,
            "degree_3": h_deg3,
            "degree_4": h_deg4,
        },
        "numerator_coefficients_from_euler": {
            "degree_1": euler(h_deg1),
            "degree_2": euler(h_deg2),
            "degree_3": euler(h_deg3),
            "degree_4": euler(h_deg4),
        },
        "complex_checks": {
            "d11_after_d20_nonzero_cols": composition_nonzero_count(d11, d20),
            "d21_after_d30_nonzero_cols": composition_nonzero_count(d21, d30),
            "d12_after_d21_nonzero_cols": composition_nonzero_count(d12, d21),
            "d31_after_d40_nonzero_cols": composition_nonzero_count(d31, d40),
            "d22_after_d31_nonzero_cols": composition_nonzero_count(d22, d31),
            "d13_after_d22_nonzero_cols": composition_nonzero_count(d13, d22),
        },
        "seconds": round(time.time() - started, 6),
    }


def m0_debug_one(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    l1_terms, l2_terms, q_terms = endpoint.terms(seed, mode, sparse_l_terms, sparse_q_terms)
    y_exp = top_basis(c)[0]
    x_var = 0
    raw_top = top_cech_class(y_exp)
    a = close_top_class(raw_top, l1_terms, l2_terms)
    qa = cech_tuple_multiply_q(a, q_terms)
    xja = cech_tuple_multiply_x(a, x_var)
    sol_qa = solve_total_boundary(qa, l1_terms, l2_terms)
    sol_xja = solve_total_boundary(xja, l1_terms, l2_terms)
    b = cech_tuple_scale(sol_qa, -1)
    h = sol_xja
    beta = cech_tuple_add(cech_tuple_multiply_x(b, x_var), cech_tuple_multiply_q(h, q_terms))
    return {
        "c": c,
        "top_y_exp": y_exp,
        "x_var": x_var,
        "top_class_total_cocycle_residual": total_degree_one_cocycle_residual_counts(a, l1_terms, l2_terms),
        "qa_total_cocycle_residual": total_degree_one_cocycle_residual_counts(qa, l1_terms, l2_terms),
        "xja_total_cocycle_residual": total_degree_one_cocycle_residual_counts(xja, l1_terms, l2_terms),
        "qa_solution_residual": total_boundary_residual_counts(qa, sol_qa, l1_terms, l2_terms),
        "xja_solution_residual": total_boundary_residual_counts(xja, sol_xja, l1_terms, l2_terms),
        "beta_total_cocycle_residual": total_cocycle_residual_counts(beta, l1_terms, l2_terms),
        "beta_component_sizes": [len(part) for part in beta],
    }


def positive_mu_probe(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    started = time.time()
    modules, q_meta = build_positive_modules(c, seed, mode, sparse_l_terms, sparse_q_terms)
    mu: dict[int, dict[int, list[Vector]]] = {}
    mu_meta: dict[str, Any] = {}
    for d in (1, 2, 3):
        mu[d] = {}
        for x_var in range(4):
            cols = positive_mu_columns(modules, d, x_var)
            mu[d][x_var] = cols
            mu_meta[f"d{d}_x{x_var}"] = {
                "rows": modules[d + 1].dim,
                "cols": modules[d].dim,
                "rank": rank_of_columns(cols),
                "max_col_fill": max((len(col) for col in cols), default=0),
            }
    commutativity = []
    for d in (1, 2):
        for i in range(4):
            for j in range(i + 1, 4):
                left = compose_columns(mu[d + 1][i], mu[d][j])
                right = compose_columns(mu[d + 1][j], mu[d][i])
                commutativity.append({
                    "d": d,
                    "i": i,
                    "j": j,
                    "commutes": columns_equal(left, right),
                })
    return {
        "module_dims_M1_to_M4": {str(d): modules[d].dim for d in range(1, 5)},
        "q_quotient_meta": q_meta,
        "mu_meta": mu_meta,
        "commutativity": commutativity,
        "all_positive_squares_commute": all(row["commutes"] for row in commutativity),
        "seconds": round(time.time() - started, 6),
    }


def probe_c(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
    check_positive_mu: bool = False,
    check_m0_top: bool = False,
    check_m0_debug_one: bool = False,
    check_full_koszul: bool = False,
) -> dict[str, Any]:
    started = time.time()
    q_results = [q_rank(c, d, seed, mode, sparse_l_terms, sparse_q_terms) for d in (2, 3, 4)]
    payload: dict[str, Any] = {
        "c": c,
        "prime": P,
        "seed": seed,
        "mode": mode,
        "sparse_l_terms": sparse_l_terms,
        "sparse_q_terms": sparse_q_terms,
        "q_results": q_results,
        "all_full_column_rank": all(row["full_column_rank"] for row in q_results),
        "seconds": round(time.time() - started, 6),
    }
    if check_positive_mu:
        payload["positive_mu_probe"] = positive_mu_probe(c, seed, mode, sparse_l_terms, sparse_q_terms)
        payload["seconds"] = round(time.time() - started, 6)
    if check_m0_top:
        payload["m0_top_probe"] = m0_top_probe(c, seed, mode, sparse_l_terms, sparse_q_terms)
        payload["seconds"] = round(time.time() - started, 6)
    if check_m0_debug_one:
        payload["m0_debug_one"] = m0_debug_one(c, seed, mode, sparse_l_terms, sparse_q_terms)
        payload["seconds"] = round(time.time() - started, 6)
    if check_full_koszul:
        payload["full_koszul_probe"] = full_koszul_probe(c, seed, mode, sparse_l_terms, sparse_q_terms)
        payload["seconds"] = round(time.time() - started, 6)
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("c", nargs="*", type=int, default=[8, 9, 10])
    parser.add_argument("--seed", type=int, default=7863)
    parser.add_argument(
        "--mode",
        choices=("diagonal", "sparseL_denseQ", "random_sparse", "dense"),
        default="sparseL_denseQ",
    )
    parser.add_argument("--sparse-l-terms", type=int, default=8)
    parser.add_argument("--sparse-q-terms", type=int, default=20)
    parser.add_argument("--positive-mu", action="store_true", help="also check M_d multiplication for d=1,2,3")
    parser.add_argument("--m0-top", action="store_true", help="also build M0 top correction and check M0/M1 squares")
    parser.add_argument("--m0-debug-one", action="store_true", help="debug one M0 top Cech/cone column")
    parser.add_argument("--full-koszul", action="store_true", help="compute full reduced Koszul homology")
    parser.add_argument("--out")
    args = parser.parse_args()

    payload = {
        "results": [
            probe_c(
                c,
                args.seed,
                args.mode,
                args.sparse_l_terms,
                args.sparse_q_terms,
                args.positive_mu,
                args.m0_top,
                args.m0_debug_one,
                args.full_koszul,
            )
            for c in args.c
        ]
    }
    text = json.dumps(payload, indent=2, sort_keys=True)
    if args.out:
        path = pathlib.Path(args.out)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
