#!/usr/bin/env python3
"""Singular certificate probe for CICY 7863 endpoint modules N_c.

This builds the global A=C[x0..x3]-linear endpoint maps

    Sym^c(V)^* tensor A -> (Sym^{c-1}(V)^* tensor A(1))^2
                         + Sym^{c-2}(V)^* tensor A(2)

for c>=2 at a deterministic finite-field specialization, then asks Singular
for the minimal resolution of the kernel module.  This is the global version
of the degree-by-degree rank probe in 7863_endpoint_nc_probe.py.
"""

from __future__ import annotations

import argparse
import json
import pathlib
import random
import re
import subprocess
import time
from functools import lru_cache


ROOT = pathlib.Path(__file__).resolve().parent
OUT_DIR = ROOT / "tmp" / "7863_endpoint_singular_certs"
SINGULAR = pathlib.Path("/opt/homebrew/bin/Singular")
P = 1_000_003


@lru_cache(maxsize=None)
def monoms_deg(n: int, vars_count: int = 4) -> tuple[tuple[int, ...], ...]:
    if n < 0:
        return ()
    out: list[tuple[int, ...]] = []

    def rec(i: int, rem: int, acc: list[int]) -> None:
        if i == vars_count - 1:
            out.append(tuple(acc + [rem]))
            return
        for k in range(rem + 1):
            rec(i + 1, rem - k, acc + [k])

    rec(0, n, [])
    return tuple(out)


def sub_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...] | None:
    out = tuple(x - y for x, y in zip(a, b))
    if any(x < 0 for x in out):
        return None
    return out


def falling_for_multi(beta: tuple[int, ...], nu: tuple[int, ...]) -> int:
    coeff = 1
    for b, n in zip(beta, nu):
        if n > b:
            return 0
        term = 1
        for j in range(n):
            term *= b - j
        coeff *= term
    return coeff % P


def terms(
    seed: int, mode: str, sparse_l_terms: int = 8, sparse_q_terms: int = 20
) -> tuple[list[tuple[int, tuple[int, ...], tuple[int, ...]]], ...]:
    x1 = monoms_deg(1)
    x2 = monoms_deg(2)
    y1 = monoms_deg(1)
    y2 = monoms_deg(2)

    if mode == "diagonal":
        e = monoms_deg(1)
        coeffs = [2, 3, 5, 7]
        l1 = [(1, e[i], e[i]) for i in range(4)]
        l2 = [(i + 1, e[i], e[i]) for i in range(4)]
        q = [
            (coeffs[i], tuple(2 * v for v in e[i]), tuple(2 * v for v in e[i]))
            for i in range(4)
        ]
        return l1, l2, q

    if mode == "sparseL_denseQ":
        e = monoms_deg(1)
        l1 = [(1, e[i], e[i]) for i in range(4)]
        l2 = [(i + 1, e[i], e[i]) for i in range(4)]
        rng = random.Random(seed)
        q = [(rng.randrange(1, P), xe, ye) for xe in x2 for ye in y2]
        return l1, l2, q

    if mode == "random_sparse":
        rng = random.Random(seed)

        def sample_terms(xmons, ymons, count):
            pool = [(xe, ye) for xe in xmons for ye in ymons]
            count = min(count, len(pool))
            return [
                (rng.randrange(1, P), xe, ye)
                for xe, ye in rng.sample(pool, count)
            ]

        l1 = sample_terms(x1, y1, sparse_l_terms)
        l2 = sample_terms(x1, y1, sparse_l_terms)
        q = sample_terms(x2, y2, sparse_q_terms)
        return l1, l2, q

    if mode != "dense":
        raise ValueError("mode must be diagonal, sparseL_denseQ, random_sparse, or dense")

    rng = random.Random(seed)
    l1 = [(rng.randrange(1, P), xe, ye) for xe in x1 for ye in y1]
    l2 = [(rng.randrange(1, P), xe, ye) for xe in x1 for ye in y1]
    q = [(rng.randrange(1, P), xe, ye) for xe in x2 for ye in y2]
    return l1, l2, q


def monomial_str(exp: tuple[int, ...]) -> str:
    pieces = []
    for i, power in enumerate(exp):
        if power == 1:
            pieces.append(f"x{i}")
        elif power > 1:
            pieces.append(f"x{i}^{power}")
    return "*".join(pieces) if pieces else "1"


def polynomial_str(poly: dict[tuple[int, ...], int]) -> str:
    terms_out = []
    for exp, coeff in sorted(poly.items()):
        coeff %= P
        if not coeff:
            continue
        monom = monomial_str(exp)
        if monom == "1":
            terms_out.append(str(coeff))
        elif coeff == 1:
            terms_out.append(monom)
        else:
            terms_out.append(f"{coeff}*{monom}")
    return "+".join(terms_out) if terms_out else "0"


def add_poly_term(poly: dict[tuple[int, ...], int], exp: tuple[int, ...], coeff: int) -> None:
    coeff %= P
    if not coeff:
        return
    new_value = (poly.get(exp, 0) + coeff) % P
    if new_value:
        poly[exp] = new_value
    elif exp in poly:
        del poly[exp]


def endpoint_columns(
    c: int, seed: int, mode: str, sparse_l_terms: int = 8, sparse_q_terms: int = 20
) -> list[list[dict[tuple[int, ...], int]]]:
    if c < 2:
        raise ValueError("c must be at least 2")

    l1, l2, q_terms = terms(seed, mode, sparse_l_terms, sparse_q_terms)
    y_dom = monoms_deg(c)
    y_l = monoms_deg(c - 1)
    y_q = monoms_deg(c - 2)

    rows = 2 * len(y_l) + len(y_q)
    cols: list[list[dict[tuple[int, ...], int]]] = []

    for beta in y_dom:
        col = [{} for _ in range(rows)]
        for block, lin_terms in enumerate((l1, l2)):
            for coeff, xop, yop in lin_terms:
                ynew = sub_exp(beta, yop)
                if ynew is None:
                    continue
                ycoeff = falling_for_multi(beta, yop)
                if not ycoeff:
                    continue
                row = block * len(y_l) + y_l.index(ynew)
                add_poly_term(col[row], xop, coeff * ycoeff)
        for coeff, xop, yop in q_terms:
            ynew = sub_exp(beta, yop)
            if ynew is None:
                continue
            ycoeff = falling_for_multi(beta, yop)
            if not ycoeff:
                continue
            row = 2 * len(y_l) + y_q.index(ynew)
            add_poly_term(col[row], xop, coeff * ycoeff)
        cols.append(col)

    return cols


def module_columns_to_singular(cols: list[list[dict[tuple[int, ...], int]]]) -> str:
    col_strings = []
    for col in cols:
        entries = ",".join(polynomial_str(poly) for poly in col)
        col_strings.append(f"[{entries}]")
    return ",".join(col_strings)


def singular_script(
    c: int,
    seed: int,
    mode: str,
    skip_resolution: bool = False,
    sparse_l_terms: int = 8,
    sparse_q_terms: int = 20,
    split_linear: bool = False,
) -> str:
    cols = endpoint_columns(c, seed, mode, sparse_l_terms, sparse_q_terms)
    module_body = module_columns_to_singular(cols)
    lines = [
        f"// CICY 7863 endpoint module certificate probe: c={c}, seed={seed}, mode={mode}",
        f"// sparse_l_terms={sparse_l_terms}, sparse_q_terms={sparse_q_terms}",
        f"// split_linear={split_linear}",
        f"ring r={P},(x0,x1,x2,x3),dp;",
        "option(redSB);",
    ]
    if split_linear:
        y_l_count = len(monoms_deg(c - 1))
        lin_rows = 2 * y_l_count
        ml_cols = [col[:lin_rows] for col in cols]
        mq_cols = [col[lin_rows:] for col in cols]
        lines.extend(
            [
                f"module ML={module_columns_to_singular(ml_cols)};",
                f"module MQ={module_columns_to_singular(mq_cols)};",
                "module KL=syz(ML);",
                'print("KL_SIZE_BEGIN");',
                "print(size(KL));",
                'print("KL_SIZE_END");',
                "matrix QKmat=matrix(MQ)*matrix(KL);",
                "module QK=module(QKmat);",
                "module T=syz(QK);",
                'print("T_SIZE_BEGIN");',
                "print(size(T));",
                'print("T_SIZE_END");',
                "module K=module(matrix(KL)*matrix(T));",
                "module G=std(K);",
            ]
        )
    else:
        lines.extend(
            [
                f"module M={module_body};",
                "module K=syz(M);",
                "module G=std(K);",
            ]
        )
    lines.extend(
        [
        'print("K_SIZE_BEGIN");',
        "print(size(K));",
        'print("K_SIZE_END");',
        'print("STD_SIZE_BEGIN");',
        "print(size(G));",
        'print("STD_SIZE_END");',
        ]
    )
    if not skip_resolution:
        lines.extend(
            [
                "resolution R=mres(G,0);",
                'print("BETTI_BEGIN");',
                "betti(R);",
                'print("BETTI_END");',
            ]
        )
    lines.extend(
        [
            'print("HILB_QUOT_BEGIN");',
            "hilb(G);",
            'print("HILB_QUOT_END");',
            "quit;",
            "",
        ]
    )
    return "\n".join(lines)


def parse_betti(stdout: str) -> list[str]:
    if "BETTI_BEGIN" not in stdout:
        return []
    tail = stdout.split("BETTI_BEGIN", 1)[1]
    tail = tail.split("BETTI_END", 1)[0]
    return [line.rstrip() for line in tail.splitlines() if line.strip()]


def marker_int(stdout: str, begin: str, end: str) -> int | None:
    pattern = re.escape(begin) + r"\s*([0-9]+)\s*" + re.escape(end)
    match = re.search(pattern, stdout)
    return int(match.group(1)) if match else None


def run_case(
    c: int,
    seed: int,
    mode: str,
    timeout: int,
    write: bool,
    skip_resolution: bool,
    sparse_l_terms: int,
    sparse_q_terms: int,
    split_linear: bool,
) -> dict[str, object]:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stem = f"endpoint_c{c}_{mode}_seed{seed}"
    script_path = OUT_DIR / f"{stem}.sing"
    out_path = OUT_DIR / f"{stem}.out"
    err_path = OUT_DIR / f"{stem}.err"
    script = singular_script(
        c, seed, mode, skip_resolution, sparse_l_terms, sparse_q_terms, split_linear
    )
    script_path.write_text(script, encoding="utf-8")
    t0 = time.time()
    try:
        proc = subprocess.run(
            [str(SINGULAR), "-q", str(script_path)],
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        proc = subprocess.CompletedProcess(
            args=[str(SINGULAR), "-q", str(script_path)],
            returncode=-999,
            stdout=exc.stdout if isinstance(exc.stdout, str) else "",
            stderr=exc.stderr if isinstance(exc.stderr, str) else "",
        )
        timed_out = True
    seconds = round(time.time() - t0, 3)
    if write:
        out_path.write_text(proc.stdout, encoding="utf-8")
        err_path.write_text(proc.stderr, encoding="utf-8")

    return {
        "c": c,
        "seed": seed,
        "mode": mode,
        "seconds": seconds,
        "returncode": proc.returncode,
        "timed_out": timed_out,
        "script": str(script_path),
        "stdout": str(out_path) if write else None,
        "stderr": str(err_path) if write else None,
        "skip_resolution": skip_resolution,
        "sparse_l_terms": sparse_l_terms,
        "sparse_q_terms": sparse_q_terms,
        "split_linear": split_linear,
        "linear_kernel_generators": marker_int(proc.stdout, "KL_SIZE_BEGIN", "KL_SIZE_END"),
        "restricted_q_syzygy_generators": marker_int(proc.stdout, "T_SIZE_BEGIN", "T_SIZE_END"),
        "kernel_generators": marker_int(proc.stdout, "K_SIZE_BEGIN", "K_SIZE_END"),
        "std_generators": marker_int(proc.stdout, "STD_SIZE_BEGIN", "STD_SIZE_END"),
        "betti": parse_betti(proc.stdout),
        "stdout_tail": proc.stdout[-2000:],
        "stderr_tail": proc.stderr[-1000:],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--c", type=int, action="append")
    parser.add_argument("--seed", type=int, default=7863)
    parser.add_argument(
        "--mode",
        choices=("diagonal", "sparseL_denseQ", "random_sparse", "dense"),
        default="sparseL_denseQ",
    )
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--skip-resolution", action="store_true")
    parser.add_argument("--sparse-l-terms", type=int, default=8)
    parser.add_argument("--sparse-q-terms", type=int, default=20)
    parser.add_argument("--split-linear", action="store_true")
    args = parser.parse_args()

    cases = args.c if args.c else [2, 3]
    for c in cases:
        if c < 2:
            raise SystemExit("--c must be at least 2")
    records = [
        run_case(
            c,
            args.seed,
            args.mode,
            args.timeout,
            args.write,
            args.skip_resolution,
            args.sparse_l_terms,
            args.sparse_q_terms,
            args.split_linear,
        )
        for c in cases
    ]
    payload = {"records": records}
    print(json.dumps(payload, indent=2))
    if args.write:
        (OUT_DIR / "endpoint_singular_cert_summary.json").write_text(
            json.dumps(payload, indent=2), encoding="utf-8"
        )


if __name__ == "__main__":
    main()
