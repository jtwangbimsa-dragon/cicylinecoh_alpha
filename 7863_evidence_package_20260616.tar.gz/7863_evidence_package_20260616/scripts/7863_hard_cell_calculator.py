#!/usr/bin/env python3
"""Calculator for the currently resolved hard CICY 7863 cells.

This covers the formerly unresolved mixed/boundary cells recorded in the
verifier notes.  It returns unresolved only for the remaining two-parameter
Cell 9/73 points beyond the reduced endpoint certificate range.
"""

from __future__ import annotations

import argparse
import json
from math import comb


def binom3(n: int) -> int:
    return comb(n, 3) if n >= 3 else 0


def p(d: int) -> int:
    return comb(d + 3, 3) if d >= 0 else 0


def n2(r: int) -> int:
    return 10 * binom3(r - 5) - 8 * binom3(r - 6)


def n3(r: int) -> int:
    return 20 * binom3(r - 11) - 20 * binom3(r - 12) + 2 * binom3(r - 14)


KNOWN_ENDPOINT_MAX = 10


def endpoint_coefficients(c: int) -> tuple[int, int, int, int, int]:
    """Return (s,A,B,C,G) for the certified Cell 9 endpoint numerator."""
    s = 6 * c - 4
    a_coeff = c * (c * c + 11) // 3
    b_coeff = c**3 - 3 * c**2 + 8 * c - 4
    c_coeff = (c - 1) * (c - 2) * (c - 3)
    g_coeff = (c - 6) * (c - 2) * (c - 1) // 3
    return s, a_coeff, b_coeff, c_coeff, g_coeff


def endpoint_n(c: int, r: int) -> int:
    """Endpoint Hilbert function from the reduced certificate numerator."""
    s, a_coeff, b_coeff, c_coeff, g_coeff = endpoint_coefficients(c)
    q = r - s
    return (
        a_coeff * binom3(q + 3)
        - b_coeff * binom3(q + 2)
        + c_coeff * binom3(q + 1)
        - g_coeff * binom3(q)
    )


def endpoint_nb(c: int, r: int) -> int:
    if 4 <= c <= KNOWN_ENDPOINT_MAX:
        return endpoint_n(c, r)
    raise ValueError(f"endpoint N_{c} is not certified by this helper")


def delta2(r: int) -> int:
    return 8 * p(r + 1) - 10 * p(r)


def delta3(r: int) -> int:
    return 20 * p(r + 1) - 20 * p(r) - 2 * p(r + 3)


def euler_cell9(m: int, b: int) -> int:
    return (
        p(m + 4) * p(b - 4)
        - 2 * p(m + 3) * p(b - 3)
        + 2 * p(m + 1) * p(b - 1)
        - p(m) * p(b)
    )


def hard_cell_cohomology(a: int, b: int, use_conjectural_endpoint: bool = False) -> dict[str, object]:
    # One-parameter N2 cells.
    if a <= -4 and b == 2:
        r = -a - 4
        n = n2(r)
        return {"status": "closed", "cell": 7, "parameter": r, "h": [0, 0, n + delta2(r), n]}
    if a == 2 and b <= -4:
        r = -b - 4
        n = n2(r)
        return {"status": "closed", "cell": 55, "parameter": r, "h": [0, 0, n + delta2(r), n]}
    if a == -2 and b >= 4:
        r = b - 4
        n = n2(r)
        return {"status": "closed", "cell": 27, "parameter": r, "h": [n, n + delta2(r), 0, 0]}
    if a >= 4 and b == -2:
        r = a - 4
        n = n2(r)
        return {"status": "closed", "cell": 75, "parameter": r, "h": [n, n + delta2(r), 0, 0]}

    # One-parameter N3 cells.
    if a <= -4 and b == 3:
        r = -a - 4
        n = n3(r)
        return {"status": "closed", "cell": 8, "parameter": r, "h": [0, 0, n + delta3(r), n]}
    if a == 3 and b <= -4:
        r = -b - 4
        n = n3(r)
        return {"status": "closed", "cell": 64, "parameter": r, "h": [0, 0, n + delta3(r), n]}
    if a == -3 and b >= 4:
        r = b - 4
        n = n3(r)
        return {"status": "closed", "cell": 18, "parameter": r, "h": [n, n + delta3(r), 0, 0]}
    if a >= 4 and b == -3:
        r = a - 4
        n = n3(r)
        return {"status": "closed", "cell": 74, "parameter": r, "h": [n, n + delta3(r), 0, 0]}

    # Fixed/small-rank hard cells.
    fixed = {
        (-3, 2): (16, [0, 0, 8, 0]),
        (-3, 3): (17, [0, 0, 0, 0]),
        (-2, 3): (26, [0, 8, 0, 0]),
        (2, -3): (56, [0, 0, 8, 0]),
        (2, -2): (57, [0, 1, 1, 0]),
        (3, -3): (65, [0, 0, 0, 0]),
        (3, -2): (66, [0, 8, 0, 0]),
    }
    if (a, b) in fixed:
        cell, h = fixed[(a, b)]
        return {"status": "closed", "cell": cell, "h": h}

    # Two-parameter Cell 9/73 slices where N_b has a reduced certificate.
    if a <= -4 and 4 <= b <= KNOWN_ENDPOINT_MAX:
        m = -a - 4
        e0 = endpoint_nb(b, m)
        d = euler_cell9(m, b) + e0
        return {
            "status": "closed_reduced_finite_field_certificate",
            "cell": 9,
            "parameter": m,
            "endpoint_e0": e0,
            "endpoint": f"N_{b}",
            "h": [0, max(-d, 0), max(d, 0), e0],
        }
    if a >= 4 and -KNOWN_ENDPOINT_MAX <= b <= -4:
        m = a - 4
        c = -b
        e0 = endpoint_nb(c, m)
        d = euler_cell9(m, c) + e0
        return {
            "status": "closed_reduced_finite_field_certificate",
            "cell": 73,
            "parameter": m,
            "endpoint_e0": e0,
            "endpoint": f"N_{c}",
            "h": [e0, max(d, 0), max(-d, 0), 0],
        }

    if a <= -4 and b >= 4:
        if use_conjectural_endpoint:
            return {
                "status": "unavailable",
                "cell": 9,
                "reason": "no surviving general endpoint conjecture after N5 disproved the c=2..4 extrapolation",
            }
        return {
            "status": "unresolved",
            "cell": 9,
            "reason": f"two-parameter reduced endpoint certificate is recorded only through b={KNOWN_ENDPOINT_MAX}",
        }
    if a >= 4 and b <= -4:
        if use_conjectural_endpoint:
            return {
                "status": "unavailable",
                "cell": 73,
                "reason": "no surviving general endpoint conjecture after N5 disproved the c=2..4 extrapolation",
            }
        return {
            "status": "unresolved",
            "cell": 73,
            "reason": f"Serre dual to unresolved Cell 9 beyond |b|={KNOWN_ENDPOINT_MAX}",
        }

    return {
        "status": "not_in_hard_cell_helper",
        "reason": "this helper only covers the hard cells discussed in the 7863 verifier notes",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("a", type=int)
    parser.add_argument("b", type=int)
    parser.add_argument("--use-conjectural-endpoint", action="store_true")
    args = parser.parse_args()
    print(
        json.dumps(
            hard_cell_cohomology(args.a, args.b, args.use_conjectural_endpoint),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
