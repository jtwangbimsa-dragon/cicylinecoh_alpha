#!/usr/bin/env python3
"""Initial-ideal Hilbert check for the CICY 7863 Cell 9 endpoint.

The check works over the deterministic finite-field specialization used by the
rank probes.  It computes a Groebner basis of

    I = (L1, L2, Q) in F_p[x0..x3,y0..y3],

extracts the leading monomials, and counts standard monomials of bidegree
(x-degree=s, y-degree=b).  The endpoint top/Cech correction P(b-4) is then
added only at shifted degree s=0.

This is an audit of the Hilbert numerator, independent of the q-rank quotient
calculation.  It is not by itself a characteristic-zero proof.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import re
import subprocess
import sys
import time
from functools import lru_cache
from math import comb
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
SINGULAR = pathlib.Path("/opt/homebrew/bin/Singular")
ENDPOINT_PATH = ROOT / "7863_endpoint_nc_probe.py"
DEFAULT_P = 1_000_003

SPEC = importlib.util.spec_from_file_location("endpoint7863", ENDPOINT_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_endpoint_nc_probe.py")
endpoint = importlib.util.module_from_spec(SPEC)
sys.modules["endpoint7863"] = endpoint
SPEC.loader.exec_module(endpoint)


Exp4 = tuple[int, int, int, int]
Exp8 = tuple[int, int, int, int, int, int, int, int]


@lru_cache(maxsize=None)
def monoms_deg(n: int, vars_count: int = 4) -> tuple[tuple[int, ...], ...]:
    if n < 0:
        return ()
    out: list[tuple[int, ...]] = []

    def rec(i: int, rem: int, acc: list[int]) -> None:
        if i == vars_count - 1:
            out.append(tuple(acc + [rem]))
            return
        for k in range(rem + 1):
            rec(i + 1, rem - k, acc + [k])

    rec(0, n, [])
    return tuple(out)


def pbinom(r: int) -> int:
    return comb(r + 3, 3) if r >= 0 else 0


def expected_coeffs(b: int) -> list[int]:
    return [
        b * (b * b + 11) // 3,
        -(b**3 - 3 * b**2 + 8 * b - 4),
        (b - 1) * (b - 2) * (b - 3),
        -((b - 6) * (b - 1) * (b - 2) // 3),
    ]


def expected_h(b: int, s: int) -> int:
    total = 0
    for j, coeff in enumerate(expected_coeffs(b)):
        total += coeff * pbinom(s - j)
    return total


def monomial_xy(coeff: int, x_exp: Exp4, y_exp: Exp4, prime: int) -> str:
    coeff %= prime
    pieces: list[str] = []
    if coeff != 1:
        pieces.append(str(coeff))
    for prefix, exp in (("x", x_exp), ("y", y_exp)):
        for i, power in enumerate(exp):
            if power == 1:
                pieces.append(f"{prefix}{i}")
            elif power > 1:
                pieces.append(f"{prefix}{i}^{power}")
    return "*".join(pieces) if pieces else "1"


def polynomial_xy(terms: list[tuple[int, Exp4, Exp4]], prime: int) -> str:
    return (
        "+".join(monomial_xy(coeff, x_exp, y_exp, prime) for coeff, x_exp, y_exp in terms)
        or "0"
    )


def singular_script(
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
    prime: int,
) -> str:
    l1, l2, q = endpoint.terms(seed, mode, sparse_l_terms, sparse_q_terms)
    return "\n".join(
        [
            f"ring r={prime},(x0,x1,x2,x3,y0,y1,y2,y3),dp;",
            "option(redSB);",
            f"poly L1={polynomial_xy(l1, prime)};",
            f"poly L2={polynomial_xy(l2, prime)};",
            f"poly Q={polynomial_xy(q, prime)};",
            "ideal I=L1,L2,Q;",
            "ideal G=std(I);",
            "ideal L=lead(G);",
            'print("LEADS_BEGIN");',
            "for (int i=1; i<=size(L); i=i+1) { print(string(leadmonom(L[i]))); }",
            'print("LEADS_END");',
            "quit;",
            "",
        ]
    )


def run_singular(script: str, timeout: float) -> tuple[str, float, pathlib.Path]:
    tmp = ROOT / "tmp" / "7863_initial_ideal_hilbert"
    tmp.mkdir(parents=True, exist_ok=True)
    path = tmp / "initial_ideal_check.sing"
    path.write_text(script)
    start = time.time()
    proc = subprocess.run(
        [str(SINGULAR), "-q", str(path)],
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    seconds = time.time() - start
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-4000:] + "\n" + proc.stdout[-4000:])
    return proc.stdout, seconds, path


def parse_lead_monomials(stdout: str) -> list[Exp8]:
    match = re.search(r"LEADS_BEGIN\s*(.*?)\s*LEADS_END", stdout, re.S)
    if not match:
        raise RuntimeError("could not find leading monomial block")
    out: list[Exp8] = []
    for line in match.group(1).splitlines():
        text = line.strip()
        if not text or text == "1":
            continue
        exp = [0] * 8
        for var, power in re.findall(r"([xy][0-3])(?:\^([0-9]+))?", text):
            idx = int(var[1]) + (4 if var[0] == "y" else 0)
            exp[idx] += int(power or "1")
        out.append(tuple(exp))  # type: ignore[arg-type]
    return out


def divides(a: Exp8, b: Exp8) -> bool:
    return all(x <= y for x, y in zip(a, b))


def monomial_lcm(a: Exp8, b: Exp8) -> Exp8:
    return tuple(max(x, y) for x, y in zip(a, b))  # type: ignore[return-value]


def lower_bound_count(total_degree: int, lower_bound: tuple[int, int, int, int]) -> int:
    remaining = total_degree - sum(lower_bound)
    return pbinom(remaining)


def standard_count(leads: list[Exp8], s: int, b: int) -> int:
    """Count bidegree-(s,b) standard monomials by inclusion-exclusion."""
    total = pbinom(s) * pbinom(b)
    covered = 0
    subset_count = 1 << len(leads)
    for mask in range(1, subset_count):
        lcm = (0, 0, 0, 0, 0, 0, 0, 0)
        bits = 0
        for i, lead in enumerate(leads):
            if mask & (1 << i):
                bits += 1
                lcm = monomial_lcm(lcm, lead)
        contribution = lower_bound_count(s, lcm[:4]) * lower_bound_count(b, lcm[4:])
        if bits % 2:
            covered += contribution
        else:
            covered -= contribution
    return total - covered


def finite_difference_numerator(values: list[int]) -> list[int]:
    coeffs: list[int] = []
    for s in range(len(values)):
        coeff = 0
        for i in range(5):
            if s - i >= 0:
                coeff += (-1) ** i * comb(4, i) * values[s - i]
        coeffs.append(coeff)
    return coeffs


def run_check(args: argparse.Namespace) -> dict[str, Any]:
    stdout, seconds, script_path = run_singular(
        singular_script(
            args.seed,
            args.mode,
            args.sparse_l_terms,
            args.sparse_q_terms,
            args.prime,
        ),
        args.timeout,
    )
    leads = parse_lead_monomials(stdout)
    records = []
    all_match = True
    for b in args.b:
        hs = []
        for s in range(args.max_s + 1):
            value = standard_count(leads, s, b)
            if s == 0:
                value += pbinom(b - 4)
            hs.append(value)
        num = finite_difference_numerator(hs)
        expected_num = expected_coeffs(b) + [0] * (args.max_s + 1 - 4)
        matches_h = [hs[s] == expected_h(b, s) for s in range(args.max_s + 1)]
        matches_num = [num[s] == expected_num[s] for s in range(args.max_s + 1)]
        all_match = all_match and all(matches_h) and all(matches_num)
        records.append(
            {
                "b": b,
                "hilbert_values_s0_to_max": hs,
                "numerator_coeffs_s0_to_max": num,
                "expected_numerator_coeffs_s0_to_max": expected_num,
                "hilbert_values_match_expected": matches_h,
                "numerator_coeffs_match_expected": matches_num,
            }
        )
    return {
        "prime": args.prime,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "max_s": args.max_s,
        "singular_seconds": round(seconds, 3),
        "lead_monomial_count": len(leads),
        "script": str(script_path),
        "all_match": all_match,
        "records": records,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--b", type=int, action="append", default=None)
    parser.add_argument("--max-s", type=int, default=8)
    parser.add_argument("--prime", type=int, default=DEFAULT_P)
    parser.add_argument("--seed", type=int, default=7863)
    parser.add_argument(
        "--mode",
        choices=("diagonal", "sparseL_denseQ", "random_sparse", "dense"),
        default="sparseL_denseQ",
    )
    parser.add_argument("--sparse-l-terms", type=int, default=8)
    parser.add_argument("--sparse-q-terms", type=int, default=20)
    parser.add_argument("--timeout", type=float, default=120)
    parser.add_argument("--out", type=pathlib.Path)
    args = parser.parse_args()
    args.b = args.b if args.b is not None else list(range(4, 11))
    payload = run_check(args)
    text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
