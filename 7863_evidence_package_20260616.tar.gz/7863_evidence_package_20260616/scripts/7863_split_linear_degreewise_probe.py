#!/usr/bin/env python3
"""Degreewise split-linear endpoint probe for CICY 7863.

This is a finite-field verifier aid for

    N_c(r) = ker(ML_r) cap ker(MQ_r).

It first triangularizes the two-linear-row map ML_r, builds a basis of its
degreewise kernel, then computes the rank of MQ_r on that smaller basis.  This
is the degreewise analogue of the Singular route

    KL = syz(ML); QK = MQ * KL; K = KL * syz(QK).

The implementation is intentionally direct and certificate-oriented; it is not
yet a publication proof.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import time

ROOT = pathlib.Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "endpoint_nc_probe_7863", ROOT / "7863_endpoint_nc_probe.py"
)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_endpoint_nc_probe.py")
endpoint = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(endpoint)


P = endpoint.P
Vector = dict[int, int]


def p3(degree: int) -> int:
    if degree < 0:
        return 0
    return (degree + 3) * (degree + 2) * (degree + 1) // 6


def sym3_dim(degree: int) -> int:
    return p3(degree)


def kl_dim_formula(m: int, c: int) -> int:
    return (
        sym3_dim(c) * p3(m - 2 * c)
        - 2 * sym3_dim(c - 1) * p3(m - 2 * c - 1)
        + sym3_dim(c - 2) * p3(m - 2 * c - 2)
    )


def add_value(row: Vector, col: int, value: int) -> None:
    value %= P
    if not value:
        return
    new = (row.get(col, 0) + value) % P
    if new:
        row[col] = new
    else:
        row.pop(col, None)


def triangularize_rows(rows, pivot: str = "max") -> dict[int, Vector]:
    pivots: dict[int, Vector] = {}
    use_min = pivot == "min"
    for raw in rows:
        row = {c: v % P for c, v in raw if v % P}
        while row:
            pc = min(row) if use_min else max(row)
            pv = row[pc]
            prow = pivots.get(pc)
            if prow is None:
                inv = pow(pv, P - 2, P)
                pivots[pc] = {c: (v * inv) % P for c, v in row.items() if v % P}
                break
            for c, v in prow.items():
                add_value(row, c, -pv * v)
    return pivots


def q_columns(r: int, c: int, seed: int, mode: str, sparse_l_terms: int, sparse_q_terms: int):
    dims = endpoint.endpoint_dimensions(r, c)
    cols: list[Vector] = [dict() for _ in range(dims["cols"])]
    for target_row, row in enumerate(
        endpoint.row_entries_for_q_part(r, c, seed, mode, sparse_l_terms, sparse_q_terms)
    ):
        for source_col, value in row:
            cols[source_col][target_row] = value % P
    return cols, dims["q_rows"]


def kernel_vector_for_free_col(free_col: int, pivots: dict[int, Vector], pivot_order: list[int]) -> Vector:
    vec: Vector = {free_col: 1}
    for pc in pivot_order:
        row = pivots[pc]
        total = 0
        for col, coeff in row.items():
            if col != pc:
                total += coeff * vec.get(col, 0)
        total %= P
        if total:
            vec[pc] = (-total) % P
    return vec


def reduce_vector_rank(vecs, pivot: str = "max") -> tuple[int, int]:
    pivots: dict[int, Vector] = {}
    use_min = pivot == "min"
    max_fill = 0
    for raw in vecs:
        row = dict(raw)
        while row:
            pc = min(row) if use_min else max(row)
            pv = row[pc]
            prow = pivots.get(pc)
            if prow is None:
                inv = pow(pv, P - 2, P)
                normalized = {c: (v * inv) % P for c, v in row.items() if v % P}
                pivots[pc] = normalized
                max_fill = max(max_fill, len(normalized))
                break
            for c, v in prow.items():
                add_value(row, c, -pv * v)
    return len(pivots), max_fill


def restricted_q_images_by_substitution(
    qcols: list[Vector],
    pivots: dict[int, Vector],
    pivot: str,
) -> tuple[list[Vector], int]:
    pivot_cols = set(pivots)
    free_cols = [col for col in range(len(qcols)) if col not in pivot_cols]
    if pivot == "max":
        elimination_order = sorted(pivots, reverse=True)
    else:
        elimination_order = sorted(pivots)

    max_col_fill = 0
    for pc in elimination_order:
        image = qcols[pc]
        if not image:
            continue
        row = pivots[pc]
        for col, coeff in row.items():
            if col == pc:
                continue
            for target_row, value in image.items():
                add_value(qcols[col], target_row, -coeff * value)
            max_col_fill = max(max_col_fill, len(qcols[col]))
        qcols[pc] = {}
    return [qcols[col] for col in free_cols], max_col_fill


def split_linear_endpoint_rank(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
    pivot: str,
) -> dict[str, object]:
    started = time.time()
    dims = endpoint.endpoint_dimensions(r, c)
    ml_rows = endpoint.row_entries_for_linear_part(r, c, seed, mode, sparse_l_terms, sparse_q_terms)
    pivots = triangularize_rows(ml_rows, pivot=pivot)
    linear_seconds = time.time() - started
    pivot_cols = set(pivots)
    free_cols = [col for col in range(dims["cols"]) if col not in pivot_cols]

    q_started = time.time()
    qcols, q_rows = q_columns(r, c, seed, mode, sparse_l_terms, sparse_q_terms)
    q_build_seconds = time.time() - q_started

    image_started = time.time()

    restricted_images, substitution_max_fill = restricted_q_images_by_substitution(
        qcols, pivots, pivot
    )
    q_rank, q_max_fill = reduce_vector_rank(restricted_images, pivot=pivot)
    image_seconds = time.time() - image_started
    return {
        "c": c,
        "r": r,
        "seed": seed,
        "mode": mode,
        "sparse_l_terms": sparse_l_terms,
        "sparse_q_terms": sparse_q_terms,
        "prime": P,
        "pivot": pivot,
        "source_cols": dims["cols"],
        "linear_rows": dims["linear_rows"],
        "q_rows": q_rows,
        "linear_rank": len(pivots),
        "kl_dim": len(free_cols),
        "kl_dim_formula": kl_dim_formula(r, c),
        "kl_dim_formula_matches": kl_dim_formula(r, c) == len(free_cols),
        "q_rank_on_kl": q_rank,
        "kernel_dim": len(free_cols) - q_rank,
        "linear_seconds": round(linear_seconds, 3),
        "q_build_seconds": round(q_build_seconds, 3),
        "image_rank_seconds": round(image_seconds, 3),
        "seconds": round(time.time() - started, 3),
        "q_image_max_fill": q_max_fill,
        "substitution_max_fill": substitution_max_fill,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--c", type=int, required=True)
    parser.add_argument("--r", type=int, required=True)
    parser.add_argument("--seed", type=int, default=7863)
    parser.add_argument(
        "--mode",
        choices=("diagonal", "sparseL_denseQ", "random_sparse", "dense"),
        default="sparseL_denseQ",
    )
    parser.add_argument("--sparse-l-terms", type=int, default=8)
    parser.add_argument("--sparse-q-terms", type=int, default=20)
    parser.add_argument("--pivot", choices=("max", "min"), default="max")
    args = parser.parse_args()
    print(
        json.dumps(
            split_linear_endpoint_rank(
                args.r,
                args.c,
                args.seed,
                args.mode,
                args.sparse_l_terms,
                args.sparse_q_terms,
                args.pivot,
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
