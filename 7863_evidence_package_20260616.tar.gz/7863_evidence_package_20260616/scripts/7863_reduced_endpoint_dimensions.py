#!/usr/bin/env python3
"""Dimension oracle for the CICY 7863 Cell 9 reduced endpoint certificate.

This script does not build the finite-field matrices.  It records the exact
dimension targets for the reduced E/q/Koszul certificate suggested for c=9 and
c=10, and checks them against the conjectured endpoint numerator.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from math import comb
from typing import Any


W_DIM = 4


def pbinom(r: int) -> int:
    """P(r)=dim H^0(P^3,O(r)), with P(r)=0 for r<0."""
    return comb(r + 3, 3) if r >= 0 else 0


def h_sym_e(n: int, t: int) -> int:
    """h^0(Sym^n E(t)) from the symmetric-power BR resolution for t>=0."""
    if n < 0 or t < 0:
        return 0
    return (
        pbinom(n) * pbinom(t)
        - 2 * pbinom(n - 1) * pbinom(t - 1)
        + pbinom(n - 2) * pbinom(t - 2)
    )


def coeffs(c: int) -> dict[str, int]:
    return {
        "s": 6 * c - 4,
        "A": c * (c * c + 11) // 3,
        "B": c**3 - 3 * c**2 + 8 * c - 4,
        "C": (c - 1) * (c - 2) * (c - 3),
        "G": (c - 6) * (c - 2) * (c - 1) // 3,
    }


def m_dim(c: int, d: int) -> int:
    if d == 0:
        return pbinom(c) + pbinom(c - 4)
    if d == 1:
        return h_sym_e(c, 1)
    return h_sym_e(c, d) - h_sym_e(c - 2, d - 2)


def hilbert_from_numerator(c: int, d: int) -> int:
    """Coefficient at shifted degree d for numerator / (1-t)^4."""
    data = coeffs(c)
    terms = [
        (0, data["A"]),
        (1, -data["B"]),
        (2, data["C"]),
        (3, -data["G"]),
    ]
    total = 0
    for shift, value in terms:
        total += value * pbinom(d - shift)
    return total


def q_shape(c: int, d: int) -> dict[str, int]:
    rows = h_sym_e(c, d)
    cols = h_sym_e(c - 2, d - 2)
    return {"d": d, "rows": rows, "cols": cols, "target_rank": cols}


def koszul_dims(m_dims: list[int], beta_index: int) -> list[int]:
    """Dimensions in total shifted degree beta_index of the Koszul complex."""
    dims = []
    for i in range(beta_index, -1, -1):
        degree = beta_index - i
        dims.append(comb(W_DIM, i) * m_dims[degree])
    return dims


def old_relation_chain(c: int) -> dict[str, int]:
    data = coeffs(c)
    second_nonminimal = data["C"] + W_DIM
    third_nonminimal = data["G"] + W_DIM
    return {
        "generators": data["A"],
        "degree_one_rank": W_DIM * data["A"] - data["B"],
        "first_relations": data["B"],
        "second_raw": W_DIM * data["B"],
        "second_relation_count_nonminimal": second_nonminimal,
        "second_rank": W_DIM * data["B"] - second_nonminimal,
        "third_raw": W_DIM * second_nonminimal,
        "third_relation_count_nonminimal": third_nonminimal,
        "third_rank": W_DIM * second_nonminimal - third_nonminimal,
        "tail_raw": W_DIM * third_nonminimal,
        "tail_rank": W_DIM * third_nonminimal,
        "tail_relations": 0,
    }


def table_for_c(c: int) -> dict[str, Any]:
    data = coeffs(c)
    m_dims = [m_dim(c, d) for d in range(5)]
    hilbert_dims = [hilbert_from_numerator(c, d) for d in range(5)]
    if m_dims != hilbert_dims:
        raise AssertionError(
            f"reduced dimensions do not match numerator for c={c}: "
            f"{m_dims} != {hilbert_dims}"
        )
    return {
        "c": c,
        "coefficients": data,
        "m_dims_d0_to_d4": m_dims,
        "q_shapes_d2_to_d4": [q_shape(c, d) for d in range(2, 5)],
        "koszul": {
            "beta_1_matrix_rows_cols": [m_dims[1], W_DIM * m_dims[0]],
            "beta_1_expected_nullity": data["B"],
            "beta_2_complex_dims": koszul_dims(m_dims, 2),
            "beta_2_expected_homology": data["C"],
            "beta_3_complex_dims": koszul_dims(m_dims, 3),
            "beta_3_expected_homology": data["G"],
            "beta_4_complex_dims": koszul_dims(m_dims, 4),
            "beta_4_expected_homology": 0,
        },
        "old_iterated_relation_chain": old_relation_chain(c),
    }


def format_markdown(tables: list[dict[str, Any]]) -> str:
    lines = []
    for table in tables:
        c = table["c"]
        co = table["coefficients"]
        lines.append(f"## c={c}")
        lines.append("")
        lines.append(
            f"- s={co['s']}, A={co['A']}, B={co['B']}, C={co['C']}, G={co['G']}"
        )
        lines.append(f"- M dims d=0..4: {table['m_dims_d0_to_d4']}")
        lines.append("- q_d full-column-rank targets:")
        for q in table["q_shapes_d2_to_d4"]:
            lines.append(
                f"  - d={q['d']}: {q['rows']} x {q['cols']}, rank {q['target_rank']}"
            )
        kos = table["koszul"]
        rows, cols = kos["beta_1_matrix_rows_cols"]
        lines.append(
            f"- beta_1: matrix {rows} x {cols}, nullity "
            f"{kos['beta_1_expected_nullity']}"
        )
        lines.append(
            f"- beta_2: {kos['beta_2_complex_dims']}, homology "
            f"{kos['beta_2_expected_homology']}"
        )
        lines.append(
            f"- beta_3: {kos['beta_3_complex_dims']}, homology "
            f"{kos['beta_3_expected_homology']}"
        )
        lines.append(
            f"- beta_4 tail: {kos['beta_4_complex_dims']}, homology "
            f"{kos['beta_4_expected_homology']}"
        )
        old = table["old_iterated_relation_chain"]
        lines.append(
            "- old relation chain: "
            f"gen {old['generators']}, deg1 rank {old['degree_one_rank']}, "
            f"rel1 {old['first_relations']}, "
            f"rel2 {old['second_relation_count_nonminimal']} "
            f"(rank {old['second_rank']} / raw {old['second_raw']}), "
            f"rel3 {old['third_relation_count_nonminimal']} "
            f"(rank {old['third_rank']} / raw {old['third_raw']}), "
            f"tail rank {old['tail_rank']} / raw {old['tail_raw']}"
        )
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("c", nargs="*", type=int, default=[8, 9, 10])
    parser.add_argument("--json", action="store_true", help="emit JSON instead of Markdown")
    parser.add_argument("--output", type=Path, help="write output to this path")
    args = parser.parse_args()

    tables = [table_for_c(c) for c in args.c]
    if args.json:
        text = json.dumps(tables, indent=2, sort_keys=True) + "\n"
    else:
        text = format_markdown(tables) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
