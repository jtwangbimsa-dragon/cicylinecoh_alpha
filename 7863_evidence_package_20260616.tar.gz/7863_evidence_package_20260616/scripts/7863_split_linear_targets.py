#!/usr/bin/env python3
"""Closed target arithmetic for the CICY 7863 split-linear endpoint route.

The c=2..5 endpoint numerators are verified by Singular certificates.  The
c=6..10 entries produced here are certificate targets: use them to drive rank
runs, not as theorem statements.
"""

from __future__ import annotations

import argparse
import json
from math import comb


def p3(degree: int) -> int:
    return comb(degree + 3, 3) if degree >= 0 else 0


def kl_dim(m: int, c: int) -> int:
    """Dimension of the proposed split-linear kernel K_L(m,c)."""
    return (
        p3(c) * p3(m - 2 * c)
        - 2 * p3(c - 1) * p3(m - 2 * c - 1)
        + p3(c - 2) * p3(m - 2 * c - 2)
    )


def endpoint_support(c: int) -> int:
    return 6 * c - 4


def endpoint_candidate_numerator(c: int) -> dict[int, int]:
    """Heavy/Codex candidate numerator for N_c.

    This reproduces the verified c=2..5 numerators and the current N_6 target.
    For c>=6 it must be read as a target for finite-field certificates.
    """
    if c < 2:
        raise ValueError("c must be at least 2")
    s = endpoint_support(c)
    coeffs = [
        c * (c * c + 11) // 3,
        -(c**3 - 3 * c * c + 8 * c - 4),
        (c - 1) * (c - 2) * (c - 3),
        -((c - 6) * (c - 2) * (c - 1) // 3),
    ]
    return {s + j: coeff for j, coeff in enumerate(coeffs) if coeff}


def endpoint_candidate_value(c: int, m: int) -> int:
    return sum(coeff * p3(m - degree) for degree, coeff in endpoint_candidate_numerator(c).items())


def n6_target(m: int) -> int:
    """Compatibility wrapper for the current N_6 target."""
    return endpoint_candidate_value(6, m)


def q_rank_target(m: int, c: int) -> int:
    return kl_dim(m, c) - endpoint_candidate_value(c, m)


def delta1_rank(m: int, c: int) -> int:
    """Rank of the first Koszul relation map for K_L(m,c)."""
    return p3(c) * p3(m - 2 * c) - kl_dim(m, c)


def n6_block_rank_target(m: int) -> int:
    """Target rank of [delta_1^4 R_m^6] in the F0/F1 split certificate."""
    return delta1_rank(m + 2, 4) + q_rank_target(m, 6)


def cell9_dims(m: int, c: int, endpoint_value: int = 0) -> dict[str, int]:
    c3 = p3(m + 4) * p3(c - 4)
    c2 = 2 * p3(m + 3) * p3(c - 3) + p3(m + 2) * p3(c - 2)
    c1 = p3(m + 2) * p3(c - 2) + 2 * p3(m + 1) * p3(c - 1)
    c0 = p3(m) * p3(c)
    return {
        "C3": c3,
        "C2": c2,
        "C1": c1,
        "C0": c0,
        "reduced_middle_domain": c2 - c3,
        "ker_d1_dim": c1 - c0 + endpoint_value,
    }


def euler_cell9(m: int, c: int) -> int:
    return (
        p3(m + 4) * p3(c - 4)
        - 2 * p3(m + 3) * p3(c - 3)
        + 2 * p3(m + 1) * p3(c - 1)
        - p3(m) * p3(c)
    )


def predicted_homology(m: int, c: int) -> dict[str, int]:
    endpoint = endpoint_candidate_value(c, m)
    d = euler_cell9(m, c) + endpoint
    return {
        "H3": 0,
        "H2": max(-d, 0),
        "H1": max(d, 0),
        "H0": endpoint,
        "D": d,
        "E": euler_cell9(m, c),
    }


def middle_rank_target(m: int, c: int) -> int:
    endpoint_value = endpoint_candidate_value(c, m)
    dims = cell9_dims(m, c, endpoint_value)
    return min(dims["reduced_middle_domain"], dims["ker_d1_dim"])


def record(m: int, c: int) -> dict[str, int | None]:
    endpoint = endpoint_candidate_value(c, m)
    dims = cell9_dims(m, c, endpoint)
    hom = predicted_homology(m, c)
    return {
        "c": c,
        "m": m,
        "support": endpoint_support(c),
        "endpoint_candidate": endpoint,
        "candidate_numerator": endpoint_candidate_numerator(c),
        "kl_dim": kl_dim(m, c),
        "n6_target": n6_target(m) if c == 6 else None,
        "q_rank_target": q_rank_target(m, c),
        "delta1_rank_c_minus_2_target": delta1_rank(m + 2, c - 2) if c >= 2 else None,
        "n6_block_rank_target": n6_block_rank_target(m) if c == 6 else None,
        "middle_reduced_domain": dims["reduced_middle_domain"],
        "middle_ker_d1_dim": dims["ker_d1_dim"],
        "middle_rank_target": middle_rank_target(m, c),
        "E": hom["E"],
        "D": hom["D"],
        "predicted_H3": hom["H3"],
        "predicted_H2": hom["H2"],
        "predicted_H1": hom["H1"],
        "predicted_H0": hom["H0"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--c", type=int, default=6)
    parser.add_argument("--min-m", type=int)
    parser.add_argument("--max-m", type=int)
    parser.add_argument("--support-window", type=int, default=4)
    args = parser.parse_args()
    min_m = args.min_m if args.min_m is not None else endpoint_support(args.c)
    max_m = args.max_m if args.max_m is not None else endpoint_support(args.c) + args.support_window
    print(
        json.dumps(
            {
                "status": "candidate targets; c=2..5 verified elsewhere, c>=6 unverified until certified",
                "c": args.c,
                "candidate_numerator": endpoint_candidate_numerator(args.c),
                "records": [record(m, args.c) for m in range(min_m, max_m + 1)],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
