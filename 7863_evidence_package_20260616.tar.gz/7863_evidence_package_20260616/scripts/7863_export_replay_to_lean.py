#!/usr/bin/env python3
"""Export strict CICY 7863 replay JSON into a Lean data module.

The replay checkers remain the executable certificate replay layer.  This
exporter packages their replay outputs, source hashes, dimensions, and status
flags into Lean data so the finite-box bridge cannot depend only on prose logs.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CERT_DIR = ROOT / "certificates" / "7863_cell9_strict_replay"
OUT = ROOT / "LeanProofs" / "PaperVersion" / "Section32" / "Case7863ReplayData.lean"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> dict:
    with path.open() as f:
        return json.load(f)


def lean_str(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def vc(c: int) -> str:
    return f".c{c}"


def bool_lit(value: bool) -> str:
    return "true" if value else "false"


def all_true(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, dict):
        return all(all_true(v) for v in value.values())
    if isinstance(value, list):
        return all(all_true(v) for v in value)
    return True


def nat(value) -> int:
    return int(value)


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


def replay_batch_sha256(paths: list[Path]) -> str:
    h = hashlib.sha256()
    for path in sorted(paths, key=lambda p: rel(p)):
        name = rel(path).encode()
        data = path.read_bytes()
        h.update(len(name).to_bytes(8, "big"))
        h.update(name)
        h.update(len(data).to_bytes(8, "big"))
        h.update(data)
    return h.hexdigest()


def qrank_records() -> list[str]:
    rows: list[str] = []
    replay_paths = sorted(
        CERT_DIR.glob("c*_d*_qrank_full_column_rank.replay.json"),
        key=lambda p: (nat(load_json(p)["c"]), nat(load_json(p)["d"])),
    )
    for replay_path in replay_paths:
        cert_path = replay_path.with_name(replay_path.name.replace(".replay.json", ".json"))
        replay = load_json(replay_path)
        cert = load_json(cert_path)
        con = cert["construction"]
        src = con["source"]
        tgt = con["target"]
        source_files = cert["source_files"]
        rows.append(
            "\n  { "
            f"c := {vc(nat(replay['c']))}, "
            f"d := {nat(replay['d'])}, "
            f"prime := {nat(replay['prime'])}, "
            f"rows := {nat(replay['matrix_rows'])}, "
            f"cols := {nat(replay['matrix_cols'])}, "
            f"rankLowerBound := {nat(replay['rank_lower_bound_from_minor'])}, "
            f"rankUpperBound := {nat(replay['rank_upper_bound_from_source_dim'])}, "
            f"detModP := {nat(replay['observed_det_mod_p'])}, "
            f"sourceDim := {nat(src['dim'])}, "
            f"targetDim := {nat(tgt['dim'])}, "
            f"sourceAmbientDim := {nat(src['ambient_dim'])}, "
            f"targetAmbientDim := {nat(tgt['ambient_dim'])}, "
            f"sourceRelationRank := {nat(src['relation_rank'])}, "
            f"targetRelationRank := {nat(tgt['relation_rank'])}, "
            f"sourceBasisName := {lean_str(src['name'])}, "
            f"targetBasisName := {lean_str(tgt['name'])}, "
            f"sourceFreeRowsSha256 := {lean_str(src['free_rows_sha256'])}, "
            f"targetFreeRowsSha256 := {lean_str(tgt['free_rows_sha256'])}, "
            f"matrixSparseColumnsSha256 := {lean_str(replay['observed_matrix_sparse_columns_sha256'])}, "
            f"sourceCertificateSha256 := {lean_str(sha256_file(cert_path))}, "
            f"replayCertificateSha256 := {lean_str(sha256_file(replay_path))}, "
            f"generatorCheckerSha256 := {lean_str(source_files.get('generator_checker_sha256', ''))}, "
            f"matrixRecipeSha256 := {lean_str(source_files.get('matrix_recipe_sha256', ''))}, "
            f"replayStatus := {lean_str(replay['status'])}, "
            f"allReplayChecksPassed := {bool_lit(all_true(replay['checks']))}, "
            f"fullColumnRank := {bool_lit(bool(replay['full_column_rank']))} "
            "}"
        )
    return rows


def koszul_records() -> list[str]:
    rows: list[str] = []
    replay_paths = sorted(
        CERT_DIR.glob("full_koszul_c*.replay.json"),
        key=lambda p: nat(load_json(p)["c"]),
    )
    for replay_path in replay_paths:
        cert_path = replay_path.with_name(replay_path.name.replace(".replay.json", ".json"))
        replay = load_json(replay_path)
        cert = load_json(cert_path)
        dims = replay["module_dims_M0_to_M4"]
        coeffs = replay["numerator_coefficients_from_euler"]
        source_files = cert["source_files"]
        rows.append(
            "\n  { "
            f"c := {vc(nat(replay['c']))}, "
            f"prime := {nat(replay['prime'])}, "
            f"m0Dim := {nat(dims['0'])}, "
            f"m1Dim := {nat(dims['1'])}, "
            f"m2Dim := {nat(dims['2'])}, "
            f"m3Dim := {nat(dims['3'])}, "
            f"m4Dim := {nat(dims['4'])}, "
            f"eulerDegree1 := {int(coeffs['degree_1'])}, "
            f"eulerDegree2 := {int(coeffs['degree_2'])}, "
            f"eulerDegree3 := {int(coeffs['degree_3'])}, "
            f"eulerDegree4 := {int(coeffs['degree_4'])}, "
            f"complexCompositionsZero := {bool_lit(all(v == 0 for v in replay['complex_checks'].values()))}, "
            f"allRankChecksPassed := {bool_lit(all_true(replay['rank_checks']))}, "
            f"allReplayChecksPassed := {bool_lit(all_true(replay['checks']))}, "
            f"sourceCertificateSha256 := {lean_str(sha256_file(cert_path))}, "
            f"replayCertificateSha256 := {lean_str(sha256_file(replay_path))}, "
            f"generatorCheckerSha256 := {lean_str(source_files.get('generator_checker_sha256', ''))}, "
            f"matrixRecipeSha256 := {lean_str(source_files.get('matrix_recipe_sha256', ''))}, "
            f"qrankReplayHelperSha256 := {lean_str(source_files.get('qrank_replay_helper_sha256', ''))}, "
            f"replayStatus := {lean_str(replay['status'])} "
            "}"
        )
    return rows


def mu_records() -> list[str]:
    rows: list[str] = []
    replay_paths = sorted(
        CERT_DIR.glob("mu_c*.replay.json"),
        key=lambda p: nat(load_json(p)["c"]),
    )
    for replay_path in replay_paths:
        cert_path = replay_path.with_name(replay_path.name.replace(".replay.json", ".json"))
        replay = load_json(replay_path)
        cert = load_json(cert_path)
        dims = replay["module_dims_M1_to_M4"]
        source_files = cert["source_files"]
        rows.append(
            "\n  { "
            f"c := {vc(nat(replay['c']))}, "
            f"prime := {nat(replay['prime'])}, "
            f"m0Dim := {nat(replay['m0_dim'])}, "
            f"regularDim := {nat(replay['regular_dim'])}, "
            f"topDim := {nat(replay['top_dim'])}, "
            f"m1Dim := {nat(dims['1'])}, "
            f"m2Dim := {nat(dims['2'])}, "
            f"m3Dim := {nat(dims['3'])}, "
            f"m4Dim := {nat(dims['4'])}, "
            f"m0SquaresCommute := {bool_lit(bool(replay['all_m0_m1_squares_commute']))}, "
            f"positiveSquaresCommute := {bool_lit(bool(replay['all_positive_squares_commute']))}, "
            f"allM0EntryChecksPassed := {bool_lit(all_true(replay['m0_entry_checks']))}, "
            f"allPositiveEntryChecksPassed := {bool_lit(all_true(replay['positive_entry_checks']))}, "
            f"allReplayChecksPassed := {bool_lit(all_true(replay['checks']))}, "
            f"sourceCertificateSha256 := {lean_str(sha256_file(cert_path))}, "
            f"replayCertificateSha256 := {lean_str(sha256_file(replay_path))}, "
            f"generatorCheckerSha256 := {lean_str(source_files.get('generator_checker_sha256', ''))}, "
            f"matrixRecipeSha256 := {lean_str(source_files.get('matrix_recipe_sha256', ''))}, "
            f"qrankReplayHelperSha256 := {lean_str(source_files.get('qrank_replay_helper_sha256', ''))}, "
            f"replayStatus := {lean_str(replay['status'])} "
            "}"
        )
    return rows


def main() -> None:
    json_paths = sorted(CERT_DIR.glob("*.json"))
    q_rows = qrank_records()
    k_rows = koszul_records()
    m_rows = mu_records()
    text = f"""import PaperVersion.Section32.Case7863

namespace PaperVersion
namespace Section32
namespace Case7863
namespace ReplayData

/-!
Lean-consumable export of the strict Python replay artifacts for CICY 7863.

Generated by `7863_export_replay_to_lean.py` from
`certificates/7863_cell9_strict_replay/*.json`.

The batch checksum below is SHA256 over sorted `(relative path, bytes)` pairs
for every JSON file in the replay directory.
-/

def replayBatchSha256 : String :=
  {lean_str(replay_batch_sha256(json_paths))}

def replayBatchJsonFileCount : Nat := {len(json_paths)}

structure QRankReplayData where
  c : VerifiedC
  d : Nat
  prime : Nat
  rows : Nat
  cols : Nat
  rankLowerBound : Nat
  rankUpperBound : Nat
  detModP : Nat
  sourceDim : Nat
  targetDim : Nat
  sourceAmbientDim : Nat
  targetAmbientDim : Nat
  sourceRelationRank : Nat
  targetRelationRank : Nat
  sourceBasisName : String
  targetBasisName : String
  sourceFreeRowsSha256 : String
  targetFreeRowsSha256 : String
  matrixSparseColumnsSha256 : String
  sourceCertificateSha256 : String
  replayCertificateSha256 : String
  generatorCheckerSha256 : String
  matrixRecipeSha256 : String
  replayStatus : String
  allReplayChecksPassed : Bool
  fullColumnRank : Bool
deriving DecidableEq, Repr

def QRankReplayData.accepts (r : QRankReplayData) : Bool :=
  decide (r.prime = 1000003 /\\
    r.rows = r.targetDim /\\
    r.cols = r.sourceDim /\\
    r.rankLowerBound = r.cols /\\
    r.rankUpperBound = r.cols /\\
    r.cols <= r.rows /\\
    r.sourceDim + r.sourceRelationRank = r.sourceAmbientDim /\\
    r.targetDim + r.targetRelationRank = r.targetAmbientDim) &&
  r.allReplayChecksPassed &&
  r.fullColumnRank &&
  (r.replayStatus == "passed")

def qRankReplayRows : List QRankReplayData :=
  [{','.join(q_rows)}
  ]

structure FullKoszulReplayData where
  c : VerifiedC
  prime : Nat
  m0Dim : Nat
  m1Dim : Nat
  m2Dim : Nat
  m3Dim : Nat
  m4Dim : Nat
  eulerDegree1 : Int
  eulerDegree2 : Int
  eulerDegree3 : Int
  eulerDegree4 : Int
  complexCompositionsZero : Bool
  allRankChecksPassed : Bool
  allReplayChecksPassed : Bool
  sourceCertificateSha256 : String
  replayCertificateSha256 : String
  generatorCheckerSha256 : String
  matrixRecipeSha256 : String
  qrankReplayHelperSha256 : String
  replayStatus : String
deriving DecidableEq, Repr

instance : Inhabited FullKoszulReplayData where
  default :=
    { c := .c4
      prime := 0
      m0Dim := 0
      m1Dim := 0
      m2Dim := 0
      m3Dim := 0
      m4Dim := 0
      eulerDegree1 := 0
      eulerDegree2 := 0
      eulerDegree3 := 0
      eulerDegree4 := 0
      complexCompositionsZero := false
      allRankChecksPassed := false
      allReplayChecksPassed := false
      sourceCertificateSha256 := ""
      replayCertificateSha256 := ""
      generatorCheckerSha256 := ""
      matrixRecipeSha256 := ""
      qrankReplayHelperSha256 := ""
      replayStatus := "" }

def FullKoszulReplayData.accepts (r : FullKoszulReplayData) : Bool :=
  decide (r.prime = 1000003) &&
  r.complexCompositionsZero &&
  r.allRankChecksPassed &&
  r.allReplayChecksPassed &&
  (r.replayStatus == "passed")

def FullKoszulReplayData.coeffList (r : FullKoszulReplayData) : List Int :=
  [Int.ofNat r.m0Dim, r.eulerDegree1, r.eulerDegree2, r.eulerDegree3, r.eulerDegree4]

def fullKoszulReplayRows : List FullKoszulReplayData :=
  [{','.join(k_rows)}
  ]

def fullKoszulReplayFor : VerifiedC -> FullKoszulReplayData
  | .c4 => fullKoszulReplayRows[0]!
  | .c5 => fullKoszulReplayRows[1]!
  | .c6 => fullKoszulReplayRows[2]!
  | .c7 => fullKoszulReplayRows[3]!
  | .c8 => fullKoszulReplayRows[4]!
  | .c9 => fullKoszulReplayRows[5]!
  | .c10 => fullKoszulReplayRows[6]!

def replayedNumeratorCoeffList (vc : VerifiedC) : List Int :=
  (fullKoszulReplayFor vc).coeffList

structure MuReplayData where
  c : VerifiedC
  prime : Nat
  m0Dim : Nat
  regularDim : Nat
  topDim : Nat
  m1Dim : Nat
  m2Dim : Nat
  m3Dim : Nat
  m4Dim : Nat
  m0SquaresCommute : Bool
  positiveSquaresCommute : Bool
  allM0EntryChecksPassed : Bool
  allPositiveEntryChecksPassed : Bool
  allReplayChecksPassed : Bool
  sourceCertificateSha256 : String
  replayCertificateSha256 : String
  generatorCheckerSha256 : String
  matrixRecipeSha256 : String
  qrankReplayHelperSha256 : String
  replayStatus : String
deriving DecidableEq, Repr

def MuReplayData.accepts (r : MuReplayData) : Bool :=
  decide (r.prime = 1000003 /\\ r.regularDim + r.topDim = r.m0Dim) &&
  r.m0SquaresCommute &&
  r.positiveSquaresCommute &&
  r.allM0EntryChecksPassed &&
  r.allPositiveEntryChecksPassed &&
  r.allReplayChecksPassed &&
  (r.replayStatus == "passed")

def muReplayRows : List MuReplayData :=
  [{','.join(m_rows)}
  ]

def qRankReplayCoveredPairs : List (Nat × Nat) :=
  qRankReplayRows.map (fun r => (r.c.toNat, r.d))

def expectedQRankReplayPairs : List (Nat × Nat) :=
  [(4, 2), (4, 3), (4, 4),
   (5, 2), (5, 3), (5, 4),
   (6, 2), (6, 3), (6, 4),
   (7, 2), (7, 3), (7, 4),
   (8, 2), (8, 3), (8, 4),
   (9, 2), (9, 3), (9, 4),
   (10, 2), (10, 3), (10, 4)]

def fullKoszulReplayCoveredC : List Nat :=
  fullKoszulReplayRows.map (fun r => r.c.toNat)

def muReplayCoveredC : List Nat :=
  muReplayRows.map (fun r => r.c.toNat)

theorem replayBatchJsonFileCount_eq : replayBatchJsonFileCount = 70 := by
  rfl

theorem qRankReplayRows_count : qRankReplayRows.length = 21 := by
  rfl

theorem fullKoszulReplayRows_count : fullKoszulReplayRows.length = 7 := by
  rfl

theorem muReplayRows_count : muReplayRows.length = 7 := by
  rfl

theorem qRankReplayRows_all_accept :
    qRankReplayRows.all QRankReplayData.accepts = true := by
  native_decide

theorem fullKoszulReplayRows_all_accept :
    fullKoszulReplayRows.all FullKoszulReplayData.accepts = true := by
  native_decide

theorem muReplayRows_all_accept :
    muReplayRows.all MuReplayData.accepts = true := by
  native_decide

theorem qRankReplayCoveredPairs_eq_expected :
    qRankReplayCoveredPairs = expectedQRankReplayPairs := by
  native_decide

theorem fullKoszulReplayCoveredC_eq_verified :
    fullKoszulReplayCoveredC = verifiedCValues := by
  native_decide

theorem muReplayCoveredC_eq_verified :
    muReplayCoveredC = verifiedCValues := by
  native_decide

theorem replayedNumeratorCoeffList_eq_numeratorCoeffList (vc : VerifiedC) :
    replayedNumeratorCoeffList vc = numeratorCoeffList vc := by
  cases vc <;> native_decide

theorem replayedNumeratorCoeffList_eq_eulerCoeffList (vc : VerifiedC) :
    replayedNumeratorCoeffList vc = eulerCoeffList vc := by
  rw [replayedNumeratorCoeffList_eq_numeratorCoeffList, eulerCoeffList_eq_numeratorCoeffList]

end ReplayData
end Case7863
end Section32
end PaperVersion
"""
    OUT.write_text(text)
    print(f"wrote {OUT}")
    print(f"json_count {len(json_paths)}")
    print(f"batch_sha256 {replay_batch_sha256(json_paths)}")


if __name__ == "__main__":
    main()
