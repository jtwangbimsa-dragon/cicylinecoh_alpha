#!/usr/bin/env python3
"""Export and replay Cell 9 left-injectivity minors for CICY 7863.

This script extracts compact nonzero-minor witnesses for the leftmost
full-column-rank map used in the finite-box Cell 9 replay.  The map is the
top reduced Koszul differential

    d_L4M0_to_L3M1

in the existing full reduced Koszul package.  For each c=4..10 it records a
square minor using all columns and the pivot rows found by exact elimination
over F_1000003.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import sys
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
FULL_PATH = ROOT / "7863_full_koszul_certificate_replay.py"
SPEC = importlib.util.spec_from_file_location("full7863", FULL_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_full_koszul_certificate_replay.py")
full = importlib.util.module_from_spec(SPEC)
sys.modules["full7863"] = full
SPEC.loader.exec_module(full)

probe = full.probe
qreplay = full.qreplay
P = full.P
Vector = dict[int, int]


MAP_NAME = "d_L4M0_to_L3M1"


def build_left_map(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    modules, _q_meta = probe.build_positive_modules(
        c, seed, mode, sparse_l_terms, sparse_q_terms
    )
    module_dims = {0: probe.pbinom(c) + probe.pbinom(c - 4)}
    module_dims.update({d: modules[d].dim for d in range(1, 5)})

    mu: dict[int, dict[int, list[Vector]]] = {0: {}}
    for x_var in range(4):
        mu[0][x_var] = probe.mu0_columns(
            c, x_var, seed, mode, sparse_l_terms, sparse_q_terms
        )
    for d in (1, 2, 3):
        mu[d] = {}
        for x_var in range(4):
            mu[d][x_var] = probe.positive_mu_columns(modules, d, x_var)

    cols = probe.koszul_diff_columns(4, 0, module_dims, mu)
    rows = full.target_rows(module_dims, 4, 0)
    return {
        "cols": cols,
        "rows": rows,
        "module_dims": module_dims,
        "matrix_hash": qreplay.matrix_hash(cols),
    }


def make_certificate(args: argparse.Namespace) -> dict[str, Any]:
    started = time.time()
    data = build_left_map(
        args.c,
        args.seed,
        args.mode,
        args.sparse_l_terms,
        args.sparse_q_terms,
    )
    cols: list[Vector] = data["cols"]
    pivot_rows = [int(row) for row in probe.build_pivots(cols).keys()]
    minor = qreplay.dense_minor(cols, pivot_rows)
    det = qreplay.det_mod_p(minor, P)
    if len(pivot_rows) != len(cols) or det == 0:
        raise RuntimeError(
            f"{MAP_NAME} is not certified full column rank for c={args.c}: "
            f"pivots={len(pivot_rows)}, cols={len(cols)}, det={det}"
        )
    return {
        "certificate_type": "cicy_7863_cell9_left_injectivity_minor_v1",
        "statement": (
            "The leftmost reduced Koszul map d_L4M0_to_L3M1 has full "
            "column rank over F_p for the recorded Cell 9 finite-box "
            "specialization."
        ),
        "cicy": 7863,
        "cell": 9,
        "c": args.c,
        "paper_b": args.c,
        "prime": P,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "map": {
            "name": MAP_NAME,
            "source": "Lambda^4 M0",
            "target": "Lambda^3 M1",
            "wedge_rank": 4,
            "module_degree": 0,
            "matrix_rows": int(data["rows"]),
            "matrix_cols": len(cols),
            "matrix_sparse_columns_sha256": data["matrix_hash"],
            "module_dims_M0_to_M4": {
                str(d): int(data["module_dims"][d]) for d in range(5)
            },
        },
        "witness": {
            "kind": "full_column_rank_minor_mod_p",
            "pivot_rows": pivot_rows,
            "column_order": "left-map source basis order 0..matrix_cols-1",
            "det_mod_p": det,
        },
        "source_files": {
            "generator_checker": pathlib.Path(__file__).name,
            "generator_checker_sha256": qreplay.sha256_file(pathlib.Path(__file__)),
            "full_koszul_helper": FULL_PATH.name,
            "full_koszul_helper_sha256": qreplay.sha256_file(FULL_PATH),
            "matrix_recipe": qreplay.PROBE_PATH.name,
            "matrix_recipe_sha256": qreplay.sha256_file(qreplay.PROBE_PATH),
        },
        "created_unix_time": time.time(),
        "seconds": round(time.time() - started, 6),
    }


def replay_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    required_type = "cicy_7863_cell9_left_injectivity_minor_v1"
    if cert.get("certificate_type") != required_type:
        raise ValueError("unexpected certificate_type")
    if cert.get("prime") != P:
        raise ValueError("certificate prime does not match checker prime")
    data = build_left_map(
        int(cert["c"]),
        int(cert["seed"]),
        str(cert["mode"]),
        int(cert["sparse_l_terms"]),
        int(cert["sparse_q_terms"]),
    )
    cols: list[Vector] = data["cols"]
    witness = cert["witness"]
    pivot_rows = [int(row) for row in witness["pivot_rows"]]
    observed_det = qreplay.det_mod_p(qreplay.dense_minor(cols, pivot_rows), P)
    checks = {
        "matrix_rows_match": int(data["rows"]) == int(cert["map"]["matrix_rows"]),
        "matrix_cols_match": len(cols) == int(cert["map"]["matrix_cols"]),
        "matrix_hash_match": data["matrix_hash"]
        == cert["map"]["matrix_sparse_columns_sha256"],
        "pivot_row_count_match": len(pivot_rows) == len(cols),
        "pivot_rows_in_bounds": all(0 <= row < int(data["rows"]) for row in pivot_rows),
        "determinant_matches_certificate": observed_det == int(witness["det_mod_p"]),
        "determinant_nonzero": observed_det % P != 0,
    }
    passed = all(checks.values())
    return {
        "status": "passed" if passed else "failed",
        "certificate_type": cert["certificate_type"],
        "cicy": cert["cicy"],
        "cell": cert["cell"],
        "c": cert["c"],
        "paper_b": cert.get("paper_b", cert["c"]),
        "prime": P,
        "map_name": MAP_NAME,
        "matrix_rows": int(data["rows"]),
        "matrix_cols": len(cols),
        "rank_lower_bound_from_minor": len(cols)
        if checks["determinant_nonzero"]
        else 0,
        "rank_upper_bound_from_source_dim": len(cols),
        "full_column_rank": passed,
        "observed_det_mod_p": observed_det,
        "observed_matrix_sparse_columns_sha256": data["matrix_hash"],
        "checks": checks,
    }


def write_json(path: pathlib.Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def generate_one(args: argparse.Namespace) -> None:
    cert = make_certificate(args)
    write_json(args.out, cert)
    if args.replay_out:
        replay = replay_certificate(cert)
        write_json(args.replay_out, replay)
        if replay["status"] != "passed":
            raise RuntimeError(f"replay failed for c={args.c}")


def generate_all(args: argparse.Namespace) -> None:
    args.out_dir.mkdir(parents=True, exist_ok=True)
    summary = []
    for c in range(args.c_min, args.c_max + 1):
        local = argparse.Namespace(**vars(args))
        local.c = c
        cert_path = args.out_dir / f"left_injectivity_c{c}.json"
        replay_path = args.out_dir / f"left_injectivity_c{c}.replay.json"
        local.out = cert_path
        local.replay_out = replay_path
        cert = make_certificate(local)
        replay = replay_certificate(cert)
        write_json(cert_path, cert)
        write_json(replay_path, replay)
        if replay["status"] != "passed":
            raise RuntimeError(f"replay failed for c={c}")
        summary.append(
            {
                "c": c,
                "paper_b": c,
                "matrix_rows": cert["map"]["matrix_rows"],
                "matrix_cols": cert["map"]["matrix_cols"],
                "minor_size": len(cert["witness"]["pivot_rows"]),
                "det_mod_p": cert["witness"]["det_mod_p"],
                "replay_status": replay["status"],
            }
        )
    write_json(args.out_dir / "summary.json", {"prime": P, "items": summary})


def replay_one(args: argparse.Namespace) -> None:
    cert = json.loads(args.certificate.read_text())
    replay = replay_certificate(cert)
    if args.out:
        write_json(args.out, replay)
    else:
        print(json.dumps(replay, indent=2, sort_keys=True))
    if replay["status"] != "passed":
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--seed", type=int, default=7863)
    common.add_argument(
        "--mode",
        choices=["diagonal", "sparseL_denseQ", "random_sparse", "dense"],
        default="sparseL_denseQ",
    )
    common.add_argument("--sparse-l-terms", type=int, default=8)
    common.add_argument("--sparse-q-terms", type=int, default=20)

    gen = sub.add_parser("generate", parents=[common])
    gen.add_argument("--c", type=int, required=True)
    gen.add_argument("--out", type=pathlib.Path, required=True)
    gen.add_argument("--replay-out", type=pathlib.Path)
    gen.set_defaults(func=generate_one)

    gen_all = sub.add_parser("generate-all", parents=[common])
    gen_all.add_argument("--c-min", type=int, default=4)
    gen_all.add_argument("--c-max", type=int, default=10)
    gen_all.add_argument(
        "--out-dir",
        type=pathlib.Path,
        default=ROOT / "certificates" / "7863_cell9_left_injectivity_minors",
    )
    gen_all.set_defaults(func=generate_all)

    rep = sub.add_parser("replay")
    rep.add_argument("certificate", type=pathlib.Path)
    rep.add_argument("--out", type=pathlib.Path)
    rep.set_defaults(func=replay_one)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
