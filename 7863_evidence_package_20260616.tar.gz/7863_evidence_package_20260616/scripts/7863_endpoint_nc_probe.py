#!/usr/bin/env python3
"""Finite-field rank probe for the CICY 7863 endpoint modules N_2, N_3.

This is a verifier aid, not a proof by itself.  It computes

    N_c(r) = dim ker alpha_r^(c)

for a deterministic finite-field specialization of the endpoint map

    A_r \otimes Sym^c(V)^*
      -> (A_{r+1} \otimes Sym^{c-1}(V)^*)^2
         \oplus A_{r+2} \otimes Sym^{c-2}(V)^*

where L1,L2 have bidegree (1,1) and Q has bidegree (2,2).  The y part acts
by contraction and the x part by multiplication.
"""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import random
import struct
import subprocess
import time
from functools import lru_cache

P = 1_000_003
ROOT = pathlib.Path(__file__).resolve().parent
RANK_BIN = pathlib.Path("/Users/juntaowang/Documents/more cicy/scripts/rank_sparse_mod")
OUT_DIR = ROOT / "tmp" / "7863_endpoint_degreewise_rank"


def inv(a: int) -> int:
    return pow(a % P, P - 2, P)


@lru_cache(maxsize=None)
def monoms_deg(n: int, vars_count: int = 4) -> tuple[tuple[int, ...], ...]:
    if n < 0:
        return ()
    out: list[tuple[int, ...]] = []

    def rec(i: int, rem: int, acc: list[int]) -> None:
        if i == vars_count - 1:
            out.append(tuple(acc + [rem]))
            return
        for k in range(rem + 1):
            rec(i + 1, rem - k, acc + [k])

    rec(0, n, [])
    return tuple(out)


def add_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(x + y for x, y in zip(a, b))


def sub_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...] | None:
    out = tuple(x - y for x, y in zip(a, b))
    if any(x < 0 for x in out):
        return None
    return out


def falling_for_multi(beta: tuple[int, ...], nu: tuple[int, ...]) -> int:
    coeff = 1
    for b, n in zip(beta, nu):
        if n > b:
            return 0
        term = 1
        for j in range(n):
            term *= b - j
        coeff *= term
    return coeff % P


def terms(
    seed: int,
    mode: str,
    sparse_l_terms: int = 8,
    sparse_q_terms: int = 20,
) -> tuple[list[tuple[int, tuple[int, ...], tuple[int, ...]]], ...]:
    """Return (L1 terms, L2 terms, Q terms).

    Each term is (coeff, x_exp, y_exp).  We use deterministic pseudorandom
    dense coefficients to avoid the extra symmetries of a diagonal example.
    """
    x1 = monoms_deg(1)
    x2 = monoms_deg(2)
    y1 = monoms_deg(1)
    y2 = monoms_deg(2)

    if mode == "diagonal":
        e = monoms_deg(1)
        coeffs = [2, 3, 5, 7]
        l1 = [(1, e[i], e[i]) for i in range(4)]
        l2 = [(i + 1, e[i], e[i]) for i in range(4)]
        q = [(coeffs[i], tuple(2 * v for v in e[i]), tuple(2 * v for v in e[i])) for i in range(4)]
        return l1, l2, q

    if mode == "sparseL_denseQ":
        e = monoms_deg(1)
        l1 = [(1, e[i], e[i]) for i in range(4)]
        l2 = [(i + 1, e[i], e[i]) for i in range(4)]
        rng = random.Random(seed)

        def coeff() -> int:
            return rng.randrange(1, P)

        q = [(coeff(), xe, ye) for xe in x2 for ye in y2]
        return l1, l2, q

    if mode == "random_sparse":
        rng = random.Random(seed)

        def sample_terms(xmons, ymons, count):
            pool = [(xe, ye) for xe in xmons for ye in ymons]
            count = min(count, len(pool))
            return [
                (rng.randrange(1, P), xe, ye)
                for xe, ye in rng.sample(pool, count)
            ]

        l1 = sample_terms(x1, y1, sparse_l_terms)
        l2 = sample_terms(x1, y1, sparse_l_terms)
        q = sample_terms(x2, y2, sparse_q_terms)
        return l1, l2, q

    if mode != "dense":
        raise ValueError("mode must be diagonal, sparseL_denseQ, random_sparse, or dense")

    rng = random.Random(seed)

    def coeff() -> int:
        return rng.randrange(1, P)

    l1 = [(coeff(), xe, ye) for xe in x1 for ye in y1]
    l2 = [(coeff(), xe, ye) for xe in x1 for ye in y1]
    q = [(coeff(), xe, ye) for xe in x2 for ye in y2]
    return l1, l2, q


def endpoint_dimensions(r: int, c: int) -> dict[str, int]:
    x_dom = monoms_deg(r)
    y_dom = monoms_deg(c)
    x_l = monoms_deg(r + 1)
    y_l = monoms_deg(c - 1)
    x_q = monoms_deg(r + 2)
    y_q = monoms_deg(c - 2)
    block_l = len(x_l) * len(y_l)
    block_q = len(x_q) * len(y_q)
    return {
        "rows": 2 * block_l + block_q,
        "linear_rows": 2 * block_l,
        "q_rows": block_q,
        "cols": len(x_dom) * len(y_dom),
        "block_l": block_l,
        "block_q": block_q,
        "x_dom": len(x_dom),
        "y_dom": len(y_dom),
        "x_l": len(x_l),
        "y_l": len(y_l),
        "x_q": len(x_q),
        "y_q": len(y_q),
    }


def endpoint_rank(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int = 8,
    sparse_q_terms: int = 20,
) -> dict[str, int | str]:
    if c < 2:
        raise ValueError("c must be at least 2")

    l1, l2, q_terms = terms(seed, mode, sparse_l_terms, sparse_q_terms)
    x_dom = monoms_deg(r)
    y_dom = monoms_deg(c)
    x_l = monoms_deg(r + 1)
    y_l = monoms_deg(c - 1)
    x_q = monoms_deg(r + 2)
    y_q = monoms_deg(c - 2)

    x_l_idx = {m: i for i, m in enumerate(x_l)}
    y_l_idx = {m: i for i, m in enumerate(y_l)}
    x_q_idx = {m: i for i, m in enumerate(x_q)}
    y_q_idx = {m: i for i, m in enumerate(y_q)}

    block_l = len(x_l) * len(y_l)
    block_q = len(x_q) * len(y_q)
    rows = 2 * block_l + block_q
    cols = len(x_dom) * len(y_dom)

    pivots: dict[int, dict[int, int]] = {}

    def row_l(block: int, xe: tuple[int, ...], ye: tuple[int, ...]) -> int:
        return block * block_l + x_l_idx[xe] * len(y_l) + y_l_idx[ye]

    def row_q(xe: tuple[int, ...], ye: tuple[int, ...]) -> int:
        return 2 * block_l + x_q_idx[xe] * len(y_q) + y_q_idx[ye]

    def add_to_vec(vec: dict[int, int], row: int, value: int) -> None:
        value %= P
        if not value:
            return
        new = (vec.get(row, 0) + value) % P
        if new:
            vec[row] = new
        elif row in vec:
            del vec[row]

    def reduce_column(vec: dict[int, int]) -> bool:
        while vec:
            p = min(vec)
            val = vec[p] % P
            if p not in pivots:
                scale = inv(val)
                norm = {k: (v * scale) % P for k, v in vec.items() if v % P}
                pivots[p] = norm
                return True
            factor = val
            prow = pivots[p]
            for k, v in prow.items():
                add_to_vec(vec, k, -factor * v)
        return False

    for xa in x_dom:
        for yb in y_dom:
            col: dict[int, int] = {}
            for block, lin_terms in enumerate((l1, l2)):
                for coeff, xop, yop in lin_terms:
                    ynew = sub_exp(yb, yop)
                    if ynew is None:
                        continue
                    ycoeff = falling_for_multi(yb, yop)
                    if not ycoeff:
                        continue
                    xnew = add_exp(xa, xop)
                    add_to_vec(col, row_l(block, xnew, ynew), coeff * ycoeff)
            for coeff, xop, yop in q_terms:
                ynew = sub_exp(yb, yop)
                if ynew is None:
                    continue
                ycoeff = falling_for_multi(yb, yop)
                if not ycoeff:
                    continue
                xnew = add_exp(xa, xop)
                add_to_vec(col, row_q(xnew, ynew), coeff * ycoeff)
            reduce_column(col)

    rank = len(pivots)
    return {
        "c": c,
        "r": r,
        "seed": seed,
        "mode": mode,
        "sparse_l_terms": sparse_l_terms,
        "sparse_q_terms": sparse_q_terms,
        "prime": P,
        "rows": rows,
        "cols": cols,
        "rank": rank,
        "kernel_dim": cols - rank,
    }


def row_entries_for_endpoint(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
):
    """Yield endpoint matrix rows as compact (col, value) lists.

    The endpoint map is
        A_r Sym^c -> (A_{r+1} Sym^{c-1})^2 + A_{r+2} Sym^{c-2}.
    Instead of building columns in memory, this iterates target basis rows and
    enumerates their possible source preimages term-by-term.
    """
    l1, l2, q_terms = terms(seed, mode, sparse_l_terms, sparse_q_terms)
    x_dom = monoms_deg(r)
    y_dom = monoms_deg(c)
    x_l = monoms_deg(r + 1)
    y_l = monoms_deg(c - 1)
    x_q = monoms_deg(r + 2)
    y_q = monoms_deg(c - 2)
    x_dom_idx = {m: i for i, m in enumerate(x_dom)}
    y_dom_idx = {m: i for i, m in enumerate(y_dom)}
    y_dom_len = len(y_dom)

    def add_to_row(row: dict[int, int], xa, yb, coeff: int, yop) -> None:
        x_i = x_dom_idx.get(xa)
        y_i = y_dom_idx.get(yb)
        if x_i is None or y_i is None:
            return
        ycoeff = falling_for_multi(yb, yop)
        if not ycoeff:
            return
        col = x_i * y_dom_len + y_i
        value = (coeff * ycoeff) % P
        if not value:
            return
        new = (row.get(col, 0) + value) % P
        if new:
            row[col] = new
        elif col in row:
            del row[col]

    for lin_terms in (l1, l2):
        for x_tgt in x_l:
            for y_tgt in y_l:
                row: dict[int, int] = {}
                for coeff, xop, yop in lin_terms:
                    xa = sub_exp(x_tgt, xop)
                    if xa is None:
                        continue
                    yb = add_exp(y_tgt, yop)
                    add_to_row(row, xa, yb, coeff, yop)
                yield sorted(row.items())

    for x_tgt in x_q:
        for y_tgt in y_q:
            row = {}
            for coeff, xop, yop in q_terms:
                xa = sub_exp(x_tgt, xop)
                if xa is None:
                    continue
                yb = add_exp(y_tgt, yop)
                add_to_row(row, xa, yb, coeff, yop)
            yield sorted(row.items())


def row_entries_for_linear_part(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
):
    l1, l2, _q_terms = terms(seed, mode, sparse_l_terms, sparse_q_terms)
    x_dom = monoms_deg(r)
    y_dom = monoms_deg(c)
    x_l = monoms_deg(r + 1)
    y_l = monoms_deg(c - 1)
    x_dom_idx = {m: i for i, m in enumerate(x_dom)}
    y_dom_idx = {m: i for i, m in enumerate(y_dom)}
    y_dom_len = len(y_dom)

    def add_to_row(row: dict[int, int], xa, yb, coeff: int, yop) -> None:
        x_i = x_dom_idx.get(xa)
        y_i = y_dom_idx.get(yb)
        if x_i is None or y_i is None:
            return
        ycoeff = falling_for_multi(yb, yop)
        if not ycoeff:
            return
        col = x_i * y_dom_len + y_i
        value = (coeff * ycoeff) % P
        if not value:
            return
        new = (row.get(col, 0) + value) % P
        if new:
            row[col] = new
        elif col in row:
            del row[col]

    for lin_terms in (l1, l2):
        for x_tgt in x_l:
            for y_tgt in y_l:
                row: dict[int, int] = {}
                for coeff, xop, yop in lin_terms:
                    xa = sub_exp(x_tgt, xop)
                    if xa is None:
                        continue
                    yb = add_exp(y_tgt, yop)
                    add_to_row(row, xa, yb, coeff, yop)
                yield sorted(row.items())


def row_entries_for_q_part(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
):
    _l1, _l2, q_terms = terms(seed, mode, sparse_l_terms, sparse_q_terms)
    x_dom = monoms_deg(r)
    y_dom = monoms_deg(c)
    x_q = monoms_deg(r + 2)
    y_q = monoms_deg(c - 2)
    x_dom_idx = {m: i for i, m in enumerate(x_dom)}
    y_dom_idx = {m: i for i, m in enumerate(y_dom)}
    y_dom_len = len(y_dom)

    def add_to_row(row: dict[int, int], xa, yb, coeff: int, yop) -> None:
        x_i = x_dom_idx.get(xa)
        y_i = y_dom_idx.get(yb)
        if x_i is None or y_i is None:
            return
        ycoeff = falling_for_multi(yb, yop)
        if not ycoeff:
            return
        col = x_i * y_dom_len + y_i
        value = (coeff * ycoeff) % P
        if not value:
            return
        new = (row.get(col, 0) + value) % P
        if new:
            row[col] = new
        elif col in row:
            del row[col]

    for x_tgt in x_q:
        for y_tgt in y_q:
            row: dict[int, int] = {}
            for coeff, xop, yop in q_terms:
                xa = sub_exp(x_tgt, xop)
                if xa is None:
                    continue
                yb = add_exp(y_tgt, yop)
                add_to_row(row, xa, yb, coeff, yop)
            yield sorted(row.items())


def write_endpoint_binary(
    path: pathlib.Path,
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
    matrix_part: str = "endpoint",
) -> dict[str, int]:
    dims = endpoint_dimensions(r, c)
    if matrix_part == "endpoint":
        row_iter = row_entries_for_endpoint(
            r, c, seed, mode, sparse_l_terms, sparse_q_terms
        )
        rows = dims["rows"]
    elif matrix_part == "linear":
        row_iter = row_entries_for_linear_part(
            r, c, seed, mode, sparse_l_terms, sparse_q_terms
        )
        rows = dims["linear_rows"]
    elif matrix_part == "q":
        row_iter = row_entries_for_q_part(
            r, c, seed, mode, sparse_l_terms, sparse_q_terms
        )
        rows = dims["q_rows"]
    else:
        raise ValueError("matrix_part must be endpoint, linear, or q")
    path.parent.mkdir(parents=True, exist_ok=True)
    nnz = 0
    written = 0
    with path.open("wb") as handle:
        handle.write(struct.pack("<ii", rows, dims["cols"]))
        for row in row_iter:
            handle.write(struct.pack("<i", len(row)))
            nnz += len(row)
            for col, value in row:
                handle.write(struct.pack("<ii", col, value % P))
            written += 1
    if written != rows:
        raise RuntimeError(f"wrote {written} rows, expected {rows}")
    return {"rows": rows, "cols": dims["cols"], "nnz": nnz, "matrix_part": matrix_part}


def endpoint_rank_external(
    r: int,
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
    timeout: int,
    keep_matrix: bool,
    matrix_part: str,
    pivot: str,
) -> dict[str, object]:
    def tail(value: str | bytes | None) -> str:
        if value is None:
            return ""
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")[-1000:]
        return value[-1000:]

    started = time.time()
    stem = f"{matrix_part}_c{c}_r{r}_{mode}_seed{seed}_L{sparse_l_terms}_Q{sparse_q_terms}"
    matrix_path = OUT_DIR / f"{stem}_{os.getpid()}_{time.time_ns()}.bin"
    matrix_meta = write_endpoint_binary(
        matrix_path, r, c, seed, mode, sparse_l_terms, sparse_q_terms, matrix_part
    )
    write_seconds = time.time() - started
    rank_started = time.time()
    rec: dict[str, object] = {
        "c": c,
        "r": r,
        "seed": seed,
        "mode": mode,
        "sparse_l_terms": sparse_l_terms,
        "sparse_q_terms": sparse_q_terms,
        "prime": P,
        "method": "rank_sparse_mod",
        "pivot": pivot,
        "matrix": matrix_meta,
        "matrix_file": str(matrix_path),
        "write_seconds": round(write_seconds, 3),
    }
    try:
        env = os.environ.copy()
        if pivot != "default":
            env["RANK_SPARSE_PIVOT"] = pivot
        proc = subprocess.run(
            [str(RANK_BIN), str(matrix_path), str(P)],
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
            env=env,
        )
        rank_seconds = time.time() - rank_started
        rec.update(
            {
                "rank_seconds": round(rank_seconds, 3),
                "returncode": proc.returncode,
            }
        )
        if proc.returncode == 0:
            try:
                rank = int(proc.stdout.strip().splitlines()[-1])
                rec.update(
                    {
                        "status": "ok",
                        "rank": rank,
                        "kernel_dim": matrix_meta["cols"] - rank,
                    }
                )
            except (IndexError, ValueError):
                rec.update(
                    {
                        "status": "rank_parse_failed",
                        "stdout_tail": tail(proc.stdout),
                        "stderr_tail": tail(proc.stderr),
                    }
                )
        else:
            rec.update(
                {
                    "status": "rank_failed",
                    "stdout_tail": tail(proc.stdout),
                    "stderr_tail": tail(proc.stderr),
                }
            )
    except subprocess.TimeoutExpired as exc:
        rank_seconds = time.time() - rank_started
        rec.update(
            {
                "status": "rank_timeout",
                "timeout": timeout,
                "rank_seconds": round(rank_seconds, 3),
                "stdout_tail": tail(exc.stdout),
                "stderr_tail": tail(exc.stderr),
            }
        )
    if not keep_matrix:
        try:
            matrix_path.unlink()
            rec["matrix_file_removed"] = True
        except FileNotFoundError:
            pass
    return rec


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-r", type=int, default=12)
    parser.add_argument("--min-r", type=int, default=0)
    parser.add_argument("--c", type=int, default=None)
    parser.add_argument("--seed", type=int, default=7863)
    parser.add_argument(
        "--mode", choices=("diagonal", "sparseL_denseQ", "random_sparse", "dense"), default="diagonal"
    )
    parser.add_argument("--sparse-l-terms", type=int, default=8)
    parser.add_argument("--sparse-q-terms", type=int, default=20)
    parser.add_argument("--external-rank", action="store_true")
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--keep-matrix", action="store_true")
    parser.add_argument("--matrix-part", choices=("endpoint", "linear", "q"), default="endpoint")
    parser.add_argument("--pivot", choices=("default", "min", "max"), default="default")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    records = []
    c_values = (args.c,) if args.c is not None else (2, 3)
    for c in c_values:
        for r in range(args.min_r, args.max_r + 1):
            if args.external_rank:
                records.append(
                    endpoint_rank_external(
                        r,
                        c,
                        args.seed,
                        args.mode,
                        args.sparse_l_terms,
                        args.sparse_q_terms,
                        args.timeout,
                        args.keep_matrix,
                        args.matrix_part,
                        args.pivot,
                    )
                )
            else:
                records.append(
                    endpoint_rank(
                        r,
                        c,
                        args.seed,
                        args.mode,
                        args.sparse_l_terms,
                        args.sparse_q_terms,
                    )
                )

    if args.json:
        print(json.dumps({"records": records}, indent=2))
        return

    print("| c | r | rows | cols | rank | N_c(r) |")
    print("| ---: | ---: | ---: | ---: | ---: | ---: |")
    for rec in records:
        matrix = rec.get("matrix", {})
        rows = rec.get("rows", matrix.get("rows", "?") if isinstance(matrix, dict) else "?")
        cols = rec.get("cols", matrix.get("cols", "?") if isinstance(matrix, dict) else "?")
        rank = rec.get("rank", rec.get("status", "?"))
        kernel_dim = rec.get("kernel_dim", "")
        print(
            f"| {rec['c']} | {rec['r']} | {rows} | {cols} | "
            f"{rank} | {kernel_dim} |"
        )


if __name__ == "__main__":
    main()
