#!/usr/bin/env python3
"""Export/replay full reduced Koszul rank-minor witnesses for CICY 7863.

The existing full-Koszul replay stores matrix hashes, exact ranks, and
pivot-row hashes.  This script adds a compact minor layer: for every
differential rank used in the Cell 9 finite-box homology calculation, it
stores pivot rows and pivot columns for a nonzero rank-size minor over
F_1000003.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import pathlib
import sys
import time
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parent
FULL_PATH = ROOT / "7863_full_koszul_certificate_replay.py"
SPEC = importlib.util.spec_from_file_location("full7863", FULL_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load 7863_full_koszul_certificate_replay.py")
full = importlib.util.module_from_spec(SPEC)
sys.modules["full7863_rank_minor"] = full
SPEC.loader.exec_module(full)

probe = full.probe
qreplay = full.qreplay
P = full.P
Vector = dict[int, int]


MATRIX_SPECS: list[tuple[str, int, int]] = [
    ("d_WM0_to_M1", 1, 0),
    ("d_L2M0_to_WM1", 2, 0),
    ("d_WM1_to_M2", 1, 1),
    ("d_L3M0_to_L2M1", 3, 0),
    ("d_L2M1_to_WM2", 2, 1),
    ("d_WM2_to_M3", 1, 2),
    ("d_L4M0_to_L3M1", 4, 0),
    ("d_L3M1_to_L2M2", 3, 1),
    ("d_L2M2_to_WM3", 2, 2),
    ("d_WM3_to_M4", 1, 3),
]


def vector_add_scaled(dst: Vector, src: Vector, scalar: int) -> None:
    scalar %= P
    if not scalar:
        return
    for i, v in src.items():
        new = (dst.get(i, 0) + scalar * v) % P
        if new:
            dst[i] = new
        elif i in dst:
            del dst[i]


def vector_scale(vec: Vector, scalar: int) -> Vector:
    scalar %= P
    if not scalar:
        return {}
    return {i: (scalar * v) % P for i, v in vec.items() if v % P}


def build_full_matrices(
    c: int,
    seed: int,
    mode: str,
    sparse_l_terms: int,
    sparse_q_terms: int,
) -> dict[str, Any]:
    modules, _q_meta = probe.build_positive_modules(
        c, seed, mode, sparse_l_terms, sparse_q_terms
    )
    module_dims = {0: probe.pbinom(c) + probe.pbinom(c - 4)}
    module_dims.update({d: modules[d].dim for d in range(1, 5)})

    mu: dict[int, dict[int, list[Vector]]] = {0: {}}
    for x_var in range(4):
        mu[0][x_var] = probe.mu0_columns(
            c, x_var, seed, mode, sparse_l_terms, sparse_q_terms
        )
    for d in (1, 2, 3):
        mu[d] = {}
        for x_var in range(4):
            mu[d][x_var] = probe.positive_mu_columns(modules, d, x_var)

    matrices: dict[str, dict[str, Any]] = {}
    for name, wedge_rank, module_degree in MATRIX_SPECS:
        cols = probe.koszul_diff_columns(wedge_rank, module_degree, module_dims, mu)
        rows = full.target_rows(module_dims, wedge_rank, module_degree)
        matrices[name] = {
            "cols": cols,
            "rows": rows,
            "wedge_rank": wedge_rank,
            "module_degree": module_degree,
            "matrix_hash": qreplay.matrix_hash(cols),
        }
    return {
        "module_dims": module_dims,
        "matrices": matrices,
    }


def pivot_witness_from_columns(cols: list[Vector]) -> dict[str, Any]:
    pivots: dict[int, Vector] = {}
    pivot_rows: list[int] = []
    pivot_columns: list[int] = []
    for col_idx, raw in enumerate(cols):
        vec = {i: v % P for i, v in raw.items() if v % P}
        while vec:
            pc = min(vec)
            pv = vec[pc] % P
            prow = pivots.get(pc)
            if prow is None:
                inv = pow(pv, P - 2, P)
                pivots[pc] = vector_scale(vec, inv)
                pivot_rows.append(int(pc))
                pivot_columns.append(int(col_idx))
                break
            vector_add_scaled(vec, prow, -pv)
    return {
        "rank": len(pivot_rows),
        "pivot_rows": pivot_rows,
        "pivot_columns": pivot_columns,
    }


def restrict_columns(
    cols: list[Vector],
    pivot_rows: list[int],
    pivot_columns: list[int],
) -> list[Vector]:
    row_index = {row: i for i, row in enumerate(pivot_rows)}
    restricted: list[Vector] = []
    for col_idx in pivot_columns:
        col = cols[col_idx]
        restricted.append(
            {
                row_index[row]: value % P
                for row, value in col.items()
                if row in row_index and value % P
            }
        )
    return restricted


def elimination_rank_and_pivot_product(cols: list[Vector]) -> dict[str, int]:
    pivots: dict[int, Vector] = {}
    rank = 0
    pivot_product = 1
    for raw in cols:
        vec = {i: v % P for i, v in raw.items() if v % P}
        while vec:
            pc = min(vec)
            pv = vec[pc] % P
            prow = pivots.get(pc)
            if prow is None:
                pivot_product = (pivot_product * pv) % P
                pivots[pc] = vector_scale(vec, pow(pv, P - 2, P))
                rank += 1
                break
            vector_add_scaled(vec, prow, -pv)
    return {
        "rank": rank,
        "pivot_product_mod_p": pivot_product % P if rank else 0,
    }


def make_rank_minor_entry(name: str, matrix: dict[str, Any]) -> dict[str, Any]:
    cols: list[Vector] = matrix["cols"]
    witness = pivot_witness_from_columns(cols)
    restricted = restrict_columns(cols, witness["pivot_rows"], witness["pivot_columns"])
    restricted_check = elimination_rank_and_pivot_product(restricted)
    rank = int(witness["rank"])
    if restricted_check["rank"] != rank:
        raise RuntimeError(f"restricted minor rank mismatch for {name}")
    if rank and restricted_check["pivot_product_mod_p"] == 0:
        raise RuntimeError(f"zero pivot product for {name}")
    return {
        "name": name,
        "rows": int(matrix["rows"]),
        "cols": len(cols),
        "rank": rank,
        "matrix_sparse_columns_sha256": matrix["matrix_hash"],
        "source": {
            "wedge_rank": int(matrix["wedge_rank"]),
            "module_degree": int(matrix["module_degree"]),
        },
        "witness": {
            "kind": "rank_minor_mod_p",
            "minor_size": rank,
            "pivot_rows": witness["pivot_rows"],
            "pivot_columns": witness["pivot_columns"],
            "pivot_product_mod_p": restricted_check["pivot_product_mod_p"],
            "restricted_minor_rank_mod_p": restricted_check["rank"],
            "row_order": "pivot discovery order",
            "column_order": "pivot discovery order",
        },
    }


def homology_from_ranks(module_dims: dict[int, int], ranks: dict[str, int], col_counts: dict[str, int]) -> dict[str, Any]:
    h_deg1 = {
        "H1": col_counts["d_WM0_to_M1"] - ranks["d_WM0_to_M1"],
        "H0": module_dims[1] - ranks["d_WM0_to_M1"],
    }
    h_deg2 = {
        "H2": col_counts["d_L2M0_to_WM1"] - ranks["d_L2M0_to_WM1"],
        "H1": col_counts["d_WM1_to_M2"]
        - ranks["d_WM1_to_M2"]
        - ranks["d_L2M0_to_WM1"],
        "H0": module_dims[2] - ranks["d_WM1_to_M2"],
    }
    h_deg3 = {
        "H3": col_counts["d_L3M0_to_L2M1"] - ranks["d_L3M0_to_L2M1"],
        "H2": col_counts["d_L2M1_to_WM2"]
        - ranks["d_L2M1_to_WM2"]
        - ranks["d_L3M0_to_L2M1"],
        "H1": col_counts["d_WM2_to_M3"]
        - ranks["d_WM2_to_M3"]
        - ranks["d_L2M1_to_WM2"],
        "H0": module_dims[3] - ranks["d_WM2_to_M3"],
    }
    h_deg4 = {
        "H4": col_counts["d_L4M0_to_L3M1"] - ranks["d_L4M0_to_L3M1"],
        "H3": col_counts["d_L3M1_to_L2M2"]
        - ranks["d_L3M1_to_L2M2"]
        - ranks["d_L4M0_to_L3M1"],
        "H2": col_counts["d_L2M2_to_WM3"]
        - ranks["d_L2M2_to_WM3"]
        - ranks["d_L3M1_to_L2M2"],
        "H1": col_counts["d_WM3_to_M4"]
        - ranks["d_WM3_to_M4"]
        - ranks["d_L2M2_to_WM3"],
        "H0": module_dims[4] - ranks["d_WM3_to_M4"],
    }
    return {
        "degree_1": h_deg1,
        "degree_2": h_deg2,
        "degree_3": h_deg3,
        "degree_4": h_deg4,
    }


def make_certificate(args: argparse.Namespace) -> dict[str, Any]:
    started = time.time()
    built = build_full_matrices(
        args.c,
        args.seed,
        args.mode,
        args.sparse_l_terms,
        args.sparse_q_terms,
    )
    entries = [
        make_rank_minor_entry(name, built["matrices"][name])
        for name, _r, _d in MATRIX_SPECS
    ]
    ranks = {entry["name"]: int(entry["rank"]) for entry in entries}
    col_counts = {entry["name"]: int(entry["cols"]) for entry in entries}
    homology = homology_from_ranks(built["module_dims"], ranks, col_counts)
    return {
        "certificate_type": "cicy_7863_cell9_full_koszul_rank_minors_v1",
        "statement": (
            "Rank-minor witnesses for all ten full reduced Koszul "
            "differentials used in the Cell 9 finite-box homology replay."
        ),
        "cicy": 7863,
        "cell": 9,
        "c": args.c,
        "paper_b": args.c,
        "prime": P,
        "seed": args.seed,
        "mode": args.mode,
        "sparse_l_terms": args.sparse_l_terms,
        "sparse_q_terms": args.sparse_q_terms,
        "module_dims_M0_to_M4": {
            str(d): int(built["module_dims"][d]) for d in range(5)
        },
        "rank_minor_entries": entries,
        "ranks": ranks,
        "koszul_homology_by_degree": homology,
        "source_files": {
            "generator_checker": pathlib.Path(__file__).name,
            "generator_checker_sha256": qreplay.sha256_file(pathlib.Path(__file__)),
            "full_koszul_helper": FULL_PATH.name,
            "full_koszul_helper_sha256": qreplay.sha256_file(FULL_PATH),
            "matrix_recipe": qreplay.PROBE_PATH.name,
            "matrix_recipe_sha256": qreplay.sha256_file(qreplay.PROBE_PATH),
        },
        "created_unix_time": time.time(),
        "seconds": round(time.time() - started, 6),
    }


def replay_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    required_type = "cicy_7863_cell9_full_koszul_rank_minors_v1"
    if cert.get("certificate_type") != required_type:
        raise ValueError("unexpected certificate_type")
    if cert.get("prime") != P:
        raise ValueError("certificate prime does not match checker prime")
    built = build_full_matrices(
        int(cert["c"]),
        int(cert["seed"]),
        str(cert["mode"]),
        int(cert["sparse_l_terms"]),
        int(cert["sparse_q_terms"]),
    )
    expected_entries = {entry["name"]: entry for entry in cert["rank_minor_entries"]}
    rank_checks: dict[str, Any] = {}
    observed_ranks: dict[str, int] = {}
    col_counts: dict[str, int] = {}
    for name, _r, _d in MATRIX_SPECS:
        matrix = built["matrices"][name]
        cols: list[Vector] = matrix["cols"]
        expected = expected_entries[name]
        pivot_rows = [int(row) for row in expected["witness"]["pivot_rows"]]
        pivot_columns = [int(col) for col in expected["witness"]["pivot_columns"]]
        restricted = restrict_columns(cols, pivot_rows, pivot_columns)
        restricted_check = elimination_rank_and_pivot_product(restricted)
        observed_rank = restricted_check["rank"]
        observed_ranks[name] = observed_rank
        col_counts[name] = len(cols)
        rank_checks[name] = {
            "matrix_rows_match": int(matrix["rows"]) == int(expected["rows"]),
            "matrix_cols_match": len(cols) == int(expected["cols"]),
            "matrix_hash_match": matrix["matrix_hash"]
            == expected["matrix_sparse_columns_sha256"],
            "pivot_row_count_match": len(pivot_rows) == int(expected["rank"]),
            "pivot_column_count_match": len(pivot_columns) == int(expected["rank"]),
            "pivot_rows_in_bounds": all(0 <= row < int(matrix["rows"]) for row in pivot_rows),
            "pivot_columns_in_bounds": all(0 <= col < len(cols) for col in pivot_columns),
            "restricted_minor_rank_match": observed_rank == int(expected["rank"]),
            "pivot_product_matches_certificate": restricted_check["pivot_product_mod_p"]
            == int(expected["witness"]["pivot_product_mod_p"]),
            "pivot_product_nonzero": restricted_check["pivot_product_mod_p"] % P != 0,
        }
    module_dims = {int(k): int(v) for k, v in cert["module_dims_M0_to_M4"].items()}
    observed_homology = homology_from_ranks(module_dims, observed_ranks, col_counts)
    checks = {
        "all_rank_minor_checks": all(all(v.values()) for v in rank_checks.values()),
        "ranks_match": observed_ranks == {k: int(v) for k, v in cert["ranks"].items()},
        "homology_match": observed_homology == cert["koszul_homology_by_degree"],
    }
    passed = all(checks.values())
    return {
        "status": "passed" if passed else "failed",
        "certificate_type": cert["certificate_type"],
        "cicy": cert["cicy"],
        "cell": cert["cell"],
        "c": cert["c"],
        "paper_b": cert.get("paper_b", cert["c"]),
        "prime": P,
        "checks": checks,
        "rank_checks": rank_checks,
        "ranks": observed_ranks,
        "koszul_homology_by_degree": observed_homology,
    }


def write_json(path: pathlib.Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


def generate_all(args: argparse.Namespace) -> None:
    args.out_dir.mkdir(parents=True, exist_ok=True)
    summary = []
    for c in range(args.c_min, args.c_max + 1):
        local = argparse.Namespace(**vars(args))
        local.c = c
        cert = make_certificate(local)
        replay = replay_certificate(cert)
        cert_path = args.out_dir / f"full_koszul_rank_minors_c{c}.json"
        replay_path = args.out_dir / f"full_koszul_rank_minors_c{c}.replay.json"
        write_json(cert_path, cert)
        write_json(replay_path, replay)
        if replay["status"] != "passed":
            raise RuntimeError(f"replay failed for c={c}")
        summary.append(
            {
                "c": c,
                "paper_b": c,
                "rank_entries": [
                    {
                        "name": entry["name"],
                        "rows": entry["rows"],
                        "cols": entry["cols"],
                        "rank": entry["rank"],
                        "pivot_product_mod_p": entry["witness"]["pivot_product_mod_p"],
                    }
                    for entry in cert["rank_minor_entries"]
                ],
                "replay_status": replay["status"],
            }
        )
    write_json(args.out_dir / "summary.json", {"prime": P, "items": summary})


def generate_one(args: argparse.Namespace) -> None:
    cert = make_certificate(args)
    write_json(args.out, cert)
    if args.replay_out:
        replay = replay_certificate(cert)
        write_json(args.replay_out, replay)
        if replay["status"] != "passed":
            raise RuntimeError(f"replay failed for c={args.c}")


def replay_one(args: argparse.Namespace) -> None:
    cert = json.loads(args.certificate.read_text())
    replay = replay_certificate(cert)
    if args.out:
        write_json(args.out, replay)
    else:
        print(json.dumps(replay, indent=2, sort_keys=True))
    if replay["status"] != "passed":
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--seed", type=int, default=7863)
    common.add_argument(
        "--mode",
        choices=["diagonal", "sparseL_denseQ", "random_sparse", "dense"],
        default="sparseL_denseQ",
    )
    common.add_argument("--sparse-l-terms", type=int, default=8)
    common.add_argument("--sparse-q-terms", type=int, default=20)

    gen = sub.add_parser("generate", parents=[common])
    gen.add_argument("--c", type=int, required=True)
    gen.add_argument("--out", type=pathlib.Path, required=True)
    gen.add_argument("--replay-out", type=pathlib.Path)
    gen.set_defaults(func=generate_one)

    gen_all = sub.add_parser("generate-all", parents=[common])
    gen_all.add_argument("--c-min", type=int, default=4)
    gen_all.add_argument("--c-max", type=int, default=10)
    gen_all.add_argument(
        "--out-dir",
        type=pathlib.Path,
        default=ROOT / "certificates" / "7863_cell9_full_koszul_rank_minors",
    )
    gen_all.set_defaults(func=generate_all)

    rep = sub.add_parser("replay")
    rep.add_argument("certificate", type=pathlib.Path)
    rep.add_argument("--out", type=pathlib.Path)
    rep.set_defaults(func=replay_one)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
