# CICY 7863 Chrome Heavy / verifier progress

Date: 2026-06-05.

This note records the current verifier status for the remaining CICY 7863
mixed-cell formula problem.  The Chrome Heavy dialogue transcripts are in
`tmp/7863_chrome_heavy_dialogue/`; the local endpoint certificate scripts and
Singular outputs are in `tmp/7863_endpoint_singular_certs/`.

## 1. Chrome Heavy status

Two Chrome ChatGPT Heavy threads were opened for the hard part of the task:

- a single-parameter solution-generator thread;
- a two-parameter solution-generator thread.

Several single-parameter Chrome attempts stalled after an opening sentence.
The responsive Heavy thread was still useful as a reviewer: it accepted the
rank obstruction for endpoint modules and proposed a first \(N_3\) correction,
but the local Singular certificate below refined that correction.

The useful saved Heavy outputs are:

- `tmp/7863_chrome_heavy_dialogue/single_parameter_data_review_on_responsive_heavy_response.md`
- `tmp/7863_chrome_heavy_dialogue/single_parameter_n3_rank_challenge_response.md`
- `tmp/7863_chrome_heavy_dialogue/two_parameter_recovery2_forced_response.md`

## 2. Single-parameter endpoint formulas

Use
\[
P(d)=
\begin{cases}
\binom{d+3}{3},&d\ge0,\\
0,&d<0.
\end{cases}
\]
For \(c=2,3\), let
\[
N_c(r)=\dim\ker\alpha^{(c)}_r
\]
for the endpoint \(A=\mathbf C[x_0,\ldots,x_3]\)-linear contraction map
described in `tmp/7863_subagent_derivations/one_parameter_closed_formulas.md`.

The local verifier now gives the following closed Hilbert series:
\[
\operatorname{HS}_{N_2}(t)=\frac{10t^8-8t^9}{(1-t)^4},
\]
\[
\operatorname{HS}_{N_3}(t)=\frac{20t^{14}-20t^{15}+2t^{17}}{(1-t)^4}.
\]

Equivalently, with \(\binom n3=0\) for \(n<3\),
\[
N_2(r)=10\binom{r-5}{3}-8\binom{r-6}{3},
\]
\[
N_3(r)=20\binom{r-11}{3}-20\binom{r-12}{3}
       +2\binom{r-14}{3}.
\]
Thus \(N_2(r)=0\) for \(r\le7\), and
\[
N_2(8),N_2(9),N_2(10),N_2(11),N_2(12)=10,32,68,120,190.
\]
Also \(N_3(r)=0\) for \(r\le13\), and
\[
N_3(14),N_3(15),N_3(16),N_3(17),N_3(18)=20,60,120,202,308.
\]

The earlier Heavy rank-only correction
\((20t^{14}-20t^{15}+2t^{16})/(1-t)^4\) is therefore not the verifier result;
the second positive term occurs in degree \(17\), not \(16\).

## 3. Singular certificate evidence

The new script
`7863_endpoint_singular_cert.py`
builds the global endpoint matrices over
\(\mathbf F_{1000003}[x_0,x_1,x_2,x_3]\), computes the kernel module with
Singular, and reads the quotient Hilbert numerator.

For both `sparseL_denseQ` and fully `dense` specializations, Singular gives:

- \(c=2\): quotient numerator \(10-10t^8+8t^9\), hence kernel numerator
  \(10t^8-8t^9\);
- \(c=3\): quotient numerator \(20-20t^{14}+20t^{15}-2t^{17}\), hence kernel
  numerator \(20t^{14}-20t^{15}+2t^{17}\).

This is a finite-field nonempty-open certificate candidate.  To make it fully
publication-grade over \(\mathbf Q\), we still need to record either a QQ
standard-basis run or a nonzero-minor / stable-initial-module argument showing
that the same Hilbert functions hold on a nonempty Zariski open set inside the
smooth CICY parameter space.

## 4. Single-parameter cell formulas

Define
\[
\Delta_2(r)=8P(r+1)-10P(r),
\]
\[
\Delta_3(r)=20P(r+1)-20P(r)-2P(r+3).
\]

Then the eight one-parameter cells are closed by substituting the \(N_2,N_3\)
above:

\[
\text{Cells }7,55:\quad
(h^0,h^1,h^2,h^3)=(0,0,N_2(r)+\Delta_2(r),N_2(r)).
\]
\[
\text{Cells }27,75:\quad
(h^0,h^1,h^2,h^3)=(N_2(r),N_2(r)+\Delta_2(r),0,0).
\]
\[
\text{Cells }8,64:\quad
(h^0,h^1,h^2,h^3)=(0,0,N_3(r)+\Delta_3(r),N_3(r)).
\]
\[
\text{Cells }18,74:\quad
(h^0,h^1,h^2,h^3)=(N_3(r),N_3(r)+\Delta_3(r),0,0).
\]

Here the parameter \(r\) is:

- Cell 7: \(r=-a-4\);
- Cell 55: \(r=-b-4\);
- Cell 27: \(r=b-4\);
- Cell 75: \(r=a-4\);
- Cell 8: \(r=-a-4\);
- Cell 64: \(r=-b-4\);
- Cell 18: \(r=b-4\);
- Cell 74: \(r=a-4\).

As useful checks, \(N_2(r)+\Delta_2(r)=120\) for \(r\ge6\), and
\(N_3(r)+\Delta_3(r)=460\) for \(r\ge14\).

## 5. Fixed/small-rank cells

From the earlier three-subagent run:

\[
\text{Cell }17=(-3,3):\quad (0,0,0,0),
\]
\[
\text{Cell }65=(3,-3):\quad (0,0,0,0),
\]
\[
\text{Cell }66=(3,-2):\quad (0,8,0,0).
\]

Together with the previously closed cells,
\[
\text{Cell }16=(0,0,8,0),\quad
\text{Cell }26=(0,8,0,0),\quad
\text{Cell }56=(0,0,8,0),\quad
\text{Cell }57=(0,1,1,0).
\]

## 6. Two-parameter finite-box theorem form

For Cell 9 write
\[
a=-m-4,\qquad m\ge0,\qquad b\ge4.
\]
The active mixed complex is
\[
C_3\to C_2\to C_1\to C_0
\]
with
\[
C_3=A_{m+4}\otimes S_{b-4},
\]
\[
C_2=(A_{m+3}\otimes S_{b-3})^{\oplus2}
      \oplus A_{m+2}\otimes S_{b-2},
\]
\[
C_1=A_{m+2}\otimes S_{b-2}
      \oplus (A_{m+1}\otimes S_{b-1})^{\oplus2},
\]
\[
C_0=A_m\otimes S_b.
\]
Let \(H_j(m,b)\) be the homology at \(C_j\).  Then
\[
h^\bullet_X(-m-4,b)=(H_3,H_2,H_1,H_0),
\]
and by Serre duality
\[
h^\bullet_X(m+4,-b)=(H_0,H_1,H_2,H_3).
\]

The Euler term is
\[
E(m,b)=P(m+4)P(b-4)-2P(m+3)P(b-3)
       +2P(m+1)P(b-1)-P(m)P(b),
\]
equivalently
\[
E(m,b)=
\frac{(b-m-4)(b^2-(8m+32)b+m^2+8m+27)}{3}.
\]

A finite-box theorem for \(0\le m\le M,\ 4\le b\le B\) should certify:

1. \(H_3(m,b)=0\) in the box;
2. \(H_0(m,b)=e_0(m,b)\), where \(e_0\) is the Hilbert function of the
   endpoint cokernel \(C_1\to C_0\);
3. with \(D(m,b)=E(m,b)+e_0(m,b)\),
\[
H_1(m,b)=\max(D(m,b),0),
\]
\[
H_2(m,b)=\max(-D(m,b),0).
\]

This sign convention follows from
\[
H_3-H_2+H_1-H_0=E.
\]
It is the verifier-corrected orientation relative to the raw Heavy transcript.

Verifier update: the old central-parity correction
\(\gamma(m,b)=q+1\) on \((m,b)=(2q,2q+4)\) is contradicted by the direct
Cell 9 probe at \((0,4)\) and \((2,6)\).  See
`7863_two_parameter_probe_status.md`.  The current finite-field evidence
supports the no-gamma form
\[
H_1(m,b)=\max(D(m,b),0),\qquad
H_2(m,b)=\max(-D(m,b),0),
\]
with \(H_3=0\) and \(H_0=e_0\), for the tested points.  The global
two-parameter closed formula is still not proved.  What we have is a more
accurate finite-box certificate target: compute \(e_0(m,b)\) in the box by
minimal resolutions / Fitting rank certificates, prove \(d_3\) injective, and
certify the no-gamma middle ranks by nonzero-minor lower witnesses plus
symbolic upper bounds.

Additional endpoint update: \(e_0(m,b)\) is the arbitrary-degree endpoint
module \(N_b(m)\).  Besides \(N_2,N_3\), the Singular verifier now also gives
\[
\operatorname{HS}_{N_4}(t)=
\frac{36t^{20}-44t^{21}+6t^{22}+4t^{23}}{(1-t)^4}.
\]
\[
\operatorname{HS}_{N_5}(t)=
\frac{60t^{26}-86t^{27}+24t^{28}+4t^{29}}{(1-t)^4}.
\]
Consequently the \(b=4\) Cell 9 endpoint has
\[
e_0(m,4)=36\binom{m-17}{3}-44\binom{m-18}{3}
 +6\binom{m-19}{3}+4\binom{m-20}{3}.
\]
The \(b=5\) endpoint has
\[
e_0(m,5)=60\binom{m-23}{3}-86\binom{m-24}{3}
 +24\binom{m-25}{3}+4\binom{m-26}{3}.
\]
The next missing endpoint is \(N_6\).  The \(N_5\) computation required the
split-linear Singular route: compute the \(L_1,L_2\)-kernel first, then
restrict \(Q\).

2026-06-05 Chrome Heavy follow-up:

- Chrome control through the Codex Chrome Extension was re-established and two
  ChatGPT Heavy tabs were used as solution generators.
- The single-parameter tab confirmed the verified \(P\)-shift formulas for
  \(N_2,\ldots,N_5\), but did not prove a uniform \(c\)-formula.  It noted the
  useful interpolation identities
  \[
  \beta_0(c)=\binom{c+3}{3}+\binom{c-1}{3},\qquad
  \beta_2(c)=6\binom{c-1}{3},
  \]
  for the four-point cubic target.  Since the same interpolation has
  \(\beta_3(c)=\frac{(c-1)(c-2)(6-c)}3\), which is negative for \(c\ge7\),
  this remains evidence rather than a theorem.
- The two-parameter tab confirmed that no independent gamma wall is currently
  justified.  For fixed \(c\), the real certificate is: endpoint numerator
  \(N_c\), \(H_3=0\), and maximal rank of the reduced middle map.  Then the
  only walls are endpoint support and the sign of \(D=E+N_c\).
- Locally verified fixed-\(c\) sign checks: for verified \(N_4,N_5\), and for
  conjectural \(N_6\), \(D_4\) has only zero \(m=0\), \(D_5\) only zero
  \(m=1\), and \(D_6\) only zero \(m=2\) through \(m=300\).  The post-support
  tails are constant positive values \(1136,2260,3944\) respectively, with the
  last still conditional on the \(N_6\) numerator.
- A new \(N_6\) attempt with
  `random_sparse`, `seed=13579`, `sparse_l_terms=8`, `sparse_q_terms=12`,
  `--split-linear`, and `--skip-resolution` generated only
  `tmp/7863_endpoint_singular_certs/endpoint_c6_random_sparse_seed13579.sing`
  and exited abnormally without `.out`/`.err`.  No \(N_6\) certificate is
  recorded.
- The direct degreewise endpoint-rank fallback in
  `7863_endpoint_nc_probe.py` was repaired to report clean `rank_timeout`
  records.  It reproduces the \(N_2\) gate \(N_2(8)=10,N_2(9)=32\), but a
  full endpoint matrix for \(N_4(20)\) is already
  \(103960\times61985\) with about \(2.05\) million nonzero entries and does
  not finish promptly.  This confirms that the next serious \(N_6\) attempt
  should be split-linear degreewise rather than direct full endpoint rank.
- A follow-up prompt to the two-parameter Heavy tab produced a concrete
  split-linear schema for the \(L_1,L_2\)-kernel.  In the diagonal-pencil
  model, Heavy proposed
  \[
  0\to A_{m-2c-2}\otimes\operatorname{Sym}^{c-2}W
  \to (A_{m-2c-1}\otimes\operatorname{Sym}^{c-1}W)^2
  \to A_{m-2c}\otimes\operatorname{Sym}^{c}W
  \to K_L(m,c)\to0.
  \]
  Hence
  \[
  \dim K_L(m,c)=
  \binom{c+3}{3}P(m-2c)
  -2\binom{c+2}{3}P(m-2c-1)
  +\binom{c+1}{3}P(m-2c-2).
  \]
  Local rank checks confirm the formula at first support for
  \(c=2,\ldots,6\), giving \(200,1236,4225,10744,22834\).  The new prototype
  `7863_split_linear_degreewise_probe.py` also reproduces
  \(N_2(8)=10,N_2(9)=32,N_3(14)=20\).  It is too slow for \(N_4(20)\), so the
  next implementation step is a compiled split-linear rank tool or a direct
  \(F_1\to F_0\to Q\) presentation verifier.  The saved summary is
  `tmp/7863_chrome_heavy_dialogue/two_parameter_split_linear_degreewise_response.md`.
- The helper `7863_split_linear_targets.py` now records the \(c=6\) target
  arithmetic.  For \(m=32,33,34,35,36\), the target ranks of \(Q|K_L\) are
  \(22740,25340,28105,31040,34150\), corresponding to conjectural endpoint
  values \(94,224,392,600,850\).
- A second Heavy follow-up gave the sparse block-rank identity
  \[
  \operatorname{rank}(Q|K_L)=
  \operatorname{rank}\begin{bmatrix}\delta^{c-2}_1&R^c_m\end{bmatrix}
  -\operatorname{rank}\delta^{c-2}_1,
  \]
  where \(R^c_m\) is built from sixteen precomputed polynomials
  \(B_{hk}(x)\), avoiding expansion of \(u^\alpha\).  For \(c=6\), the first
  endpoint block-rank targets are \(124530,138740,153965\) at
  \(m=32,33,34\).  Heavy also proposed the middle-defect target
  \(\operatorname{HS}(H^{(6)}_2;t)=86+56t\), with first reduced-middle rank
  targets \(714,1484,2625,4120\).  The saved summary is
  `tmp/7863_chrome_heavy_dialogue/two_parameter_sparse_block_certificate_response.md`.
- The new verifier `7863_sparse_block_endpoint_probe.py` implements this block
  identity.  After correcting the \(u_h\) normalization by \(u_h\mapsto
  (-1)^hu_h\), it reproduces \(N_2(8)=10,N_2(9)=32,N_3(14)=20,N_4(20)=36\),
  and \(N_5(26)=60\).  The \(N_5\) block matrix has about \(8.03\) million
  nonzero entries and finishes with `pivot=min` in 823.239 seconds.  The first
  \(N_6\) target \(m=32\) builds a \(279804\times127890\) transposed matrix
  with about \(25.69\) million nonzero entries, but the current
  `rank_sparse_mod` backend timed out at 1800 seconds.
- A later Heavy response proposed a sharper weight decomposition: decompose by
  \(x\)-minus-\(T\) weight, quotient source and target by \(\delta_1\) inside
  each small weight block, then compute the induced
  \(\bar R^c_m:K_L(m,c)\to K_L(m+2,c-2)\).  The local verifier
  `7863_weight_quotient_endpoint_probe.py` implements this route.  It reaches
  the known targets for \(N_4(20)\) and \(N_5(26)\), then reaches the first
  five \(N_6\) target ranks at \(m=32,\ldots,36\):
  \[
  \dim K_L(32,6)=22834,\qquad
  \operatorname{rank}\bar R^6_{32}\ge22740.
  \]
  \[
  \dim K_L(33,6)=25564,\qquad
  \operatorname{rank}\bar R^6_{33}\ge25340.
  \]
  \[
  \dim K_L(34,6)=28497,\qquad
  \operatorname{rank}\bar R^6_{34}\ge28105.
  \]
  It later also reached the next two targets:
  \[
  \dim K_L(35,6)=31640,\qquad
  \operatorname{rank}\bar R^6_{35}\ge31040,
  \]
  \[
  \dim K_L(36,6)=35000,\qquad
  \operatorname{rank}\bar R^6_{36}\ge34150.
  \]
  Hence
  \[
  N_6(32),\ldots,N_6(36)\le94,224,392,600,850.
  \]
  In all five runs the target was reached on the final transposed row, so the
  same finite-field specialization has the exact degreewise values
  \[
  N_6(32),\ldots,N_6(36)=94,224,392,600,850.
  \]
  These values match the first five Hilbert-function values of the
  conjectural numerator
  \[
  \frac{94t^{32}-152t^{33}+60t^{34}}{(1-t)^4}
  \]
  at first support, but this is still a finite-field specialization result
  rather than a full generic \(N_6\) Hilbert-series theorem.  The next proof
  step is either portable exact-rank / matching independent-kernel
  certificates in these degrees, or promotion of the three degree checks to the
  linear resolution
  \(0\to A(-34)^{60}\to A(-33)^{152}\to A(-32)^{94}\to N_6\to0\).
  Portable finite-field pivot artifacts have now been recorded for
  \(m=32,33,34\): `7863_weight_quotient_pivot_certificate.py` gives ranks
  \(22740,25340,28105\), kernel dimensions \(94,224,392\), and stores complete
  pivot row/column/value lists in `tmp/7863_weight_quotient_pivots/`.  The
  artifact hashes are collected in `7863_weight_quotient_n6_support_ledger.json`.
- The direct Cell 9 probe `7863_two_parameter_box_probe.py` now supports
  `--rank-backend external`, using the external sparse rank engine instead of
  the slow dense Python/Numpy path.  With this backend, the \(c=6\),
  \(m=0,\ldots,3\) rank-only full-complex check finishes and gives
  \[
  (H_0,H_1,H_2,H_3)=(0,0,86,0),(0,0,56,0),(0,0,0,0),(0,80,0,0).
  \]
  Equivalently,
  \(h^\bullet_X(-m-4,6)=(0,86,0,0),(0,56,0,0),(0,0,0,0),(0,0,80,0)\).
  This supports the \(c=6\) middle defect \(86+56t\) and shows no new wall
  through the first positive-\(D\) degree.  Composition zero was not recomputed
  in this run; the raw output is `tmp/7863_cell9_c6_m0_3_external_rank.json`.
- After asking the Heavy tab whether the finite-box program can be pushed to
  \(|b|\le10\), Heavy proposed the candidate family
  \[
  N_c(t)=\frac{A_ct^{6c-4}-B_ct^{6c-3}+C_ct^{6c-2}-G_ct^{6c-1}}{(1-t)^4},
  \]
  with
  \[
  A_c=\frac{c(c^2+11)}3,\quad
  B_c=c^3-3c^2+8c-4,\quad
  C_c=(c-1)(c-2)(c-3),
  \]
  \[
  G_c=\frac{(c-6)(c-2)(c-1)}3.
  \]
  The helper `7863_split_linear_targets.py` now emits the corresponding
  endpoint, quotient-rank, and middle-rank targets for \(c=6,\ldots,10\).
  As a first check beyond \(c=6\), the weight-quotient verifier reached the
  \(c=7,m=38\) target:
  \[
  \dim K_L(38,7)=43000,\qquad
  \operatorname{rank}\bar R^7_{38}=42860,
  \]
  hence the finite-field specialization has
  \[
  N_7(38)=140.
  \]
  The matrix had shape \(43000\times48236\) with 4,977,300 nonzero entries,
  and the target was reached on the final row in 1199.208 seconds.  The record
  is stored in `7863_weight_quotient_c7_support_ledger.json`.  This supports
  the first coefficient of the candidate
  \[
  \frac{140t^{38}-248t^{39}+120t^{40}-10t^{41}}{(1-t)^4},
  \]
  but \(N_7\) still needs the remaining support degrees and a
  generation/resolution certificate.
  A follow-up pivot-certificate run also passed: rank \(42860\), pivot count
  \(42860\), pivot product \(412833\), with full pivots stored at
  `tmp/7863_weight_quotient_pivots/weight_quotient_pivots_c7_m38_sparseL_denseQ_seed7863_L8_Q20_min_pivots.json`.
- A recovery Heavy tab was then asked for the next certificate route after
  \(N_7(38)=140\).  Its recommended route is not to run all later ranks
  blindly.  Instead:
  1. construct a canonical \(G_{38}\) kernel basis from the \(m=38\) pivot
     certificate and verify \(\bar R^7_{38}G_{38}=0\);
  2. multiply \(G_{38}\) by \(S_1,S_2,S_3\) to build generated spans in
     degrees \(39,40,41\), with expected ranks \(312,528,790\);
  3. certify quotient-injectivity in degrees \(39,40,41\) by row/projection
     selectors on a complement, proving no extra primitive kernel;
  4. certify the linear resolution
     \[
     S(-41)^{10}\to S(-40)^{120}\to S(-39)^{248}\to S(-38)^{140}
     \]
     and a no-tail/regularity witness.
  The saved response is
  `tmp/7863_chrome_heavy_dialogue/two_parameter_c7_to10_certificate_strategy_response.md`.
- The first local step toward this route is now implemented:
  `7863_weight_quotient_kernel_basis_certificate.py` converts a stored replay
  artifact into a slim kernel-basis certificate.  It verifies hash consistency,
  replayed zero relations, coefficient \(1\) on each free row, and no
  cross-free-row terms.  It passes on the existing \(N_4(20)\) replay, giving
  a 36-vector independent basis certificate at
  `tmp/7863_weight_quotient_kernel_replay/n4_m20_kernel_basis_cert.json`.
  A controlled \(c=7,m=38\) pure-Python replay probe with a 180-second replay
  limit reached only row \(2574\) of \(43000\), with no kernel row yet.  This
  confirms that \(G_{38}\) should be produced by a compiled replay/backsolve
  tool rather than the current Python replay.
- A workspace-local compiled replay prototype has now been added:
  `7863_weight_quotient_kernel_replay.cpp`, wrapped by
  `7863_weight_quotient_compiled_kernel_replay.py`.  It reproduces the
  \(N_4(20)\) Python replay exactly but much faster: rank \(4189\), kernel
  \(36\), max expression fill \(3732\), and the same basis hash
  `2151413b1d0f031b0ebaad7fb043f1088369f2b3268c3bc6ae29af278576c5c8`,
  with replay time 7.834 seconds instead of 294.056 seconds.  A \(c=7,m=38\)
  compiled replay probe still did not reach a kernel row before aborting
  around row \(2359\).  So the next engineering target is more specialized
  than generic replay: use the existing pivot certificate to build a
  pivot-backsolve / quotient-injectivity certificate without storing full
  row-operation expressions for all \(42860\) pivots.
- That specialized route is now implemented in
  `7863_weight_quotient_kernel_factor_replay.cpp`.  On \(N_4(20)\), it
  reproduces the exact same basis hash as the full replay and lowers replay
  time from 7.834 seconds to 4.418 seconds.  More importantly, the full
  \(c=7,m=38\) run now passes: rank \(42860\), kernel \(140\), max generator
  support \(38567\), replay time 3204.18 seconds.  The resulting basis
  certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_factor_basis_cert.json`
  verifies all sparse matvec-zero checks and the free-row identity witness.
  This gives an actual \(G_{38}\) generator-basis certificate for the first
  \(N_7\) support degree.  The next target is the multiplication/generated-span
  certificate for degrees \(39,40,41\), expected ranks \(312,528,790\).
- The generated-span verifier `7863_weight_quotient_generated_span.py` now
  passes all three of these ranks.  Multiplication by \(S_1\) gives
  560 raw columns in degree 39 and rank \(312\), with 248 zero/redundant
  columns; multiplication by \(S_2\) gives 1400 raw columns in degree 40 and
  rank \(528\), with 872 zero/redundant columns; multiplication by \(S_3\)
  gives 2800 raw columns in degree 41 and rank \(790\), with 2010
  zero/redundant columns.  The certificates are
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_to_m39_generated_span_deg1.json`,
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_to_m40_generated_span_deg2.json`,
  and
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_to_m41_generated_span_deg3_external_stream.json`,
  and their hash summaries are now recorded in
  `7863_weight_quotient_c7_support_ledger.json`.  This upgrades \(c=7\) from
  first-support-only evidence to generated-span evidence for
  \(N_7(38),N_7(39),N_7(40),N_7(41)=(140,312,528,790)\) over the chosen
  finite field.  It still does not prove the full \(N_7\) Hilbert series: the
  quotient-injectivity/direct upper-bound certificates and the no-tail or
  linear-resolution witness remain open.
- The first direct upper-bound certificate has now passed.  For \(c=7,m=39\),
  the direct endpoint map has \(\dim K_L(39,7)=47320\) and certified rank
  \(47008\), hence kernel dimension \(312\).  Since this equals the generated
  span rank \(\operatorname{rank}(S_1G_{38})=312\), the degree-39 kernel is
  exactly generated by \(G_{38}\) over the chosen finite field.  The pivot
  certificate has pivot product \(61041\), full pivots stored at
  `tmp/7863_weight_quotient_pivots/weight_quotient_pivots_c7_m39_sparseL_denseQ_seed7863_L8_Q20_min_pivots.json`,
  and summary hashes in `7863_weight_quotient_c7_support_ledger.json`.
  The \(m=40\) direct upper-bound certificate has also passed.  Here
  \(\dim K_L(40,7)=51912\), certified rank is \(51384\), and kernel dimension
  is \(528\), matching \(\operatorname{rank}(S_2G_{38})=528\).  The full pivots
  are stored at
  `tmp/7863_weight_quotient_pivots/weight_quotient_pivots_c7_m40_sparseL_denseQ_seed7863_L8_Q20_min_pivots.json`.
  The \(m=41\) direct upper-bound certificate has now passed too:
  \(\dim K_L(41,7)=56784\), certified rank \(55994\), and kernel dimension
  \(790=\operatorname{rank}(S_3G_{38})\).  The full pivots are stored at
  `tmp/7863_weight_quotient_pivots/weight_quotient_pivots_c7_m41_sparseL_denseQ_seed7863_L8_Q20_min_pivots.json`.
  Thus degrees 39, 40, and 41 are exact, not just lower generated-span
  evidence.  The remaining \(N_7\) gap is a no-tail/linear-resolution or
  regularity witness ruling out hidden later numerator terms, plus the usual
  finite-field-to-generic/characteristic-zero upgrade if needed.
- A no-tail Heavy follow-up suggested checking degree 42 and invoking
  Gotzmann persistence, but the local verifier does not accept that theorem
  step as stated.  For the shifted sequence
  \(M_i=N_7(38+i)=(140,312,528,790,1100,\ldots)\), the Macaulay expansion
  \(790={17\choose3}+{15\choose2}+{5\choose1}\) gives
  \(790^{\langle3\rangle}=3635\), not \(1100\).  Thus degree 42 is not
  automatically a Gotzmann no-tail proof by maximal growth.
  As a finite-field check, however, degree 42 now also passes exactly:
  \(\operatorname{rank}(S_4G_{38})=1100\) from 4900 raw generated columns, and
  the direct endpoint rank is \(60844\) on \(\dim K_L(42,7)=61944\), so
  \(\dim\ker\bar R^7_{42}=1100=\operatorname{rank}(S_4G_{38})\).  The
  generated-span certificate is
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_to_m42_generated_span_deg4_external_stream.json`,
  and the full direct pivots are
  `tmp/7863_weight_quotient_pivots/weight_quotient_pivots_c7_m42_sparseL_denseQ_seed7863_L8_Q20_min_pivots.json`.
  The remaining theorem-level gap is still a real no-tail / linear-resolution
  / regularity certificate, not another checked value alone.
- The generated-span verifier now has an explicit relation-tracking mode for
  first syzygy extraction.  It passed small \(N_2\) and \(N_4\) S1 tests, then
  passed the \(c=7\) S1 case.  The new certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_m38_to_m39_generated_span_deg1_relations.json`
  has the same generated-column hash and pivot hashes as the earlier S1 rank
  certificate, but additionally stores \(248=560-312\) raw-column relation
  vectors.  Each relation vector replays to zero over the finite field.  The
  relation-vector hash is
  `d34e121daa707ed6064b21c6b04d5c09ebbb2c89e4c49164d567100f73acefbc`,
  maximum expression fill is \(260\), and maximum relation support is \(234\).
  This supplies the expected first-syzygy data for the candidate
  \(R(-39)^{248}\to R(-38)^{140}\) step of the \(c=7\) linear resolution, but
  it is not yet the full no-tail certificate: the higher syzygy layers and
  exactness/kernel identification remain open.
- A follow-up local syzygy-layer verifier now shows that the earlier Heavy
  pure-linear-resolution schema is not literally correct.  Multiplying the
  248 first syzygies by \(S_1\) gives 992 raw columns of rank \(868\), not
  the full degree-2 kernel dimension \(1400-528=872\).  The certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_first_syzygies_times_s1_rank868_relations.json`
  stores 124 verified-zero relations among those 992 columns.  Thus there are
  four missing degree-2 kernel directions, and the numerator coefficient is
  compatible through the net \(124-4=120\), rather than a pure
  \(R(-40)^{120}\) step.
- Continuing the same raw-coordinate syzygy-layer check gives
  `tmp/7863_weight_quotient_kernel_replay/c7_second_syzygies_times_s1_rank482_relations.json`,
  where 124 source relations multiplied by \(S_1\) give 496 raw columns of
  rank \(482\) and 14 verified-zero relations.  Multiplying these 14 again by
  \(S_1\) gives
  `tmp/7863_weight_quotient_kernel_replay/c7_third_syzygies_times_s1.json`,
  with 56 raw columns, rank \(56\), and no further relation in this check.
  The finite-field Betti shadow now supported by local evidence is
  \[
  \beta_{1,1}=248,\quad \beta_{1,2}=4,\quad
  \beta_{2,2}=124,\quad \beta_{2,3}=4,\quad \beta_{3,3}=14,
  \]
  whose alternating contribution is
  \(-248t+(124-4)t^2+(4-14)t^3=-248t+120t^2-10t^3\).  This keeps the \(N_7\)
  numerator viable but replaces the old pure-linear certificate target with a
  corrected-resolution target.  The missing constructive step is to extract
  the four degree-2 first-syzygy generators and four degree-3 second-syzygy
  generators, then certify exactness/saturation.
- The four degree-2 first-syzygy generators are now explicit.  The complement
  certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_missing_degree2_syzygy_complement.json`
  reduces the known \(S_1K_{1,1}\) rank-\(868\) subspace in the 1400-dimensional
  \(F_{0,2}\) coordinate module and computes the induced endpoint map on 532
  free coordinates.  The induced rank is \(528\), the missing complement has
  dimension \(4\), and the combined known-plus-missing rank is
  \(872=1400-528\).  The missing-vector hash is
  `891c031750da432ea3044964e6218bcdc390817941cb8644fe6ae67fbbfda0ed`.
- The corrected first-syzygy generators now also pass the degree-3 span check.
  In
  `tmp/7863_weight_quotient_kernel_replay/c7_mixed_first_syzygies_degree3_span.json`,
  the 248 linear syzygies multiplied by \(S_2\) contribute 2480 raw columns,
  and the four quadratic missing syzygies multiplied by \(S_1\) contribute 16
  raw columns.  Together these 2496 columns have rank \(2010\), exactly the
  full degree-3 first-syzygy kernel dimension \(2800-790\), with 486
  verified-zero relations.  The relation-vector hash is
  `2a4a1c58b1120ad88622255032d2918fe27fc47034e687fd96b20c394d5bf8c7`.
  This upgrades the corrected-resolution target from a Betti-shadow
  consistency check to an explicit degree-3 spanning certificate.
- The four missing degree-3 second-syzygy generators are now explicit too.
  The certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_missing_degree3_second_syzygy_complement.json`
  reduces the known \(S_1K_{2,2}\) rank-\(482\) subspace inside the 2496-column
  mixed degree-3 relation module.  The full mixed relation dimension is 486,
  the induced rank on the 2014 free coordinates is 2010, and the resulting
  four missing relation vectors lift the known rank to \(482+4=486\).  The
  missing-vector hash is
  `a97c01065744e0d2b97217ad4fc9a55ed18e434bbe2af82b6fd90df5f39eecd2`.
  This makes the corrected \(c=7\) syzygy layers explicit through degree 3.
- A rank-only degree-4 check now passes for the corrected first-syzygy
  generators.  In
  `tmp/7863_weight_quotient_kernel_replay/c7_mixed_first_syzygies_degree4_rank.json`,
  \(S_3\) times the 248 linear first syzygies gives 4960 raw columns and
  \(S_2\) times the four quadratic missing syzygies gives 40 raw columns.
  Together these 5000 columns have rank \(3800\), exactly the full
  degree-4 first-syzygy kernel dimension \(4900-1100\) from the certified
  \(m=42\) endpoint value.  This verifies corrected first-syzygy generation
  through degree 4, while no-tail/regularity beyond the checked range remains
  open.
- The matching degree-4 second-syzygy span now passes with explicit relations.
  The new verifier `7863_mixed_second_syzygy_span.py` uses 124 known degree-2
  second syzygies multiplied by \(S_2\) (1240 raw columns) and the four
  missing degree-3 second syzygies multiplied by \(S_1\) (16 raw columns) in
  the mixed degree-4 \(F_1\) coordinate module.  The certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_mixed_second_syzygies_degree4_relations.json`
  has 1256 raw columns, rank \(1200\), and 56 verified-zero relations.  This
  rank equals the 1200-dimensional relation space left by the degree-4 mixed
  first-syzygy map.  The column-hash aggregate is
  `9c35eac9bf1429a736d9c481f73764dc6d805cdec5108130b96f55f4e74e20d2`, and
  the relation-vector hash is
  `9d2d135350bda5cafdf5740a8c89de761aef8f3ed8523971bca657515cd29d07`.
  So the corrected second-syzygy generators span the full degree-4 relation
  space over the chosen finite field.  The remaining gap for \(c=7\) is now
  specifically no-tail/regularity and generic characteristic-zero upgrade,
  not a missing degree-4 syzygy-layer rank.
- A further subspace comparison verifies that the 56-dimensional mixed
  degree-4 relation space is exactly \(S_1\) times the 14 third syzygies
  already seen in the known layer.  The script
  `7863_mixed_third_syzygy_comparison.py` rebuilds those 56 \(S_1\)-multiples,
  embeds them into the 1256-dimensional mixed second-syzygy coordinate module,
  and compares them with the stored mixed relation vectors.  In
  `tmp/7863_weight_quotient_kernel_replay/c7_mixed_third_syzygies_degree4_comparison.json`,
  the embedded \(S_1K_{3,3}\) rank is 56, the mixed relation-vector rank is
  56, and the combined rank is still 56.  Hence no new top-syzygy direction
  appears in degree 4 in the finite-field specialization.
- The top layer now has a stronger injectivity witness.  Multiplying the 14
  third syzygies by \(S_2\) and \(S_3\) gives independent spans of ranks 140
  and 280 respectively, with no relations:
  `tmp/7863_weight_quotient_kernel_replay/c7_third_syzygies_times_s2.json`
  and
  `tmp/7863_weight_quotient_kernel_replay/c7_third_syzygies_times_s3.json`.
  More decisively, `7863_top_syzygy_injectivity_certificate.py` evaluates the
  14 polynomial third-syzygy vectors at \((1,2,3,5)\) over the same finite
  field and finds rank 14, with certificate
  `tmp/7863_weight_quotient_kernel_replay/c7_top_third_syzygy_injectivity_eval_1_2_3_5.json`.
  This gives a nonzero 14-by-14 minor, hence the top map is injective over
  \(\operatorname{Frac}(S)\) and has no fourth-syzygy kernel in this
  specialization.  The remaining c7 gap is now lower-layer no-tail/regularity
  plus the generic characteristic-zero lift.

Chrome Heavy was then given the top-injectivity update and asked for a
\(c\le10\) finite-box schema.  The first schema tab hit a front-end
`Connection interrupted` state, so a fresh temporary Heavy tab was opened with
a compact handoff.  That recovery tab returned a usable target table.  With
\[
s=6c-4,\quad
(A,B,C,G)=\left(
\frac{c(c^2+11)}3,\,
c^3-3c^2+8c-4,\,
(c-1)(c-2)(c-3),\,
\frac{(c-6)(c-2)(c-1)}3
\right),
\]
it proposed
\[
N_c(s+q)=
A\binom{q+3}{3}
-B\binom{q+2}{3}
+C\binom{q+1}{3}
-G\binom{q}{3}.
\]
The target values are:

| \(c\) | \(s\) | \(N_c(s)\) | \(N_c(s+1)\) | \(N_c(s+2)\) | \(N_c(s+3)\) | \(N_c(s+4)\) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8 | 44 | 200 | 420 | 690 | 1012 | 1388 |
| 9 | 50 | 276 | 550 | 880 | 1268 | 1716 |
| 10 | 56 | 370 | 704 | 1100 | 1560 | 2086 |

Local verifier update: the first \(c=8\) support point now matches this table.
The weight-quotient endpoint probe at \(c=8,m=44\) reached target rank 74011
at the final source row.  The saved certificate is
`tmp/7863_weight_quotient_endpoint/c8_m44_weight_quotient_rank_cert.json`;
it has source quotient dimension 74211, target quotient dimension 82075, and
9028773 nonzero induced-matrix entries.  Therefore
\[
N_8(44)=\dim\ker\bar R^8_{44}=74211-74011=200.
\]
This is evidence for the first \(c=8\) numerator coefficient only; the
remaining \(m=45,\ldots,48\) values and no-tail/generic-lift certificate are
still open.

Heavy follow-up after the \(N_8(44)\) certificate gave a useful warning for
the \(c=8\) strategy.  The tuple \((200,-380,210,-28)\) should be treated as
the Hilbert numerator shadow only; the verifier should not assume a pure
minimal Betti table.  The \(c=7\) correction shows that cancelling pairs can
hide behind the same numerator.  For \(c=8\), after checking the endpoint
values \(m=44,\ldots,48\), the next data to extract are the kernel
multiplication ranks
\[
S_1\otimes H_{m-1}\to H_m
\]
and the first- and second-relation kernels among those generated columns.
Those ranks determine the corrected minimal Betti shadow; the five Hilbert
values alone do not.  Even if \(N_8(45),\ldots,N_8(48)\) match the target
table, a no-tail theorem is still needed to exclude new generators or higher
tail terms for \(m\ge49\).

Verifier note: the arithmetic table matches the candidate numerator, but it is
still a target, not a proof.  The theorem-level certificate for each fixed
\(c\) needs endpoint dimensions, lower syzygy generation/exactness beyond the
box, a top-map nonzero-minor injectivity witness, and a generic
characteristic-zero lift.  The \(c=7\) top layer now has this injectivity
witness; the lower-layer no-tail/regularity part remains the active gap.

Lower-layer no-tail guardrail: the nonzero top minor proves that
\(\ker d_3=0\) over the domain \(S\), but it does not alone prove exactness of
the whole free complex.  A Buchsbaum--Eisenbud acyclicity certificate for
\[
0\to F_3\xrightarrow{d_3}F_2\xrightarrow{d_2}F_1\xrightarrow{d_1}F_0
\]
would need the expected generic ranks
\[
r_3=f_3,\qquad r_2=f_2-f_3,\qquad r_1=f_1-f_2+f_3,
\]
and the height conditions
\[
\operatorname{grade} I_{r_1}(d_1)\ge1,\quad
\operatorname{grade} I_{r_2}(d_2)\ge2,\quad
\operatorname{grade} I_{r_3}(d_3)\ge3.
\]
So the top-minor certificate is a necessary piece, not the full no-tail
theorem.  A theorem-level finite certificate still needs explicit
regular-sequence/initial-ideal witnesses for these determinantal height
conditions, or an alternative regularity certificate.
