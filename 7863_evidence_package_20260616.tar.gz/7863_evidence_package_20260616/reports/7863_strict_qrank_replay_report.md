# CICY 7863 Strict Python Replay: Cell 9 q-rank Layer

Date: 2026-06-13.

This report records the strict Python replay now added for the Cell 9 reduced
q-rank layer:

```text
c = 4..10
d = 2,3,4
q_d : B(c-2,d-2) -> B(c,d)
field = F_1000003
seed = 7863
mode = sparseL_denseQ
```

Each certificate stores:

- construction parameters;
- source and target quotient-basis hashes;
- canonical sparse matrix hash;
- pivot rows for a full-column-rank minor;
- determinant of that minor modulo `1000003`.

Each replay consumes the stored certificate, rebuilds the matrix from the
recorded recipe, checks the hashes, checks the stored minor determinant, and
derives:

```text
rank(q_d) >= matrix_cols
rank(q_d) <= matrix_cols
rank(q_d) = matrix_cols
```

## Replay Command Pattern

```bash
python3 7863_qrank_certificate_replay.py generate \
  --c C --d D \
  --out certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.json

python3 7863_qrank_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.json \
  --out certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.replay.json
```

## Aggregate Replay Result

All 21 replay outputs passed.

| c | d | rows | cols | det mod 1000003 |
| --- | --- | ---: | ---: | ---: |
| 4 | 2 | 200 | 10 | 576323 |
| 4 | 3 | 340 | 32 | 996800 |
| 4 | 4 | 525 | 69 | 439385 |
| 5 | 2 | 300 | 20 | 166144 |
| 5 | 3 | 500 | 60 | 947111 |
| 5 | 4 | 760 | 124 | 281154 |
| 6 | 2 | 427 | 35 | 311378 |
| 6 | 3 | 700 | 100 | 48827 |
| 6 | 4 | 1050 | 200 | 361165 |
| 7 | 2 | 584 | 56 | 984760 |
| 7 | 3 | 944 | 154 | 920086 |
| 7 | 4 | 1400 | 300 | 615321 |
| 8 | 2 | 774 | 84 | 146914 |
| 8 | 3 | 1236 | 224 | 419060 |
| 8 | 4 | 1815 | 427 | 104882 |
| 9 | 2 | 1000 | 120 | 458567 |
| 9 | 3 | 1580 | 312 | 854289 |
| 9 | 4 | 2300 | 584 | 175570 |
| 10 | 2 | 1265 | 165 | 72937 |
| 10 | 3 | 1980 | 420 | 872782 |
| 10 | 4 | 2860 | 774 | 911223 |

There are 42 generated JSON files in
`certificates/7863_cell9_strict_replay`: one certificate and one replay output
for each of the 21 `(c,d)` pairs.

## Status Under the Skill

This upgrades the q-rank layer from summary/probe evidence to strict Python
replay evidence.

The global CICY 7863 verification is still incomplete because the strict skill
also requires:

- replay/checks for the full reduced Koszul homology layer;
- replay/checks for M0 top correction;
- replay/checks for positive multiplication data;
- a characteristic-zero bridge;
- a Lean certificate-to-formula soundness theorem chain;
- resolution or propagation outside the finite box.
