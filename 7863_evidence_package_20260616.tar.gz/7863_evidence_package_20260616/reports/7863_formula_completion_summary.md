# CICY 7863 formula-completion summary

This records the cells that were re-sent one by one to Chrome ChatGPT
Thinking Heavy for formula completion after the 81-cell audit.  Raw answers
are saved in `tmp/7863_formula_completion_outputs/`.

Target cells processed:

`7, 8, 9, 16, 17, 18, 26, 27, 55, 56, 57, 64, 65, 66, 73, 74, 75`.

Verification pass:

- Every target cell has a non-empty `cell_NNN_formula_completion.md` output.
- No saved output contains the captured failure strings `network error`,
  `Connection interrupted`, `Message delivery timed out`, `Please try again`,
  or `no assistant response captured`.

## Closed or small-rank outcomes

| Cell | Chamber | ChatGPT formula-completion output |
| ---: | --- | --- |
| 16 | `(a,b)=(-3,2)` | Closed formula: `(h0,h1,h2,h3)=(0,0,8,0)`. |
| 26 | `(a,b)=(-2,3)` | Closed formula: `(h0,h1,h2,h3)=(0,8,0,0)`. |
| 56 | `(a,b)=(2,-3)` | Closed formula: `(h0,h1,h2,h3)=(0,0,8,0)`. |
| 57 | `(a,b)=(2,-2)` | Closed formula: `(h0,h1,h2,h3)=(0,1,1,0)`. Follow-up check says the old red-flag audit was wrong: in the Koszul basis `(Q,L1,L2)`, `d(L1 wedge L2)` has no component landing in the `Q` summand. |
| 66 | `(a,b)=(3,-2)` | Rank formula with a 4 by 12 map. If the displayed map is proved surjective, it gives `(h0,h1,h2,h3)=(0,8,0,0)`; otherwise keep `rho=rank(delta)` and use `(0,12-rho,4-rho,0)`. |

## Rank-complex formulas

These cells did not receive a theorem-level closed binomial/polynomial formula.
ChatGPT returned explicit finite-dimensional complexes and rank/homology
formulas instead.  These are directly computable once the indicated maps are
instantiated for the chosen general equations.

| Cell | Chamber | Output status |
| ---: | --- | --- |
| 7 | `a<=-4, b=2` | Endpoint rank formula. With `r=-a-4`, the missing datum is the Hilbert/rank theorem for the endpoint map `alpha_r`; the output gives `h0=0`, `h1=0`, and `h2,h3` in terms of `dim ker alpha_r`. |
| 8 | `a<=-4, b=3` | Three-term mixed operator complex; `h1,h2,h3` are ranks/homology of the displayed `C2 -> C1 -> C0`. |
| 9 | `a<=-4, b>=4` | Full four-term mixed operator complex; all `hi` are given by ranks of `d3,d2,d1`. |
| 17 | `(a,b)=(-3,3)` | One 36 by 36 rank problem: `(h0,h1,h2,h3)=(0,36-rho,36-rho,0)`. |
| 18 | `a=-3, b>=4` | Three-term rank complex `C3 -> C2 -> C1`; `h0,h1,h2` are ranks/homology, `h3=0`. |
| 27 | `a=-2, b>=4` | Three-term rank complex `C3 -> C2 -> C1`; `h0,h1,h2` are ranks/homology, `h3=0`. |
| 55 | `a=2, b<=-4` | Three-term top-y/bottom-x rank complex; `h1,h2,h3` are ranks/homology, `h0=0`. |
| 64 | `a=3, b<=-4` | Three-term top-y/bottom-x rank complex; `h1,h2,h3` are ranks/homology, `h0=0`. |
| 65 | `(a,b)=(3,-3)` | One 36 by 16 rank problem: `(h0,h1,h2,h3)=(0,16-rho,36-rho,0)`. |
| 73 | `a>=4, b<=-4` | Full four-term top-y/bottom-x rank complex; all `hi` are given by ranks of `delta3,delta2,delta1`. |
| 74 | `a>=4, b=-3` | Three-term rank complex `C3 -> C2 -> C1`; `h0,h1,h2` are ranks/homology, `h3=0`. |
| 75 | `a>=4, b=-2` | Three-term rank complex `C3 -> C2 -> C1`; `h0,h1,h2` are ranks/homology, `h3=0`. |

## Main publication-level takeaway

For the problematic non-boundary mixed cells, ChatGPT did not supply a new
closed analytic theorem.  The upgrade over the previous audit is that each
formerly "no formula" cell now has a precise finite-dimensional rank complex
with cohomological degree placement.  To turn most of these into closed
piecewise polynomial formulas, the remaining mathematical task is to prove the
rank/Hilbert-function theorem for the displayed operator complexes.
