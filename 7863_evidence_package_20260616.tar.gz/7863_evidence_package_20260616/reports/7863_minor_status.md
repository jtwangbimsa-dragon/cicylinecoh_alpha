# CICY 7863 Cell 9 Minor Status

## Existing q-rank minors

The strict q-rank certificates in `certificates/7863_cell9_strict_replay/`
already contain explicit full-column-rank minors.  Each certificate records:

- `witness.kind = full_column_rank_minor_mod_p`
- `witness.pivot_rows`
- `witness.det_mod_p`
- `prime = 1000003`

The corresponding replay files check `determinant_nonzero = true`.

| b/c | d | matrix rows | matrix cols | minor size | det mod 1000003 |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 4 | 2 | 200 | 10 | 10 | 576323 |
| 4 | 3 | 340 | 32 | 32 | 996800 |
| 4 | 4 | 525 | 69 | 69 | 439385 |
| 5 | 2 | 300 | 20 | 20 | 166144 |
| 5 | 3 | 500 | 60 | 60 | 947111 |
| 5 | 4 | 760 | 124 | 124 | 281154 |
| 6 | 2 | 427 | 35 | 35 | 311378 |
| 6 | 3 | 700 | 100 | 100 | 48827 |
| 6 | 4 | 1050 | 200 | 200 | 361165 |
| 7 | 2 | 584 | 56 | 56 | 984760 |
| 7 | 3 | 944 | 154 | 154 | 920086 |
| 7 | 4 | 1400 | 300 | 300 | 615321 |
| 8 | 2 | 774 | 84 | 84 | 146914 |
| 8 | 3 | 1236 | 224 | 224 | 419060 |
| 8 | 4 | 1815 | 427 | 427 | 104882 |
| 9 | 2 | 1000 | 120 | 120 | 458567 |
| 9 | 3 | 1580 | 312 | 312 | 854289 |
| 9 | 4 | 2300 | 584 | 584 | 175570 |
| 10 | 2 | 1265 | 165 | 165 | 72937 |
| 10 | 3 | 1980 | 420 | 420 | 872782 |
| 10 | 4 | 2860 | 774 | 774 | 911223 |

## How the endpoint Hilbert numerator is obtained

This is the detailed bookkeeping behind the endpoint numerator table in the
paper.  I write `b` for the finite-box parameter; the certificate files often
call the same parameter `c`.

### 1. What is being computed

For Cell 9 we set `a=-m-4`, with `m >= 0`.  The right endpoint is the map
`C1 -> C0`.  After dualizing this endpoint map, its cokernel dimension becomes
the kernel dimension of a graded map

\[
\alpha_b(m):
A_m\otimes \operatorname{Sym}^b(\mathbb C_y^4)^\vee
\longrightarrow
\left(A_{m+1}\otimes \operatorname{Sym}^{b-1}(\mathbb C_y^4)^\vee\right)^2
\oplus
A_{m+2}\otimes \operatorname{Sym}^{b-2}(\mathbb C_y^4)^\vee .
\]

The three components of this map are multiplication by the two linear rows
`L1,L2` and by the quadratic row `Q`.  The endpoint Hilbert function is

\[
N_b(m)=\dim \ker \alpha_b(m).
\]

So the goal is not to compute one isolated number.  The goal is to compute the
Hilbert series of the graded kernel module `ker alpha_b`.  The answer is written
as

\[
\sum_{m\ge0}N_b(m)t^m
=
\frac{t^{6b-4}(n_{b,0}+n_{b,1}t+n_{b,2}t^2+n_{b,3}t^3)}{(1-t)^4}.
\]

The shift is

\[
s_0=6b-4.
\]

It is convenient to remove this shift and write

\[
H_s=N_b(s_0+s).
\]

The four printed numerator coefficients are fourth finite differences of the
first four shifted values `H_0,H_1,H_2,H_3`.

### 2. Why we first remove the two linear rows

Directly building `alpha_b(m)` is large.  But the first two rows are special:
they are the two linear equations `L1,L2`.  We can quotient by their image
first.  Define

\[
B(n,t)=
\frac{A_t\otimes \operatorname{Sym}^n(\mathbb C_y^4)^\vee}
{L_1(A_{t-1}\otimes \operatorname{Sym}^{n-1}(\mathbb C_y^4)^\vee)
 +L_2(A_{t-1}\otimes \operatorname{Sym}^{n-1}(\mathbb C_y^4)^\vee)} .
\]

In words: `B(n,t)` is what remains in bidegree `(n,t)` after we have already
modded out by the two linear rows.  This is the Buchsbaum--Rim quotient model.
It uses the special structure of the two linear equations instead of treating
the whole endpoint map as one unstructured dense matrix.

After this quotient step, the only nontrivial row still acting is the quadratic
row `Q`.  Therefore `Q` induces maps between the quotient spaces `B(n,t)`.

### 3. Why exactly three q-rank matrices appear

The shifted endpoint module begins in degree `s_0=6b-4`.  The first values are
computed as follows.

For shifted degree `0`,

\[
H_0=P(b)+P(b-4),
\qquad P(r)=\binom{r+3}{3}.
\]

The term `P(b)` is the ordinary quotient piece.  The term `P(b-4)` is the
extra top/Cech summand in `M0`.  This is the correction that caused trouble
before; in the reduced construction it is inserted as a cone/Cech class, not as
an arbitrary extra vector.

For shifted degree `1`, there is no quadratic source yet, so

\[
H_1=\dim B(b,1).
\]

For shifted degrees `2,3,4`, the quadratic row starts to act.  The three
matrices are

\[
q_2:B(b-2,0)\longrightarrow B(b,2),
\]

\[
q_3:B(b-2,1)\longrightarrow B(b,3),
\]

\[
q_4:B(b-2,2)\longrightarrow B(b,4).
\]

Here is the interpretation.  In shifted degree `s`, the target after removing
the two linear rows is `B(b,s)`.  The quadratic row comes from two y-degrees
lower and two x-degrees lower, hence from `B(b-2,s-2)`.  Thus

\[
H_s=\dim B(b,s)-\operatorname{rank}(q_s),
\qquad s=2,3,4.
\]

The certificate proves each `q_s` has full column rank.  Therefore

\[
H_s=\dim B(b,s)-\dim B(b-2,s-2),
\qquad s=2,3,4.
\]

This is why those three matrices are the ones we need.  They are not arbitrary
rank tests: they are exactly the induced action of the remaining quadratic row
on the first three shifted degrees where that row can affect the endpoint
Hilbert function.

### 4. How the H-values become the numerator

Once `H_0,H_1,H_2,H_3` are known, the numerator coefficients are obtained by
fourth finite differences, because the denominator is `(1-t)^4`:

\[
n_{b,0}=H_0,
\]

\[
n_{b,1}=H_1-4H_0,
\]

\[
n_{b,2}=H_2-4H_1+6H_0,
\]

\[
n_{b,3}=H_3-4H_2+6H_1-4H_0.
\]

The `q_4` check gives `H_4`.  It verifies that the first possible coefficient
after the printed numerator vanishes:

\[
n_{b,4}=H_4-4H_3+6H_2-4H_1+H_0=0.
\]

So the endpoint layer does two limited things:

1. `q_2` and `q_3`, together with the structural values `H_0,H_1`, give the
   printed coefficients `n_{b,0},...,n_{b,3}`.
2. `q_4` verifies that the next coefficient after the printed numerator is
   zero.

This is not, by itself, a propagation proof for `q_5,q_6,...` or for all higher
shifted degrees.  To turn the displayed endpoint numerator into a full
all-degree theorem one still needs a separate regularity/no-tail argument, a
resolution or initial-module certificate, or additional higher-degree rank
certificates.

### 5. Example: b=4

For `b=4`, the shift is

\[
s_0=6b-4=20.
\]

The structural first value is

\[
H_0=P(4)+P(0)=35+1=36.
\]

The next value is

\[
H_1=\dim B(4,1)=100.
\]

The q-rank certificates say:

- `q_2` has matrix size `200 x 10` and full column rank `10`, so
  \[
  H_2=200-10=190.
  \]
- `q_3` has matrix size `340 x 32` and full column rank `32`, so
  \[
  H_3=340-32=308.
  \]
- `q_4` has matrix size `525 x 69` and full column rank `69`, so
  \[
  H_4=525-69=456.
  \]

Now take finite differences:

\[
n_{4,0}=36,
\]

\[
n_{4,1}=100-4\cdot36=-44,
\]

\[
n_{4,2}=190-4\cdot100+6\cdot36=6,
\]

\[
n_{4,3}=308-4\cdot190+6\cdot100-4\cdot36=4.
\]

The next coefficient is

\[
n_{4,4}=456-4\cdot308+6\cdot190-4\cdot100+36=0.
\]

Thus the endpoint numerator for `b=4` is

\[
36t^{20}-44t^{21}+6t^{22}+4t^{23}.
\]

The other rows `b=5,...,10` are computed in exactly the same way, using the
three corresponding `q_2,q_3,q_4` certificates in the table above.

### 6. What the certificates prove

The dimensions of the spaces `B(b,s)` are structural after the two linear rows
have been quotiented out.  What is not automatic is the rank of the induced
quadratic maps `q_s`.  A rank drop in any of these maps would change the value
of `H_s`, and therefore would change the finite differences and the Hilbert
numerator.

That is why the endpoint evidence consists of `7 x 3 = 21` q-rank
certificates.  For each `b=4,...,10` and each `s=2,3,4`, the certificate:

- rebuilds the same quotient matrix over `F_1000003`;
- checks the matrix hash;
- records explicit pivot rows for a full-column-rank minor;
- computes the determinant of that minor modulo `1000003`;
- checks that the determinant is nonzero.

Nonzero determinant means the displayed minor has full rank over the finite
field.  Since its entries come from an integral specialization of the universal
coefficient matrix, the same determinant is a nonzero polynomial condition on
the coefficients.  This gives a nonempty Zariski-open condition in
characteristic zero.  Intersecting these finitely many opens is what upgrades
the endpoint rank statement from a finite-field computation to a generic
characteristic-zero certificate layer.

## Left-injectivity minors now exported

The leftmost reduced Koszul map

```text
d_L4M0_to_L3M1
```

now has compact nonzero-minor certificates in
`certificates/7863_cell9_left_injectivity_minors/`.  Each certificate records
the full pivot row list and determinant modulo `1000003`; each replay rebuilds
the matrix and checks that the determinant is nonzero.

| b/c | matrix rows | matrix cols | minor size | det mod 1000003 | replay |
| ---: | ---: | ---: | ---: | ---: | --- |
| 4 | 400 | 36 | 36 | 742387 | passed |
| 5 | 616 | 60 | 60 | 69836 | passed |
| 6 | 896 | 94 | 94 | 14531 | passed |
| 7 | 1248 | 140 | 140 | 158735 | passed |
| 8 | 1680 | 200 | 200 | 781756 | passed |
| 9 | 2200 | 276 | 276 | 215919 | passed |
| 10 | 2816 | 370 | 370 | 862706 | passed |

The export/replay script is `7863_left_injectivity_minor_export.py`.

## Full reduced Koszul rank-minor layer now exported

The full reduced Koszul replay layer now also has explicit rank-minor
witnesses in
`certificates/7863_cell9_full_koszul_rank_minors/`.  For each `c=4,...,10`,
the certificate records all ten differential matrices:

```text
d_WM0_to_M1
d_L2M0_to_WM1
d_WM1_to_M2
d_L3M0_to_L2M1
d_L2M1_to_WM2
d_WM2_to_M3
d_L4M0_to_L3M1
d_L3M1_to_L2M2
d_L2M2_to_WM3
d_WM3_to_M4
```

For every rank entry the certificate stores the selected pivot rows, pivot
columns, matrix dimensions, matrix hash, rank, and the nonzero pivot product
modulo `1000003`.  Replay rebuilds the matrix, checks the hash, checks the
restricted rank-size minor, checks the pivot product is nonzero, and recomputes
the Koszul homology from the certified ranks.

| b/c | rank-minor entries | nonzero witnesses | replay |
| ---: | ---: | --- | --- |
| 4 | 10 | yes | passed |
| 5 | 10 | yes | passed |
| 6 | 10 | yes | passed |
| 7 | 10 | yes | passed |
| 8 | 10 | yes | passed |
| 9 | 10 | yes | passed |
| 10 | 10 | yes | passed |

The compact rank vectors, in the order listed above, are:

| b/c | ranks |
| ---: | --- |
| 4 | `[100, 206, 190, 144, 452, 308, 36, 364, 776, 456]` |
| 5 | `[154, 332, 280, 240, 680, 440, 60, 556, 1124, 636]` |
| 6 | `[224, 500, 392, 372, 968, 600, 94, 802, 1550, 850]` |
| 7 | `[312, 716, 528, 546, 1322, 790, 140, 1108, 2060, 1100]` |
| 8 | `[420, 986, 690, 768, 1748, 1012, 200, 1480, 2660, 1388]` |
| 9 | `[550, 1316, 880, 1044, 2252, 1268, 276, 1924, 3356, 1716]` |
| 10 | `[704, 1712, 1100, 1380, 2840, 1560, 370, 2446, 4154, 2086]` |

The export/replay script is `7863_full_koszul_rank_minor_export.py`.

For `c=10`, an additional independent replay was run from the saved
certificate and passed with:

- `all_rank_minor_checks = true`
- `ranks_match = true`
- `homology_match = true`

## Still missing optional explicit minor layer

The `M0`/positive-multiplication certificates currently store rank data, matrix
hashes, and pivot-row hashes, but not explicit determinant/rank-minor
witnesses:

- `mu_c*.json`: stores rank entries and `pivot_rows_sha256`.

Thus the q-rank endpoint layer, the left-injectivity layer, and the full
reduced Koszul middle/no-correction layer now have nonzero-minor witnesses.
The remaining optional pass is to export the same style of explicit witnesses
for the `M0`/positive layer if we want that layer to have identical certificate
formatting.
