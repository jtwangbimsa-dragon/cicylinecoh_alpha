# CICY 7863 Lean Verification Audit

Date: 2026-06-13.

This report follows the `cicy-lean-verification` skill workflow for CICY 7863
Cell 9 and its Serre-dual Cell 73.

## Agent A: Mathematical Extraction

- Configuration: CICY 7863 is the complete intersection in `P3 x P3` with
  configuration `[[P3 | 2 1 1], [P3 | 2 1 1]]`.
- Cell 9 is normalized as `a = -m - 4`, `m >= 0`, `b = c`, with checked box
  `4 <= c <= 10`.
- Cell 73 is the Calabi-Yau Serre-dual slice, represented by `a = m + 4`,
  `b = -c`.
- Endpoint numerator:
  `s = 6*c - 4`,
  `A = c*(c^2 + 11)/3`,
  `B = c^3 - 3*c^2 + 8*c - 4`,
  `C = (c - 1)*(c - 2)*(c - 3)`,
  `G = (c - 6)*(c - 2)*(c - 1)/3`.
- For `c = 4..10`, the finite-field artifacts record q-rank, M0 correction,
  positive multiplication, and full reduced Koszul homology summaries.
- Agent A classified the current package as `finite-box` summary evidence.
  There are no no-map or analytic-map proofs for Cell 9/73 in the current
  package.
- Scope caveat: the Lean formula currently formalizes the reduced
  endpoint/probe bookkeeping table.  It does not formalize the central parity
  wall formula in `paper_version.tex` around `eq:7863-central-parity-wall`,
  which states nonzero wall homology at even wall points.  This mismatch must
  be resolved before claiming that Lean verifies the paper text verbatim.

## Agent B: Lean Replay Design

Recommended theorem ladder:

1. Export one concrete full-column-rank witness for the smallest q-map,
   namely Cell 9 `c = 4`, `d = 2`, a `200 x 10` matrix with rank `10`.
2. Replay the witness in Lean with a Std-only Boolean checker.
3. Use the checker soundness theorem to derive a local proposition such as
   `FullColumnRankOverFp q_c4_d2`.
4. Repeat for the q-rank, M0 top-correction, positive multiplication, and
   Koszul differential ranks needed by each slice.
5. Keep finite-field replay, characteristic-zero bridge, and propagation as
   separate theorem layers.

Minimum fields for each replayable rank certificate:

- coefficient domain and prime;
- matrix construction recipe;
- source and target basis order;
- pivot/minor/RREF witness proving the rank lower bound;
- structural or explicit upper-bound witness;
- Lean executable checker;
- soundness theorem connecting `checker = true` to the rank statement.

## Lean Integration Status

Implemented modules:

- `LeanProofs/PaperVersion/Section32/Case7863.lean`
- `LeanProofs/PaperVersion/Section32/Case7863CertificateAudit.lean`
- `LeanProofs/PaperVersion/Section32/Case7863CellLedger.lean`

Lean-proved/bookkeeping facts now include:

- the checked c-box is exactly `c = 4..10`;
- the endpoint numerator coefficients agree with the closed formula for
  `c = 4..10`;
- the recorded Koszul homology table has Euler coefficients matching the
  numerator coefficients;
- shifted degree 4 is zero in every recorded slice;
- Cell 73 is the formal Serre-dual reversal of Cell 9;
- the current artifact ledger is explicitly classified as summary-only or
  background-assumed, not replayed.
- the 81-cell ledger induced by the nine intervals
  `<= -4, -3, -2, -1, 0, 1, 2, 3, >= 4` on each coordinate has Lean-checked
  selected-cell coverage and uniqueness.
- the mixed cells are classified into external finite-box cells and the two
  partial finite-box cells `[9, 73]`.

## Current Trusted Boundary

`lean_proved`:

- finite list coverage and arithmetic consistency;
- numerator/Euler bookkeeping;
- formal Serre-dual vector reversal;
- audit checks that current finite-field artifacts are not replayable Lean
  witnesses.

`external_computation_assumed`:

- current JSON q-rank summaries;
- current JSON full-Koszul homology summaries;
- current M0 top-correction and positive multiplication summaries;
- old weight-quotient pivot-coordinate dumps.

`background_geometry_assumed`:

- Bott-Kunneth and Koszul exactness;
- reduced quotient construction;
- Cell 9/73 identification with CICY line-bundle cohomology;
- generic characteristic-zero bridge;
- endpoint-to-all-`m` propagation.
- agreement between the reduced endpoint/probe formula and the paper's central
  parity wall paragraph.

## Conditional Global Theorem

The strict global theorem currently proved in Lean is conditional:

```lean
PaperVersion.Section32.Case7863.CellLedger.cellwise_conditional_formula_sound
```

It says that if each selected cell has an explicit soundness assumption for its
mechanism class, then the selected computed value equals the selected printed
formula.  This is intentionally not reported as a fully Lean-proved CICY
cohomology theorem, because the mixed-row rank data and background geometry are
still trusted-boundary inputs.

The theorem is useful because the assumptions are visible fields of
`CellwiseSoundnessAssumptions`; no rank computation is hidden as an unnamed
axiom.

## Verification Log

Commands run:

```bash
cd LeanProofs
./lake-local build
rg -n "\b(sorry|admit|axiom|constant|opaque)\b" LeanProofs
LEAN_PATH=./.lake/build/lib ./lean-local /tmp/7863_strict_axioms.lean
```

Build result:

```text
Build completed successfully.
```

Forbidden-keyword scan:

```text
no matches
```

Key `#print axioms` output:

```text
boxLE10_arithmetic_consistent: no axioms
finiteFieldArtifacts_not_replayed: no axioms
qRankSummaries_all_internally_consistent: no axioms
selectedCell_region: [propext, Quot.sound]
allCellsHaveKnownStatus_true: [propext, Quot.sound]
selected_cell_has_ledger_status: [propext, Quot.sound]
cellwise_conditional_formula_sound: [propext, Quot.sound]
```

`propext` and `Quot.sound` are Lean core principles used by the proof
machinery.  There are no project-specific axioms.

## Next Replay Target

The first real Lean replay target should be Cell 9 `c = 4`, `d = 2`:

- finite field: `F_1000003`;
- matrix dimensions: `200 x 10`;
- expected full-column rank: `10`;
- upper bound: structural, because rank is at most the number of columns;
- missing export: a pivot trace, nonzero minor/LU certificate, or RREF witness
  tied to the exact matrix recipe and basis order.
