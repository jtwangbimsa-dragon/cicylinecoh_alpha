# CICY 7863 Strict Python Replay: Cell 9 M0/Positive Multiplication Layer

Date: 2026-06-13.

This report records the standalone strict Python replay now added for the Cell
9 M0-top and positive-multiplication layers:

```text
c = 4..10
field = F_1000003
seed = 7863
mode = sparseL_denseQ
```

The replay uses:

- checker/generator: `7863_mu_certificate_replay.py`;
- helper/reduced-map recipe: `7863_qrank_certificate_replay.py` and
  `7863_reduced_q_rank_probe.py`;
- certificate/replay directory:
  `certificates/7863_cell9_strict_replay`.

Each certificate stores:

- M0 dimensions, including regular/top split;
- module dimensions `M1..M4`;
- sparse matrix hashes and exact ranks for `mu0_x0..mu0_x3`;
- sparse matrix hashes and exact ranks for `mu_d1_x*`, `mu_d2_x*`,
  `mu_d3_x*`;
- pivot-row hashes from exact finite-field elimination;
- M0-M1 commutativity checks;
- positive-degree commutativity checks.

Each replay consumes the stored certificate, rebuilds all maps from the
recorded recipe, recomputes exact ranks over `F_1000003`, checks all hashes,
and checks all commutativity squares.

## Replay Command Pattern

```bash
python3 7863_mu_certificate_replay.py generate \
  --c C \
  --out certificates/7863_cell9_strict_replay/mu_cC.json

python3 7863_mu_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/mu_cC.json \
  --out certificates/7863_cell9_strict_replay/mu_cC.replay.json
```

## Aggregate Replay Result

All 7 M0/positive replay outputs passed.

| c | replay seconds | M0 regular/top/total | module dims M1..M4 | M0 squares | positive squares |
| --- | ---: | --- | --- | --- | --- |
| 4 | 0.236092 | 35 + 1 = 36 | 100, 190, 308, 456 | true | true |
| 5 | 0.653239 | 56 + 4 = 60 | 154, 280, 440, 636 | true | true |
| 6 | 1.524944 | 84 + 10 = 94 | 224, 392, 600, 850 | true | true |
| 7 | 3.247680 | 120 + 20 = 140 | 312, 528, 790, 1100 | true | true |
| 8 | 6.684703 | 165 + 35 = 200 | 420, 690, 1012, 1388 | true | true |
| 9 | 13.016111 | 220 + 56 = 276 | 550, 880, 1268, 1716 | true | true |
| 10 | 24.706523 | 286 + 84 = 370 | 704, 1100, 1560, 2086 | true | true |

There are 14 generated M0/positive JSON files: one certificate and one replay
output for each `c`.

## SHA256 Samples

```text
7863_mu_certificate_replay.py:
56fa116326537c5a8fb46245827776d602006471c9b5402c53c77b546cfa84e0

certificates/7863_cell9_strict_replay/mu_c10.json:
5b207138aa107035e1fe3b0600b1ff399d3c7033997552b5fa353faf4437e12b

certificates/7863_cell9_strict_replay/mu_c10.replay.json:
bc29418edbbc7f0100b0c201b72c43f5e399a9462b18c3227fdf3f87bdc4842d
```

## Status Under the Skill

This upgrades the standalone M0-top and positive-multiplication layers from
summary/probe evidence to strict Python replay evidence.

The global CICY 7863 verification is still incomplete because the strict skill
also requires:

- characteristic-zero bridge from finite-field replay;
- Lean certificate-to-formula soundness theorem chain;
- formal reduced-complex-to-CICY cohomology bridge;
- resolution or propagation outside the finite box;
- analytic formula chains for the non-finite-box cells;
- alignment with or correction of the paper central parity wall.
