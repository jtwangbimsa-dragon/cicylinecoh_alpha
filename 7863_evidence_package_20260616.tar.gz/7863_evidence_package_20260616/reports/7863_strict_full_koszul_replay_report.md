# CICY 7863 Strict Python Replay: Cell 9 Full Reduced Koszul Layer

Date: 2026-06-13.

This report records the strict Python replay now added for the Cell 9 full
reduced Koszul layer:

```text
c = 4..10
field = F_1000003
seed = 7863
mode = sparseL_denseQ
```

The replay uses:

- checker/generator: `7863_full_koszul_certificate_replay.py`;
- helper/reduced-map recipe: `7863_qrank_certificate_replay.py` and
  `7863_reduced_q_rank_probe.py`;
- certificate/replay directory:
  `certificates/7863_cell9_strict_replay`.

Each certificate stores:

- module dimensions `M0..M4`;
- sparse matrix hashes for all ten Koszul differentials;
- exact finite-field ranks;
- pivot-row hashes from exact elimination;
- Koszul homology by shifted degree;
- Euler coefficients;
- zero-composition checks for the complex.

Each replay consumes the stored certificate, rebuilds the matrices from the
recorded recipe, recomputes exact ranks over `F_1000003`, checks all hashes,
checks zero compositions, and recomputes homology/Euler data.

## Replay Command Pattern

```bash
python3 7863_full_koszul_certificate_replay.py generate \
  --c C \
  --out certificates/7863_cell9_strict_replay/full_koszul_cC.json

python3 7863_full_koszul_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/full_koszul_cC.json \
  --out certificates/7863_cell9_strict_replay/full_koszul_cC.replay.json
```

## Aggregate Replay Result

All 7 full-Koszul replay outputs passed.

| c | replay seconds | module dims M0..M4 | Euler degrees 1..4 |
| --- | ---: | --- | --- |
| 4 | 0.423126 | 36, 100, 190, 308, 456 | -44, 6, 4, 0 |
| 5 | 1.394241 | 60, 154, 280, 440, 636 | -86, 24, 4, 0 |
| 6 | 4.113203 | 94, 224, 392, 600, 850 | -152, 60, 0, 0 |
| 7 | 11.325387 | 140, 312, 528, 790, 1100 | -248, 120, -10, 0 |
| 8 | 30.738445 | 200, 420, 690, 1012, 1388 | -380, 210, -28, 0 |
| 9 | 74.426278 | 276, 550, 880, 1268, 1716 | -554, 336, -56, 0 |
| 10 | 163.750952 | 370, 704, 1100, 1560, 2086 | -776, 504, -96, 0 |

All zero-composition checks are zero for every `c=4..10`.

There are 14 generated full-Koszul JSON files: one certificate and one replay
output for each `c`.

## SHA256 Samples

```text
7863_full_koszul_certificate_replay.py:
05e317121fa4199503825bc4d79087360899def4416439acad2a844f952e1c3d

certificates/7863_cell9_strict_replay/full_koszul_c10.json:
a02fe15eb28a765962d5fe7ae9a1fd9686196599ee9f898746df4ea5c0e4c2de

certificates/7863_cell9_strict_replay/full_koszul_c10.replay.json:
ea98427dac5d88b77101764fb4acf61086883de3c6c6095fb84222181381f6e0
```

## Status Under the Skill

This upgrades the full reduced Koszul layer from summary/probe evidence to
strict Python replay evidence.

The global CICY 7863 verification is still incomplete because the strict skill
also requires:

- characteristic-zero bridge from the finite-field computation;
- Lean certificate-to-formula soundness theorem chain;
- formal reduced-complex-to-CICY cohomology bridge;
- resolution or propagation outside the finite box;
- alignment with or correction of the paper central parity wall.

The standalone M0-top and positive-multiplication probe ledgers are still not
separate stored-witness replay certificates, although the full-Koszul replay
rebuilds the M0 and positive multiplication data internally and checks the
resulting Koszul complex/ranks/homology.
