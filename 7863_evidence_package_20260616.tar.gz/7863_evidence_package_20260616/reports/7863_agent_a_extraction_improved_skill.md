# Agent A Extraction Artifact: CICY 7863 Improved Skill Run

Status: `incomplete`. Do not claim fully verified.

## Scope / Cells

Config: CICY 7863,

```text
[[P3 | 2 1 1],
 [P3 | 2 1 1]]
```

Line bundles are `O_X(a,b)`.

Lean partition: 9 x 9 Bott grid with axis ranges
`<= -4, -3, -2, -1, 0, 1, 2, 3, >= 4`; 81 cells.

| Cells | Classification | Current status |
| --- | --- | --- |
| PB/PT/B/Bdual | `analytic-map` | `external_assumption` |
| D cells | `no-map` | `external_assumption` |
| M except 9/73 | `finite-box` | `external_assumption` |
| Cell 9, `4 <= b <= 10` | `finite-box` | Python strict replay passed, Lean bridge missing |
| Cell 9, `b >= 11` | `finite-box` | `unverified` |
| Cell 73, `-10 <= b <= -4` | `finite-box` | Serre-dual bookkeeping, same missing bridges |
| Cell 73, `b <= -11` | `finite-box` | `unverified` |

## Finite-Box Metadata

Field: `F_1000003`, prime `1000003`.

Specialization: `seed=7863`, `mode=sparseL_denseQ`,
`sparse_l_terms=8`, `sparse_q_terms=20`.

Certificate directories and manifests:

- `certificates/7863_cell9_strict_replay/`
- `certificates/7863_cell9_box_lt10/manifest.json`
- `certificates/7863_cell9_reduced/manifest.json`

Current script hashes:

```text
7863_qrank_certificate_replay.py:
11c02fde5f914ee94c67bac2161dcdd78a77eef8907dacc852138939b0ca3e10

7863_full_koszul_certificate_replay.py:
05e317121fa4199503825bc4d79087360899def4416439acad2a844f952e1c3d

7863_reduced_q_rank_probe.py:
195c46b48ed14830b83129cbb9d20ca1a5e149c5e59f884e55bcb31bcf64d057
```

Hash/check policy:

- q-rank certificates store source/target quotient-basis hashes, canonical
  sparse matrix hash, pivot rows, and nonzero minor determinant modulo
  `1000003`.
- q-rank replay rebuilds the matrix, checks hashes, determinant, pivot bounds,
  and proves `rank = cols` via lower bound plus structural upper bound.
- full-Koszul certificates store `M0..M4`, ten differential sparse matrix
  hashes, exact ranks, pivot-row hashes, zero-composition checks, homology, and
  Euler coefficients.
- full-Koszul replay rebuilds matrices, recomputes ranks, checks hashes, checks
  zero compositions, and recomputes homology/Euler data.

Claimed finite-field targets:

- q-rank: `q_d : B(c-2,d-2) -> B(c,d)` has full column rank over
  `F_1000003`.
- full-Koszul: full reduced Koszul differential ranks and homology over
  `F_1000003`.
- Intended paper target remains the Cell 9/Cell 73 CICY cohomology formula, but
  Lean does not yet prove the bridge.

## Replayed Certificates

Strict q-rank replay: `21 / 21 passed`, for `c=4..10`, `d=2,3,4`.

```text
c=4:  d2 200x10,   d3 340x32,   d4 525x69
c=5:  d2 300x20,   d3 500x60,   d4 760x124
c=6:  d2 427x35,   d3 700x100,  d4 1050x200
c=7:  d2 584x56,   d3 944x154,  d4 1400x300
c=8:  d2 774x84,   d3 1236x224, d4 1815x427
c=9:  d2 1000x120, d3 1580x312, d4 2300x584
c=10: d2 1265x165, d3 1980x420, d4 2860x774
```

Strict full reduced Koszul replay: `7 / 7 passed`, for `c=4..10`.

```text
c=4:  M=36,100,190,308,456      Euler=-44,6,4,0
c=5:  M=60,154,280,440,636      Euler=-86,24,4,0
c=6:  M=94,224,392,600,850      Euler=-152,60,0,0
c=7:  M=140,312,528,790,1100    Euler=-248,120,-10,0
c=8:  M=200,420,690,1012,1388   Euler=-380,210,-28,0
c=9:  M=276,550,880,1268,1716   Euler=-554,336,-56,0
c=10: M=370,704,1100,1560,2086  Euler=-776,504,-96,0
```

Prime/field consistency statement: manifests, scripts, generated certificates,
replay outputs, and reports consistently use `prime=1000003`, i.e.
`F_1000003`, with `seed=7863` and `mode=sparseL_denseQ`.

## Agent B Replay Commands

Full q-rank batch pattern:

```bash
for c in 4 5 6 7 8 9 10; do
  for d in 2 3 4; do
    python3 7863_qrank_certificate_replay.py replay \
      certificates/7863_cell9_strict_replay/c${c}_d${d}_qrank_full_column_rank.json \
      --out /tmp/c${c}_d${d}_qrank_full_column_rank.replay.json
  done
done
```

Full Koszul batch pattern:

```bash
for c in 4 5 6 7 8 9 10; do
  python3 7863_full_koszul_certificate_replay.py replay \
    certificates/7863_cell9_strict_replay/full_koszul_c${c}.json \
    --out /tmp/full_koszul_c${c}.replay.json
done
```

Stored full-batch outputs already exist in
`certificates/7863_cell9_strict_replay/*.replay.json`.

Mandatory representative replay set if full re-run is too expensive:

```bash
python3 7863_qrank_certificate_replay.py replay certificates/7863_cell9_strict_replay/c4_d2_qrank_full_column_rank.json
python3 7863_qrank_certificate_replay.py replay certificates/7863_cell9_strict_replay/c10_d4_qrank_full_column_rank.json
python3 7863_full_koszul_certificate_replay.py replay certificates/7863_cell9_strict_replay/full_koszul_c4.json
python3 7863_full_koszul_certificate_replay.py replay certificates/7863_cell9_strict_replay/full_koszul_c10.json
```

## Existing Lean Theorems

```text
selectedCell_region
selectedCell_unique
axisRange_unique
cellEntries_length
count_PB / count_PT / count_D / count_M / count_B / count_Bdual
mCellIds_eq
boundaryCellIds_eq
partialFiniteBoxMixedIds_eq
externalFiniteBoxMixedIds_eq
boxLE10_arithmetic_consistent
qRankSummaries_count
qRankSummaries_all_internally_consistent
finiteFieldArtifacts_not_replayed
strictPythonReplayArtifacts_recorded
strictPythonReplayArtifacts_not_lean_bridge
requiredRankReplayFields_count
replay_schema_accepts_requires_checker
cell73Formula_is_serreDual
serreDual_involutive
cell9_outside_box_is_gap
cell73_outside_box_is_gap
cellwise_conditional_formula_sound
```

These prove partition, ledger counts/statuses, arithmetic consistency,
Serre-dual reversal, replay-schema bookkeeping, Python-replay ledger
bookkeeping, and explicit outside-box gap markers. They do not prove the final
CICY formula.

## Missing Bridges / Gaps

- Lean certificate-to-formula bridge.
- Characteristic-zero bridge from `F_1000003`.
- Reduced-complex-to-CICY bridge.
- Outside-box propagation for Cell 9/73.
- Central parity wall alignment with paper.
- Complete analytic proof chains for PB/PT/D/B/Bdual.
- Separate stored-witness replay for standalone M0-top and
  positive-multiplication ledgers, although full-Koszul replay rebuilds/checks
  the resulting complex internally.

## Anticipated Agent B Blockers

| Blocker | Agent A response |
| --- | --- |
| q-rank certs replay strictly? | `resolved_by_artifact`: `7863_strict_qrank_replay_report.md`, `7863_qrank_certificate_replay.py`, `certificates/7863_cell9_strict_replay/c*_d*_qrank_full_column_rank*.json` |
| full-Koszul certs replay strictly? | `resolved_by_artifact`: `7863_strict_full_koszul_replay_report.md`, `7863_full_koszul_certificate_replay.py`, `certificates/7863_cell9_strict_replay/full_koszul_c*.json` |
| prime/field mismatch? | `resolved_by_artifact`: manifests, scripts, certificates, and replay outputs all record `prime=1000003` |
| Lean still says finiteFieldArtifacts_not_replayed. | `resolved_by_patch`: `LeanProofs/PaperVersion/Section32/Case7863CertificateAudit.lean` now records strict Python replay artifacts separately from legacy summaries. |
| Lean certificate-to-formula theorem missing. | `blocked_with_reason`: no current Lean theorem connects replayed ranks/homology to CICY cohomology formula. |
| Characteristic-zero bridge missing. | `blocked_with_reason`: current evidence is one finite-field specialization; no formal char-zero transfer theorem. |
| Reduced-complex-to-CICY bridge missing. | `blocked_with_reason`: reduction remains background geometry, not Lean-proved. |
| Cell 9 `b>=11` / Cell 73 `b<=-11` unresolved. | `blocked_with_reason`: Lean explicitly marks these as unresolved outside finite box. |
| Central parity wall formalized? | `blocked_with_reason`: paper wall is noted but not Lean-aligned/formalized. |
| Analytic cells fully proved? | `blocked_with_reason`: PB/PT/D/B/Bdual proof chains are still assumptions. |
| Standalone M0/positive-mu replay? | `blocked_with_reason`: not separate stored-witness replay certs yet; full-Koszul replay checks the resulting complex internally. |

Final Agent A classification: `incomplete`.
