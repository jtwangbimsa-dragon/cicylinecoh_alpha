# CICY 7863 Strict Replay Gate Status

Date: 2026-06-13.

Skill: `cicy-lean-verification`.

Final classification: `incomplete`.

This run followed the strict two-agent protocol:

- Agent A extraction artifact: `7863_agent_a_extraction_strict_replay.md`
- Agent B audit artifact: `7863_agent_b_audit_strict_replay.md`

Post-audit correction: strict Python replay certificates have now been added
for the finite-box q-rank layer and the full reduced Koszul layer:

- `7863_strict_qrank_replay_report.md`
- `7863_strict_full_koszul_replay_report.md`
- `7863_strict_mu_replay_report.md`
- `7863_strict_replay_c4d2_report.md`
- `7863_qrank_certificate_replay.py`
- `7863_full_koszul_certificate_replay.py`
- `7863_mu_certificate_replay.py`
- `certificates/7863_cell9_strict_replay/c*_d*_qrank_full_column_rank.json`
- `certificates/7863_cell9_strict_replay/c*_d*_qrank_full_column_rank.replay.json`
- `certificates/7863_cell9_strict_replay/full_koszul_c*.json`
- `certificates/7863_cell9_strict_replay/full_koszul_c*.replay.json`
- `certificates/7863_cell9_strict_replay/mu_c*.json`
- `certificates/7863_cell9_strict_replay/mu_c*.replay.json`

This improves all 21 q-rank components for `c=4..10`, `d=2,3,4` from
summary/probe evidence to strict Python replay evidence. It also improves all
7 full reduced Koszul homology computations for `c=4..10` to strict Python
replay evidence. It also improves the standalone M0-top and
positive-multiplication layers for `c=4..10` to strict Python replay evidence.
It does not change the global classification, because the characteristic-zero
bridge, the Lean certificate-to-formula bridge, the formal
reduced-complex-to-CICY bridge, and finite-box propagation/outside-box
resolution are still missing.

## Commands Re-run in Main Thread

```bash
cd LeanProofs
./lake-local build
```

Result:

```text
Build completed successfully.
```

```bash
rg -n "\b(sorry|admit|axiom|constant|opaque)\b" LeanProofs
```

Result: no matches.

```bash
LEAN_PATH=./.lake/build/lib ./lean-local /tmp/7863_strict_replay_axioms.lean
```

Result summary:

```text
boxLE10_arithmetic_consistent: no axioms
finiteFieldArtifacts_not_replayed: no axioms
qRankSummaries_all_internally_consistent: no axioms
replay_schema_accepts_requires_checker: [propext]
cellEntries_length: no axioms
count_M: no axioms
mCellIds_eq: no axioms
partialFiniteBoxMixedIds_eq: [propext, Quot.sound]
externalFiniteBoxMixedIds_eq: [propext, Quot.sound]
selectedCell_region: [propext, Quot.sound]
selectedCell_unique: [propext, Quot.sound]
cell9_outside_box_is_gap: [propext, Quot.sound]
cell73_outside_box_is_gap: [propext, Quot.sound]
cellwise_conditional_formula_sound: [propext, Quot.sound]
```

No project-specific axioms were reported.

Optional summary reproduction:

```bash
python3 7863_reduced_q_rank_probe.py 4 --out /tmp/7863_reduced_q_rank_c4.main_audit.json
```

Result: pass. It reproduced the `c=4` finite-field q-rank summary:

```text
prime=1000003, seed=7863, mode=sparseL_denseQ
d=2: rows=200, cols=10, rank=10
d=3: rows=340, cols=32, rank=32
d=4: rows=525, cols=69, rank=69
```

This is not a strict certificate replay because it does not consume stored
pivot/minor/RREF witnesses.

Strict replay now added for the q-rank layer. Command pattern:

```bash
python3 7863_qrank_certificate_replay.py generate \
  --c C --d D \
  --out certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.json
python3 7863_qrank_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.json \
  --out certificates/7863_cell9_strict_replay/cC_dD_qrank_full_column_rank.replay.json
```

Result:

```text
21 / 21 q-rank replay outputs passed
c=4..10, d=2,3,4
each replay verifies matrix hash, basis hashes, stored pivot rows,
nonzero finite-field minor determinant, and full-column rank
```

Strict replay now added for the full reduced Koszul layer. Command pattern:

```bash
python3 7863_full_koszul_certificate_replay.py generate \
  --c C \
  --out certificates/7863_cell9_strict_replay/full_koszul_cC.json
python3 7863_full_koszul_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/full_koszul_cC.json \
  --out certificates/7863_cell9_strict_replay/full_koszul_cC.replay.json
```

Result:

```text
7 / 7 full-Koszul replay outputs passed
c=4..10
each replay verifies ten Koszul differential matrix hashes, exact ranks,
pivot-row hashes, zero compositions, homology tables, and Euler coefficients
```

Strict replay now added for the standalone M0/positive multiplication layer.
Command pattern:

```bash
python3 7863_mu_certificate_replay.py generate \
  --c C \
  --out certificates/7863_cell9_strict_replay/mu_cC.json
python3 7863_mu_certificate_replay.py replay \
  certificates/7863_cell9_strict_replay/mu_cC.json \
  --out certificates/7863_cell9_strict_replay/mu_cC.replay.json
```

Result:

```text
7 / 7 M0/positive replay outputs passed
c=4..10
each replay verifies M0-top and positive-multiplication matrix hashes, exact
ranks, pivot-row hashes, and commutativity squares
```

## Gate Results

| Gate | Status | Reason |
| --- | --- | --- |
| Two-agent gate | pass | Agent A extraction and Agent B audit artifacts exist for this strict replay run. |
| Cell partition gate | pass for the 9-by-9 ledger | Lean proves selected-cell coverage/uniqueness for the axis partition and the 81-cell ledger counts. |
| Cell status gate | incomplete | Cell 9 outside `b <= 10` and Cell 73 outside `b >= -10` remain explicit unresolved gaps. |
| Analytic formula gate | incomplete | PB/PT/D/B/Bdual mechanisms are not formalized as complete Lean theorem chains. |
| Finite-box certificate gate | incomplete | The q-rank, full reduced Koszul, M0-top, and positive-multiplication layers for Cell 9 `c=4..10` now have strict Python replay; propagation, characteristic-zero bridge, and formula bridge are still missing. |
| Certificate-to-formula soundness gate | incomplete | Lean does not prove the chain from replayed rank/kernel/cokernel statements to the printed CICY cohomology formula. |
| Characteristic-zero bridge | incomplete | A single finite-field specialization is not formalized as a characteristic-zero rank/formula theorem. |
| Global theorem gate | incomplete | The available theorem is conditional and permits unresolved mixed-cell gaps. |

## Accepted Lean Claims

- 81-cell selected-cell partition and ledger counts.
- Cell 9/73 `c = 4..10` numerator/Euler/table arithmetic consistency.
- Formal Cell 73 Serre-dual vector reversal.
- Explicit marker that current finite-field artifacts are not Lean-replayed
  certificates.
- Explicit gap theorems for Cell 9 outside the finite box and Cell 73 outside
  the dual finite box.
- Strict Python replay for all 21 Cell 9 q-rank full-column-rank entries
  `c=4..10,d=2,3,4` over `F_1000003`.
- Strict Python replay for all 7 Cell 9 full reduced Koszul homology entries
  `c=4..10` over `F_1000003`.
- Strict Python replay for all 7 Cell 9 standalone M0-top and
  positive-multiplication entries `c=4..10` over `F_1000003`.

## Rejected or Not Accepted

- JSON summaries as certificate replay.
- Manifest `replay_commands` as strict finite-box replay.
- The optional Python q-rank probe as certificate replay.
- The q-rank or full-Koszul replay layers alone as sufficient for the full Cell
  9 finite-box formula without the Lean soundness and characteristic-zero
  bridges.
- The conditional dispatch theorem as a paper-formula theorem.
- The paper central parity wall as Lean-formalized.
- Cell 9/73 outside the finite box as verified.
- The full CICY 7863 line-bundle formula as fully Lean-proved.

## Next Certificate Target

The first replayable finite-box target should be Cell 9, `c=4`, `d=2`:

```text
field: F_1000003
matrix: 200 x 10
target: full column rank 10
needed witness: pivot trace, nonzero 10 x 10 minor, LU/RREF, or equivalent
also needed: matrix recipe, row basis order, column basis order, Python checker,
and Lean theorem connecting the checked rank statement to the cell formula.
```
