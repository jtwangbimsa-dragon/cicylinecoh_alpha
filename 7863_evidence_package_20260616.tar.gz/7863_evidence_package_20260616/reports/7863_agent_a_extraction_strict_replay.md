# Agent A Extraction Artifact: CICY 7863 Strict Replay Gate

Protocol role: Agent A writer/extractor only. This artifact extracts the
current mathematical and computational scope for CICY 7863 under the strict
`cicy-lean-verification` finite-box replay gate. It does not approve
verification.

## Scope

CICY 7863 is the `P3 x P3` complete intersection with degrees:

```text
[[P3 | 2 1 1],
 [P3 | 2 1 1]]
```

Line bundles are `O_X(a,b)`.

The current Lean scope covers:

- the 9-by-9 Bott cell partition with ranges
  `<= -4, -3, -2, -1, 0, 1, 2, 3, >= 4`;
- the 81-cell ledger and label counts;
- Cell 9/73 reduced finite-box arithmetic for `c = 4..10`;
- numerator/Euler table consistency;
- formal Serre-dual reversal for Cell 73;
- a conditional dispatch theorem.

The paper includes the central parity wall `eq:7863-central-parity-wall`.
Current Lean does not prove that paper formula. The Lean files only check the
reduced endpoint/probe bookkeeping tables.

## Strict Cell Ledger

| Cells | Classification | Status |
| --- | --- | --- |
| PB/PT/B/Bdual | analytic-map | external_assumption |
| D cells | no-map | external_assumption |
| M except 9/73 | finite-box | external_assumption |
| Cell 9, `4 <= b <= 10` | finite-box | external_assumption |
| Cell 9, `b >= 11` | finite-box | unverified |
| Cell 73, `-10 <= b <= -4` | finite-box | external_assumption |
| Cell 73, `b <= -11` | finite-box | unverified |

## Existing Lean Theorems

Current meaningful Lean theorem names include:

```text
selectedCell_region
selectedCell_unique
axisRange_unique
cellEntries_length
count_PB / count_PT / count_D / count_M / count_B / count_Bdual
mCellIds_eq
boundaryCellIds_eq
partialFiniteBoxMixedIds_eq
externalFiniteBoxMixedIds_eq
boxLE10_arithmetic_consistent
qRankSummaries_count
qRankSummaries_all_internally_consistent
finiteFieldArtifacts_not_replayed
requiredRankReplayFields_count
replay_schema_accepts_requires_checker
cell73Formula_is_serreDual
serreDual_involutive
cell9_outside_box_is_gap
cell73_outside_box_is_gap
cellwise_conditional_formula_sound
```

These prove partition, bookkeeping, and table consistency only. They do not
prove the CICY cohomology formulas.

## Python Replay Status

The manifest commands using:

```bash
python3 7863_reduced_q_rank_probe.py ...
```

are summary/probe reproduction commands, not true certificate replay commands.
They regenerate JSON summaries containing ranks, homology tables,
commutativity checks, and Euler coefficients. They do not consume exported
pivot, minor, or RREF witnesses; they do not independently verify a stored
certificate; and they do not provide a Lean soundness bridge.

Therefore no mandatory Python finite-box certificate replay command currently
exists for Cell 9/73.

Optional summary-reproduction commands, which may be useful for audit but do
not satisfy the strict finite-box certificate gate, are:

```bash
python3 7863_reduced_q_rank_probe.py 4 5 6 7 --full-koszul --out /tmp/7863_reduced_full_koszul_c4_c7.audit.json
python3 7863_reduced_q_rank_probe.py 8 9 10 --out /tmp/7863_reduced_q_rank_c8_c10.audit.json
```

## Gate Result Extracted by Agent A

Finite-box gate: incomplete.

Missing items:

```text
typed matrix construction
basis order
rank witness / pivot / minor / RREF certificate
independent Python certificate replay
characteristic-zero bridge
Lean theorem from replayed certificate statement to formula
propagation beyond finite box
paper central parity wall proof
```

Global status extracted by Agent A: incomplete, not `fully_verified`.

## Minimal Agent B Audit Commands

From the Lean project:

```bash
cd "/Users/juntaowang/Documents/more cicy/line bundle formula/paper version/LeanProofs"
./lake-local build
```

From the workspace root:

```bash
rg -n "\b(sorry|admit|axiom|constant|opaque)\b" LeanProofs
```

Agent B should also run `#print axioms` on at least:

```text
PaperVersion.Section32.Case7863.boxLE10_arithmetic_consistent
PaperVersion.Section32.Case7863.CertificateAudit.finiteFieldArtifacts_not_replayed
PaperVersion.Section32.Case7863.CertificateAudit.qRankSummaries_all_internally_consistent
PaperVersion.Section32.Case7863.CellLedger.cell9_outside_box_is_gap
PaperVersion.Section32.Case7863.CellLedger.cell73_outside_box_is_gap
PaperVersion.Section32.Case7863.CellLedger.cellwise_conditional_formula_sound
```

Agent B must not count the optional Python summary commands as passing the
finite-box certificate replay gate.
