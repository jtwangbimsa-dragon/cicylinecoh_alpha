# CICY 7863 Evidence Package

This package collects the evidence needed for the CICY 7863 finite-box
Cell 9 / Cell 73 statements used in the current paper draft.

## Contents

- `paper/`
  - Current `paper_version.tex` and compiled `paper_version.pdf`.
  - The relevant theorem is the finite-box Cell 9 theorem in the 7863 case
    study, with proof material in Appendix `app:7863-technical`.

- `certificates/7863_cell9_strict_replay/`
  - Strict replay certificates for the Cell 9 endpoint quotient ranks,
    full reduced Koszul homology, and multiplication maps.
  - Includes `README.md` explaining the endpoint proof route and replay
    status.

- `certificates/7863_cell9_full_koszul_rank_minors/`
  - Full reduced Koszul rank-minor certificates for `b=4,...,10`.
  - These are the certificates used to rule out simultaneous middle
    corrections.

- `certificates/7863_cell9_left_injectivity_minors/`
  - Full-column-rank minors for the leftmost map
    `d_3 : C_3 -> C_2`, proving left injectivity on the certified open set.

- `certificates/7863_k3_characteristic_zero/`
  - Characteristic-zero witness package for the one-parameter `N_3` endpoint.

- `certificates/7863_cell9_reduced/` and
  `certificates/7863_cell9_box_lt10/`
  - Earlier reduced/finite-box manifests kept for provenance.

- `audits/`
  - Initial-ideal Hilbert checks through `s=50` over five finite fields.
  - `7863_reduced_qrank_quick_check.json` records the quick q-rank audit.

- `scripts/`
  - Replay and export scripts needed to regenerate/check the certificates.

- `reports/`
  - Human-readable status, strict replay, Lean-verification, and audit notes.

## Main Replay Commands

From the original paper workspace, examples:

```bash
python3 7863_qrank_certificate_replay.py replay certificates/7863_cell9_strict_replay/c4_d2_qrank_full_column_rank.json
python3 7863_full_koszul_certificate_replay.py replay certificates/7863_cell9_strict_replay/full_koszul_c4.json
python3 7863_left_injectivity_minor_export.py replay certificates/7863_cell9_left_injectivity_minors/left_injectivity_c4.json
python3 7863_initial_ideal_hilbert_check.py --prime 1000003 --max-s 50 --out /tmp/7863_initial_ideal_p1000003_s50.json
```

The current paper proof does not rely on finite sampling alone.  The endpoint
numerator/no-tail statement is derived analytically from the Buchsbaum--Rim/Bott
reduction and the nonzerodivisor condition on `Q` modulo `(L_1,L_2)`.  The
finite-field certificates are replayable audits and open-condition witnesses
for the stated finite box.
