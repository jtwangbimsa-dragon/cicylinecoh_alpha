#!/usr/bin/env python3
"""Replayable structured endpoint certificates for CICY 7883.

The black line is (r,b)=(3q,2q).  For q>=2 we normalize

    G = x0*y0 + x1*y1 + x2*y2

and work on the associated graded for the y3-adic filtration.  The G-block is
used first; the certificate stores only pivots for the induced F-map on the
G-quotient in the bottom layers e=0,1,2.  Layers e>=3 are handled by the
structural x0^2*y3^3 pivot of F, as explained in the README.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from functools import lru_cache
from pathlib import Path
from typing import Iterable


P = 32003
Exp = tuple[int, ...]
Col = dict[int, int]


@lru_cache(maxsize=None)
def monomials(nvars: int, degree: int) -> tuple[Exp, ...]:
    if degree < 0:
        return ()
    if nvars == 1:
        return ((degree,),)
    return tuple(
        (first,) + tail
        for first in range(degree + 1)
        for tail in monomials(nvars - 1, degree - first)
    )


def add_exp(a: Exp, b: Exp) -> Exp:
    return tuple(x + y for x, y in zip(a, b))


def sub_exp(a: Exp, b: Exp) -> Exp | None:
    c = tuple(x - y for x, y in zip(a, b))
    return None if any(x < 0 for x in c) else c


def coeff(label: str, *parts: object, p: int = P) -> int:
    raw = (label + ":" + ":".join(map(str, parts))).encode()
    value = int(hashlib.sha256(raw).hexdigest()[:16], 16) % p
    return value or 1


def reduce_by_basis(col: Col, basis: dict[int, Col], p: int = P) -> Col:
    col = dict(col)
    while col:
        pivot = max(col)
        old = basis.get(pivot)
        if old is None:
            return col
        factor = col[pivot]
        for row, value in old.items():
            new_value = (col.get(row, 0) - factor * value) % p
            if new_value:
                col[row] = new_value
            elif row in col:
                del col[row]
    return col


def add_to_basis_search(col: Col, basis: dict[int, Col], p: int = P) -> tuple[bool, int, int, int]:
    col = reduce_by_basis(col, basis, p)
    if not col:
        return False, -1, 0, 0
    pivot = max(col)
    pivot_value = col[pivot] % p
    inv = pow(pivot_value, -1, p)
    normalized = {row: (value * inv) % p for row, value in col.items()}
    normalized = {row: value for row, value in normalized.items() if value}
    basis[pivot] = normalized
    return True, pivot, pivot_value, len(normalized)


def add_to_basis_replay(col: Col, basis: dict[int, Col], expected_pivot: int, p: int = P) -> tuple[int, int]:
    col = reduce_by_basis(col, basis, p)
    if not col:
        raise ValueError(f"stored pivot {expected_pivot} got zero residual")
    actual = max(col)
    if actual != expected_pivot:
        raise ValueError(f"stored pivot mismatch: expected {expected_pivot}, got {actual}")
    pivot_value = col[expected_pivot] % p
    if pivot_value == 0:
        raise ValueError(f"stored pivot {expected_pivot} has zero value")
    inv = pow(pivot_value, -1, p)
    normalized = {row: (value * inv) % p for row, value in col.items()}
    normalized = {row: value for row, value in normalized.items() if value}
    basis[expected_pivot] = normalized
    return pivot_value, len(normalized)


def target_basis(q: int, e: int) -> tuple[list[tuple[Exp, Exp]], dict[tuple[Exp, Exp], int]]:
    r = 3 * q
    b = 2 * q
    m = r - 3
    n = b - e
    target = [(x, u) for x in monomials(3, m) for u in monomials(3, n)]
    return target, {xu: idx for idx, xu in enumerate(target)}


def g_columns(m: int, n: int, target_index: dict[tuple[Exp, Exp], int]) -> Iterable[Col]:
    units = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    if n <= 0:
        return
    for sx in monomials(3, m + 1):
        for su in monomials(3, n - 1):
            col: Col = {}
            for unit in units:
                tx = sub_exp(sx, unit)
                if tx is None:
                    continue
                tu = add_exp(su, unit)
                row = target_index.get((tx, tu))
                if row is not None:
                    col[row] = (col.get(row, 0) + 1) % P
            if col:
                yield col


def build_g_basis(q: int, e: int) -> tuple[int, dict[int, Col], int]:
    r = 3 * q
    b = 2 * q
    m = r - 3
    n = b - e
    target, target_index = target_basis(q, e)
    basis: dict[int, Col] = {}
    max_fill = 0
    for col in g_columns(m, n, target_index):
        ok, _pivot, _value, fill = add_to_basis_search(col, basis)
        if ok:
            max_fill = max(max_fill, fill)
    return len(target), basis, max_fill


@lru_cache(maxsize=None)
def f_terms(seed: int) -> tuple[tuple[int, Exp, Exp, int], ...]:
    terms: list[tuple[int, Exp, Exp, int]] = []
    for x in monomials(3, 2):
        for y3 in range(4):
            for u in monomials(3, 3 - y3):
                terms.append((coeff("7883-F", seed, x, u, y3), x, u, y3))
    return tuple(terms)


def f_term_digest(seed: int) -> str:
    payload = json.dumps(f_terms(seed), separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def f_column_count(q: int, e: int) -> int:
    r = 3 * q
    b = 2 * q
    m = r - 3
    n = b - e
    x_count = len(monomials(3, m + 2))
    total = 0
    for c in range(e + 1):
        ud = n - 3 + c
        if ud >= 0:
            total += x_count * len(monomials(3, ud))
    return total


def f_column_spec(q: int, e: int, column_index: int) -> tuple[int, Exp, Exp]:
    r = 3 * q
    b = 2 * q
    m = r - 3
    n = b - e
    x_sources = monomials(3, m + 2)
    remaining = column_index
    for c in range(e + 1):
        ud = n - 3 + c
        if ud < 0:
            continue
        u_sources = monomials(3, ud)
        block = len(x_sources) * len(u_sources)
        if remaining < block:
            sx = x_sources[remaining // len(u_sources)]
            su = u_sources[remaining % len(u_sources)]
            return c, sx, su
        remaining -= block
    raise IndexError(column_index)


def build_f_column(q: int, e: int, column_index: int, target_index: dict[tuple[Exp, Exp], int], seed: int) -> Col:
    c, sx, su = f_column_spec(q, e, column_index)
    col: Col = {}
    for value, x, u, y3 in f_terms(seed):
        if y3 != c:
            continue
        tx = sub_exp(sx, x)
        if tx is None:
            continue
        tu = add_exp(su, u)
        row = target_index.get((tx, tu))
        if row is not None:
            new_value = (col.get(row, 0) + value) % P
            if new_value:
                col[row] = new_value
            elif row in col:
                del col[row]
    return col


def normal_form(row: int, g_basis: dict[int, Col], cache: dict[int, Col]) -> Col:
    got = cache.get(row)
    if got is not None:
        return got
    got = reduce_by_basis({row: 1}, g_basis)
    cache[row] = got
    return got


def quotient_f_column(raw_col: Col, g_basis: dict[int, Col], nf_cache: dict[int, Col]) -> Col:
    residual: Col = {}
    for row, value in raw_col.items():
        nf = normal_form(row, g_basis, nf_cache)
        for qrow, qvalue in nf.items():
            new_value = (residual.get(qrow, 0) + value * qvalue) % P
            if new_value:
                residual[qrow] = new_value
            elif qrow in residual:
                del residual[qrow]
    return residual


def generate_layer(q: int, e: int, out_dir: Path, seed: int) -> dict[str, object]:
    start = time.time()
    target, target_index = target_basis(q, e)
    target_dim, g_basis, g_fill = build_g_basis(q, e)
    assert target_dim == len(target)
    quotient_dim = target_dim - len(g_basis)

    nf_cache: dict[int, Col] = {}
    f_basis: dict[int, Col] = {}
    pivot_columns: list[int] = []
    pivot_rows: list[int] = []
    pivot_product = 1
    f_total = f_column_count(q, e)
    max_fill = 0
    columns_seen = 0
    for col_idx in range(f_total):
        raw = build_f_column(q, e, col_idx, target_index, seed)
        residual = quotient_f_column(raw, g_basis, nf_cache)
        if not residual:
            continue
        columns_seen += 1
        ok, pivot, pivot_value, fill = add_to_basis_search(residual, f_basis)
        if ok:
            pivot_columns.append(col_idx)
            pivot_rows.append(pivot)
            pivot_product = (pivot_product * pivot_value) % P
            max_fill = max(max_fill, fill)
            if len(f_basis) == quotient_dim:
                break

    ok = len(f_basis) == quotient_dim
    cert = {
        "kind": "cicy-7883-right-endpoint-bottom-layer",
        "prime": P,
        "seed": seed,
        "f_terms_sha256": f_term_digest(seed),
        "normal_form": "G=x0*y0+x1*y1+x2*y2",
        "monomial_order": "recursive lex order used by monomials(nvars,degree); row pivot is max row index",
        "q": q,
        "e": e,
        "r": 3 * q,
        "b": 2 * q,
        "target_dim": target_dim,
        "g_rank": len(g_basis),
        "g_quotient_dim": quotient_dim,
        "g_max_fill": g_fill,
        "f_total_columns": f_total,
        "f_columns_seen_until_certificate": columns_seen,
        "f_rank_on_g_quotient": len(f_basis),
        "remaining_coker": quotient_dim - len(f_basis),
        "f_max_fill": max_fill,
        "pivot_columns": pivot_columns,
        "pivot_rows": pivot_rows,
        "pivot_product_mod_prime": pivot_product,
        "ok": ok,
        "seconds": round(time.time() - start, 3),
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"q{q:02d}_e{e}.json"
    path.write_text(json.dumps(cert, separators=(",", ":")) + "\n")
    return cert


def verify_layer(path: Path) -> dict[str, object]:
    cert = json.loads(path.read_text())
    if cert.get("kind") == "cicy-7883-q1-boundary":
        return verify_boundary_q1(path, cert)

    q = int(cert["q"])
    e = int(cert["e"])
    seed = int(cert["seed"])
    if int(cert["prime"]) != P:
        raise ValueError("wrong prime")
    if cert["f_terms_sha256"] != f_term_digest(seed):
        raise ValueError("F term digest mismatch")

    target, target_index = target_basis(q, e)
    target_dim, g_basis, _g_fill = build_g_basis(q, e)
    quotient_dim = target_dim - len(g_basis)
    if target_dim != cert["target_dim"] or len(g_basis) != cert["g_rank"]:
        raise ValueError("G dimensions/rank mismatch")
    if quotient_dim != cert["g_quotient_dim"]:
        raise ValueError("quotient dimension mismatch")

    nf_cache: dict[int, Col] = {}
    f_basis: dict[int, Col] = {}
    pivot_product = 1
    max_fill = 0
    pivot_columns = list(map(int, cert["pivot_columns"]))
    pivot_rows = list(map(int, cert["pivot_rows"]))
    if len(pivot_columns) != len(pivot_rows):
        raise ValueError("pivot column/row length mismatch")
    for col_idx, pivot_row in zip(pivot_columns, pivot_rows):
        raw = build_f_column(q, e, col_idx, target_index, seed)
        residual = quotient_f_column(raw, g_basis, nf_cache)
        pivot_value, fill = add_to_basis_replay(residual, f_basis, pivot_row)
        pivot_product = (pivot_product * pivot_value) % P
        max_fill = max(max_fill, fill)

    ok = (
        len(f_basis) == quotient_dim
        and pivot_product == int(cert["pivot_product_mod_prime"])
        and quotient_dim - len(f_basis) == int(cert["remaining_coker"])
    )
    return {
        "path": str(path),
        "q": q,
        "e": e,
        "target_dim": target_dim,
        "g_rank": len(g_basis),
        "g_quotient_dim": quotient_dim,
        "f_rank_on_g_quotient": len(f_basis),
        "remaining_coker": quotient_dim - len(f_basis),
        "pivot_product_mod_prime": pivot_product,
        "max_fill": max_fill,
        "ok": ok,
    }


def verify_boundary_q1(path: Path, cert: dict[str, object] | None = None) -> dict[str, object]:
    if cert is None:
        cert = json.loads(path.read_text())
    if cert.get("kind") != "cicy-7883-q1-boundary":
        raise ValueError("wrong boundary certificate kind")
    if int(cert["prime"]) != P:
        raise ValueError("wrong prime")
    if int(cert["q"]) != 1 or int(cert["r"]) != 3 or int(cert["b"]) != 2:
        raise ValueError("wrong q=1 boundary parameters")
    if cert.get("normal_form") != "G=x0*y0+x1*y1+x2*y2":
        raise ValueError("wrong G normal form")

    target = monomials(4, 2)
    target_index = {m: idx for idx, m in enumerate(target)}
    basis: dict[int, Col] = {}
    for i in range(3):
        y_i = [0, 0, 0, 0]
        y_i[i] = 1
        for y_linear in monomials(4, 1):
            monomial = tuple(y_i[j] + y_linear[j] for j in range(4))
            add_to_basis_search({target_index[monomial]: 1}, basis)

    quotient_generator = tuple(cert["quotient_generator"]["y"])  # type: ignore[index]
    if quotient_generator != (0, 0, 0, 2):
        raise ValueError("wrong quotient generator")
    quotient_row = target_index[quotient_generator]
    if reduce_by_basis({quotient_row: 1}, basis) == {}:
        raise ValueError("stored quotient generator lies in the G-image")

    rank = len(basis)
    coker = len(target) - rank
    ok = (
        int(cert["target_dim"]) == len(target)
        and int(cert["g_rank"]) == rank
        and int(cert["right_coker"]) == coker
        and coker == 1
    )
    return {
        "path": str(path),
        "q": 1,
        "r": 3,
        "b": 2,
        "target_dim": len(target),
        "g_rank": rank,
        "right_coker": coker,
        "quotient_generator": {"x": [0, 0, 0], "y": list(quotient_generator)},
        "ok": ok,
    }


def boundary_q1(out_dir: Path) -> dict[str, object]:
    # Target S_2 has 10 monomials.  The normalized G-image is
    # (y0,y1,y2)S_1, of rank 9; the quotient is generated by y3^2.
    cert = {
        "kind": "cicy-7883-q1-boundary",
        "prime": P,
        "q": 1,
        "r": 3,
        "b": 2,
        "target_dim": 10,
        "g_rank": 9,
        "right_coker": 1,
        "quotient_generator": {"x": [0, 0, 0], "y": [0, 0, 0, 2]},
        "normal_form": "G=x0*y0+x1*y1+x2*y2",
        "ok": True,
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "q01-boundary.json").write_text(json.dumps(cert, indent=2) + "\n")
    return cert


def write_manifest(root: Path, q_max: int, seed: int, records: list[dict[str, object]]) -> None:
    manifest = {
        "package": "cicy-7883-right-endpoint-structured-certificates",
        "prime": P,
        "seed": seed,
        "scope": f"q=1 boundary and q=2..{q_max}, e=0,1,2 bottom layers",
        "meaning": (
            "For q>=2, G is normalized to x0*y0+x1*y1+x2*y2. "
            "The certificate replays F-pivots on the G-quotient in bottom "
            "layers e=0,1,2; layers e>=3 are handled by the structural "
            "x0^2*y3^3 pivot."
        ),
        "records": records,
    }
    (root / "right-endpoint" / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--generate", action="store_true")
    parser.add_argument("--verify", type=Path)
    parser.add_argument("--verify-all", action="store_true")
    parser.add_argument("--q-max", type=int, default=8)
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()

    cert_dir = args.root / "right-endpoint" / "quotient-pivots"
    if args.generate:
        records: list[dict[str, object]] = []
        records.append(boundary_q1(args.root / "right-endpoint"))
        for q in range(2, args.q_max + 1):
            for e in range(3):
                rec = generate_layer(q, e, cert_dir, args.seed)
                records.append({k: rec[k] for k in ("q", "e", "r", "b", "target_dim", "g_rank", "g_quotient_dim", "f_rank_on_g_quotient", "remaining_coker", "ok", "seconds")})
                print(json.dumps(records[-1], indent=2), flush=True)
        write_manifest(args.root, args.q_max, args.seed, records)
    elif args.verify is not None:
        print(json.dumps(verify_layer(args.verify), indent=2))
    elif args.verify_all:
        paths = [args.root / "right-endpoint" / "q01-boundary.json"]
        paths.extend(sorted(cert_dir.glob("q*_e*.json")))
        results = [verify_layer(path) for path in paths]
        print(json.dumps({"checked": len(results), "ok": all(r["ok"] for r in results), "results": results}, indent=2))
    else:
        parser.error("use --generate, --verify PATH, or --verify-all")


if __name__ == "__main__":
    main()
