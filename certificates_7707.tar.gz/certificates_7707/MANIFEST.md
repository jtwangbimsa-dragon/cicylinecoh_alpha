# CICY 7707 certificate manifest

| Paper range | Result type | Core certificate files | What the certificate proves |
|---|---|---|---|
| `k=(-a,-b,3)`, `2<=a<=10` or `2<=b<=10`; dual `k=(a,b,-3)` | finite-width infinite strip | `core/cell6_strip/7707_cell6_strip_certificate.json`, `core/cell6_strip/7707_cell6_strip_certificate.md`, `core/cell6_strip/7707_cell6_strip_certificate.sing`, `core/cell6_strip/7707_cell6_strip_certificate.singular.out` | One-variable Hilbert numerators for the vertical and horizontal strips; chamber degrees `>=2` match the printed formula. |
| `k=(0,-b,c)`, `2<=b<=10`, `c>=4`; dual `k=(0,b,-c)` | finite `b`-box with arbitrary `c` | `core/cell77_99_arbitrary_c/7707_cell77_99_c_arbitrary_certificate.json`, `core/cell77_99_arbitrary_c/7707_cell77_99_c_arbitrary_certificate.md` | Singular Hilbert numerators for `coker Phi_b`, recurrence for residual tails, and direct finite-field rank checks. |
| `k=(-a,-b,c)`, `2<=a,b<=10`, `c>=4`; dual `k=(a,b,-c)` | finite `(a,b)`-box with arbitrary `c` | `core/cell7_169_endpoints/7707_cell7_169_c_arbitrary_endpoints.json`, `core/cell7_169_endpoints/7707_cell7_169_c_arbitrary_endpoints.md`, `core/cell7_169_endpoints/7707_cell7_169_q2_singular_certs.json`, `core/cell7_169_endpoints/7707_cell7_169_q2_singular_certs.md`, `core/cell7_169_endpoints/7707_cell7_169_q2_singular_certs/` | q0 endpoint is the shifted residual tail from cell 77; q2 endpoint has 81 Singular Hilbert numerator certificates, one for each `2<=a,b<=10`. |
| `k=(-a,-b,m)`, `m=1,2`; dual `k=(a,b,-m)` | analytic splitting range | `auxiliary/cell5_splitting/7707_cell5_splitting_certificate.json`, `auxiliary/cell5_splitting/7707_cell5_splitting_certificate.md` | Finite-field full-rank/minor checks proving the required open splitting conditions. |
| cells `5/6/170/171` and `7/169` | auxiliary sample verification | `auxiliary/sample_checks/7707_cells5_6_170_171_100sample_check.json`, `auxiliary/sample_checks/7707_cells7_169_100sample_check.json`, `auxiliary/sample_checks/7707_cells7_169_100sample_check.md` | Formula-vs-rank checks: 100 samples for each listed cell package, all matching. |

## Included scripts

The `scripts/` directory contains:

- `7707_unresolved_box10_rank.py`
- `7707_cell5_splitting_certificate.py`
- `7707_cell6_strip_certificate.py`
- `7707_cell77_99_c_arbitrary_certificate.py`
- `7707_cell7_169_c_arbitrary_endpoints.py`
- `7707_cell7_169_q2_singular_certificates.py`
- `7707_cells5_6_170_171_100sample_check.py`
- `7707_cells7_169_100sample_check.py`

