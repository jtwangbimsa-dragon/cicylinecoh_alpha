# CICY 7707 Cell 6 finite-width strip certificate

- seed: `7707`
- prime: `1000003`
- all chamber Hilbert numerators match for degree >= 2: `True`
- full graded-module match including non-chamber degrees 0 and 1: `False`

The theorem only uses chamber degrees >= 2.  The full graded module
contains lower-degree pieces outside the Bott chamber convention, so
the full-series flag is recorded only as a diagnostic.

| strip | target | source | weights | regularity | chamber | shift | coeffs |
|---|---:|---:|---|---:|---|---:|---|
| vertical_a02 | 22 | 20 | {'0': 20, '2': 2} | 12 | True | 0 | `[20, 0, -18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]` |
| vertical_a03 | 33 | 40 | {'0': 30, '2': 3} | 7 | True | 0 | `[30, 0, -37, 0, 0, 0, 0, 0, 2, 6]` |
| vertical_a04 | 44 | 60 | {'0': 40, '2': 4} | 5 | True | 0 | `[40, 0, -56, 0, 0, 0, 0, 16]` |
| vertical_a05 | 55 | 80 | {'0': 50, '2': 5} | 4 | True | 0 | `[50, 0, -75, 0, 0, 0, 25]` |
| vertical_a06 | 66 | 100 | {'0': 60, '2': 6} | 4 | True | 0 | `[60, 0, -94, 0, 0, 16, 18]` |
| vertical_a07 | 77 | 120 | {'0': 70, '2': 7} | 4 | True | 0 | `[70, 0, -113, 0, 0, 32, 11]` |
| vertical_a08 | 88 | 140 | {'0': 80, '2': 8} | 4 | True | 0 | `[80, 0, -132, 0, 0, 48, 4]` |
| vertical_a09 | 99 | 160 | {'0': 90, '2': 9} | 3 | True | 0 | `[90, 0, -151, 0, 3, 58]` |
| vertical_a10 | 110 | 180 | {'0': 100, '2': 10} | 3 | True | 0 | `[100, 0, -170, 0, 10, 60]` |
| horizontal_b02 | 31 | 20 | {'1': 31} | 1 | True | 1 | `[31, -20]` |
| horizontal_b03 | 42 | 40 | {'1': 42} | 15 | True | 1 | `[42, -40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]` |
| horizontal_b04 | 53 | 60 | {'1': 53} | 8 | True | 1 | `[53, -60, 0, 0, 0, 0, 0, 0, 3, 4]` |
| horizontal_b05 | 64 | 80 | {'1': 64} | 4 | True | 1 | `[64, -80, 0, 0, 0, 16]` |
| horizontal_b06 | 75 | 100 | {'1': 75} | 3 | True | 1 | `[75, -100, 0, 0, 25]` |
| horizontal_b07 | 86 | 120 | {'1': 86} | 3 | True | 1 | `[86, -120, 0, 16, 18]` |
| horizontal_b08 | 97 | 140 | {'1': 97} | 3 | True | 1 | `[97, -140, 2, 28, 13]` |
| horizontal_b09 | 108 | 160 | {'1': 108} | 3 | True | 1 | `[108, -160, 10, 28, 14]` |
| horizontal_b10 | 119 | 180 | {'1': 119} | 3 | True | 1 | `[119, -180, 18, 28, 15]` |

The JSON file records the predicted splitting type for each strip.
The generated Singular file is `7707_cell6_strip_certificate.sing`.
