# CICY 7707 Cells 77/99 arbitrary-c certificate

- prime: `1000003`
- seed: `7707`
- Singular numerator checks: `True`
- recurrence checks for residual tails b=4..10: `True`
- direct rank checks: `99` matches, `0` mismatches

For Cell 77, set
\[\gamma_b(c)=[t^c]\frac{N_b(t)}{(1-t)^4},\qquad
\kappa_b(c)=\gamma_b(c)+(b+1)P_3(c-4)-(b-1)P_3(c).\]
Then
\[h^\bullet(0,-b,c)=(\kappa_b(c),\gamma_b(c),0,0),\]
and Cell 99 is the Serre dual
\[h^\bullet(0,b,-c)=(0,0,\gamma_b(c),\kappa_b(c)).\]

| b | N_b(t) |
|---:|---|
| 2 | `$1 - 3t^{4} + t^{6} + 3t^{8} - 2t^{9}` |
| 3 | `$2 - 4t^{4} + 2t^{10} + 4t^{12} - 4t^{13}` |
| 4 | `$3 - 5t^{4} + t^{12} + 3t^{14} - 2t^{15} + 5t^{16} - 6t^{17} + t^{18}` |
| 5 | `$4 - 6t^{4} + 2t^{16} + 4t^{18} - 4t^{19} + 6t^{20} - 8t^{21} + 2t^{22}` |
| 6 | `$5 - 7t^{4} + t^{18} + 3t^{20} - 2t^{21} + 5t^{22} - 6t^{23} + 8t^{24} - 10t^{25} + 3t^{26}` |
| 7 | `$6 - 8t^{4} + 2t^{22} + 4t^{24} - 4t^{25} + 6t^{26} - 8t^{27} + 10t^{28} - 12t^{29} + 4t^{30}` |
| 8 | `$7 - 9t^{4} + t^{24} + 3t^{26} - 2t^{27} + 5t^{28} - 6t^{29} + 8t^{30} - 10t^{31} + 12t^{32} - 14t^{33} + 5t^{34}` |
| 9 | `$8 - 10t^{4} + 2t^{28} + 4t^{30} - 4t^{31} + 6t^{32} - 8t^{33} + 10t^{34} - 12t^{35} + 14t^{36} - 16t^{37} + 6t^{38}` |
| 10 | `$9 - 11t^{4} + t^{30} + 3t^{32} - 2t^{33} + 5t^{34} - 6t^{35} + 8t^{36} - 10t^{37} + 12t^{38} - 14t^{39} + 16t^{40} - 18t^{41} + 7t^{42}` |

The residual tails satisfy
\[R_b=t^6R_{b-2}+t^{4b}\bigl((b+1)-(2b-2)t+(b-3)t^2\bigr),\quad b=4,\ldots,10.\]
