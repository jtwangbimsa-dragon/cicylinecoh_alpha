#!/usr/bin/env python3
"""Finite-field rank verifier for the unresolved CICY 7707 cells.

The script builds the finite complexes appearing in Cells 5, 6, 7, 77 and
uses Calabi-Yau Serre duality for Cells 99, 169, 170, 171.  It is meant as a
box-10 numerical certificate generator: the same random specialization is used
for all cells, and ranks are computed over a large prime field.
"""

from __future__ import annotations

from dataclasses import dataclass
import argparse
import json
import random
from itertools import product
import numpy as np

try:
    from numba import njit
except Exception:  # pragma: no cover - optional speed path
    njit = None


P = 1_000_003
DENSE_ENTRY_LIMIT = 100_000_000


def monomials(nvars: int, deg: int) -> list[tuple[int, ...]]:
    if deg < 0:
        return []
    if nvars == 1:
        return [(deg,)]
    out: list[tuple[int, ...]] = []
    for i in range(deg + 1):
        for tail in monomials(nvars - 1, deg - i):
            out.append((i,) + tail)
    return out


def add_tuple(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(x + y for x, y in zip(a, b))


def sub_tuple(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...] | None:
    c = tuple(x - y for x, y in zip(a, b))
    if any(x < 0 for x in c):
        return None
    return c


def u_basis(xdeg: int, ydeg: int) -> list[tuple[tuple[int, int], tuple[int, int]]]:
    return [(x, y) for x in monomials(2, xdeg) for y in monomials(2, ydeg)]


def w_basis(zdeg: int) -> list[tuple[int, int, int, int]]:
    return monomials(4, zdeg)


def tensor_basis(
    zdeg: int, xdeg: int, ydeg: int
) -> list[tuple[tuple[int, int, int, int], tuple[int, int], tuple[int, int]]]:
    return [(z, x, y) for z in w_basis(zdeg) for x, y in u_basis(xdeg, ydeg)]


@dataclass(frozen=True)
class Term:
    coeff: int
    z: tuple[int, int, int, int]
    x: tuple[int, int]
    y: tuple[int, int]


@dataclass
class SparseMap:
    nrows: int
    ncols: int
    cols: list[dict[int, int]]


def random_terms(
    rng: random.Random, zdeg: int, xdeg: int, ydeg: int
) -> list[Term]:
    return [
        Term(rng.randrange(1, P), z, x, y)
        for z in w_basis(zdeg)
        for x, y in u_basis(xdeg, ydeg)
    ]


def build_fg(seed: int) -> tuple[list[Term], list[Term]]:
    rng = random.Random(seed)
    f_terms = random_terms(rng, zdeg=3, xdeg=1, ydeg=0)
    g_terms = random_terms(rng, zdeg=1, xdeg=1, ydeg=2)
    return f_terms, g_terms


def contraction_sparse(
    source: list[tuple[tuple[int, int, int, int], tuple[int, int], tuple[int, int]]],
    target: list[tuple[tuple[int, int, int, int], tuple[int, int], tuple[int, int]]],
    terms: list[Term],
) -> SparseMap:
    target_index = {b: i for i, b in enumerate(target)}
    cols: list[dict[int, int]] = []
    for z_src, x_src, y_src in source:
        col: dict[int, int] = {}
        for term in terms:
            z_tgt = sub_tuple(z_src, term.z)
            if z_tgt is None:
                continue
            x_tgt = add_tuple(x_src, term.x)
            y_tgt = add_tuple(y_src, term.y)
            i = target_index.get((z_tgt, x_tgt, y_tgt))
            if i is not None:
                col[i] = (col.get(i, 0) + term.coeff) % P
        cols.append({i: v for i, v in col.items() if v % P})
    return SparseMap(len(target), len(source), cols)


def block_v(mats: list[SparseMap]) -> SparseMap:
    if not mats:
        return SparseMap(0, 0, [])
    ncols = mats[0].ncols
    out_cols = [dict() for _ in range(ncols)]
    row_offset = 0
    for mat in mats:
        if mat.ncols != ncols:
            raise ValueError("vertical block column mismatch")
        for j, col in enumerate(mat.cols):
            for i, val in col.items():
                out_cols[j][row_offset + i] = val
        row_offset += mat.nrows
    return SparseMap(row_offset, ncols, out_cols)


def block_h(mats: list[SparseMap]) -> SparseMap:
    rows = mats[0].nrows if mats else 0
    out_cols: list[dict[int, int]] = []
    for mat in mats:
        if mat.nrows != rows:
            raise ValueError("horizontal block row mismatch")
        out_cols.extend(mat.cols)
    return SparseMap(rows, len(out_cols), out_cols)


def scalar_mul(mat: SparseMap, scalar: int) -> SparseMap:
    return SparseMap(
        mat.nrows,
        mat.ncols,
        [{i: (scalar * x) % P for i, x in col.items()} for col in mat.cols],
    )


def rank_sparse(mat: SparseMap, p: int = P) -> int:
    basis: dict[int, dict[int, int]] = {}
    for original in mat.cols:
        col = original.copy()
        while col:
            pivot = min(col)
            coeff = col[pivot] % p
            if coeff == 0:
                del col[pivot]
                continue
            if pivot not in basis:
                inv = pow(coeff, p - 2, p)
                basis[pivot] = {i: (v * inv) % p for i, v in col.items() if v % p}
                break
            factor = coeff
            brow = basis[pivot]
            for i, v in brow.items():
                nv = (col.get(i, 0) - factor * v) % p
                if nv:
                    col[i] = nv
                elif i in col:
                    del col[i]
    return len(basis)


def rank_dense_numpy(mat: SparseMap, p: int = P) -> int:
    a = np.zeros((mat.nrows, mat.ncols), dtype=np.int64)
    for j, col in enumerate(mat.cols):
        for i, val in col.items():
            a[i, j] = val
    if njit is not None:
        return int(_rank_forward_numba(a, p))
    return rank_forward_numpy(a, p)


def rank_forward_numpy(a: np.ndarray, p: int = P) -> int:
    nrows, ncols = a.shape
    rank = 0
    for col in range(ncols):
        nz = np.flatnonzero(a[rank:, col] % p)
        if nz.size == 0:
            continue
        pivot = rank + int(nz[0])
        if pivot != rank:
            a[[rank, pivot], col:] = a[[pivot, rank], col:]
        inv = pow(int(a[rank, col] % p), p - 2, p)
        a[rank, col:] = (a[rank, col:] * inv) % p
        rows = np.flatnonzero(a[rank + 1 :, col] % p) + rank + 1
        if rows.size:
            factors = a[rows, col].copy() % p
            a[rows, col:] = (a[rows, col:] - factors[:, None] * a[rank, col:]) % p
        rank += 1
        if rank == nrows:
            break
    return rank


if njit is not None:
    @njit
    def _mod_pow_numba(a: int, e: int, p: int) -> int:
        res = 1
        a %= p
        while e > 0:
            if e & 1:
                res = (res * a) % p
            a = (a * a) % p
            e //= 2
        return res


    @njit
    def _rank_forward_numba(a: np.ndarray, p: int) -> int:
        nrows, ncols = a.shape
        rank = 0
        for col in range(ncols):
            pivot = -1
            for i in range(rank, nrows):
                if a[i, col] % p != 0:
                    pivot = i
                    break
            if pivot < 0:
                continue
            if pivot != rank:
                for j in range(col, ncols):
                    tmp = a[rank, j]
                    a[rank, j] = a[pivot, j]
                    a[pivot, j] = tmp
            inv = _mod_pow_numba(int(a[rank, col]), p - 2, p)
            for j in range(col, ncols):
                a[rank, j] = (a[rank, j] * inv) % p
            for i in range(rank + 1, nrows):
                factor = a[i, col] % p
                if factor != 0:
                    for j in range(col, ncols):
                        a[i, j] = (a[i, j] - factor * a[rank, j]) % p
            rank += 1
            if rank == nrows:
                break
        return rank


def rank_auto(mat: SparseMap) -> int:
    entries = mat.nrows * mat.ncols
    if entries <= DENSE_ENTRY_LIMIT:
        return rank_dense_numpy(mat)
    return rank_sparse(mat)


def apply_sparse(mat: SparseMap, vec: dict[int, int], p: int = P) -> dict[int, int]:
    out: dict[int, int] = {}
    for j, coeff in vec.items():
        for i, val in mat.cols[j].items():
            out[i] = (out.get(i, 0) + coeff * val) % p
    return {i: v for i, v in out.items() if v}


def composition_nonzero_columns(a: SparseMap, b: SparseMap, limit: int | None = None) -> int:
    count = 0
    cols = b.cols if limit is None else b.cols[:limit]
    for col in cols:
        if apply_sparse(a, col):
            count += 1
    return count


def cell5(a: int, b: int, m: int, g_terms: list[Term]) -> dict:
    left = tensor_basis(m, a - 2, b - 2)
    right = tensor_basis(m - 1, a - 1, b)
    d = contraction_sparse(left, right, g_terms)
    r = rank_auto(d)
    return {
        "cell": 5,
        "params": {"a": a, "b": b, "m": m},
        "dims": [len(left), len(right)],
        "ranks": [r],
        "h": [0, len(right) - r, len(left) - r, 0],
    }


def cell6(a: int, b: int, f_terms: list[Term], g_terms: list[Term]) -> dict:
    left = tensor_basis(3, a - 2, b - 2)
    t_f = tensor_basis(0, a - 1, b - 2)
    t_g = tensor_basis(2, a - 1, b)
    d = block_v([
        contraction_sparse(left, t_f, f_terms),
        contraction_sparse(left, t_g, g_terms),
    ])
    r = rank_auto(d)
    return {
        "cell": 6,
        "params": {"a": a, "b": b},
        "dims": [len(left), len(t_f) + len(t_g)],
        "ranks": [r],
        "h": [0, len(t_f) + len(t_g) - r, len(left) - r, 0],
    }


def cell7(
    a: int,
    b: int,
    c: int,
    f_terms: list[Term],
    g_terms: list[Term],
    check_composition: bool = False,
) -> dict:
    left = tensor_basis(c, a - 2, b - 2)
    mid_f = tensor_basis(c - 3, a - 1, b - 2)
    mid_g = tensor_basis(c - 1, a - 1, b)
    right = tensor_basis(c - 4, a, b)

    d0 = block_v([
        contraction_sparse(left, mid_f, f_terms),
        contraction_sparse(left, mid_g, g_terms),
    ])
    d1 = block_h([
        contraction_sparse(mid_f, right, g_terms),
        scalar_mul(contraction_sparse(mid_g, right, f_terms), -1),
    ])
    comp_bad = composition_nonzero_columns(d1, d0) if check_composition else 0
    r0 = rank_auto(d0)
    r1 = rank_auto(d1)
    h2 = len(left) - r0
    h1 = len(mid_f) + len(mid_g) - r1 - r0
    h0 = len(right) - r1
    return {
        "cell": 7,
        "params": {"a": a, "b": b, "c": c},
        "dims": [len(left), len(mid_f) + len(mid_g), len(right)],
        "ranks": [r0, r1],
        "composition_nonzero_columns": comp_bad,
        "h": [h0, h1, h2, 0],
    }


def multiply_z_forms(
    p1: dict[tuple[int, int, int, int], int],
    p2: dict[tuple[int, int, int, int], int],
) -> dict[tuple[int, int, int, int], int]:
    out: dict[tuple[int, int, int, int], int] = {}
    for z1, c1 in p1.items():
        for z2, c2 in p2.items():
            z = add_tuple(z1, z2)
            out[z] = (out.get(z, 0) + c1 * c2) % P
    return out


def delta_quartics(f_terms: list[Term], g_terms: list[Term]) -> list[dict[tuple[int, int, int, int], int]]:
    # F=x0 A0 + x1 A1.  G=x0 B0 + x1 B1, where each B_i is quadratic in y.
    a_forms = [{}, {}]
    b_forms = [[{}, {}, {}], [{}, {}, {}]]
    y_mons = monomials(2, 2)
    y_index = {m: i for i, m in enumerate(y_mons)}
    for term in f_terms:
        xi = 0 if term.x == (0, 1) else 1
        a_forms[xi][term.z] = (a_forms[xi].get(term.z, 0) + term.coeff) % P
    for term in g_terms:
        xi = 0 if term.x == (0, 1) else 1
        yi = y_index[term.y]
        b_forms[xi][yi][term.z] = (b_forms[xi][yi].get(term.z, 0) + term.coeff) % P

    result = []
    for yi in range(3):
        a0b1 = multiply_z_forms(a_forms[0], b_forms[1][yi])
        a1b0 = multiply_z_forms(a_forms[1], b_forms[0][yi])
        coeffs = a0b1.copy()
        for z, coeff in a1b0.items():
            coeffs[z] = (coeffs.get(z, 0) - coeff) % P
        result.append(coeffs)
    return result


def delta_sparse(b: int, c: int, quartics: list[dict[tuple[int, int, int, int], int]]) -> SparseMap:
    source_z = w_basis(c - 4)
    target_z = w_basis(c)
    source = [(slot, z) for slot in range(b + 1) for z in source_z]
    target = [(slot, z) for slot in range(b - 1) for z in target_z]
    target_index = {basis: i for i, basis in enumerate(target)}
    cols: list[dict[int, int]] = []
    for slot, z_src in source:
        col: dict[int, int] = {}
        for offset, quartic in enumerate(quartics):
            target_slot = slot - offset
            if target_slot < 0 or target_slot >= b - 1:
                continue
            for zq, coeff in quartic.items():
                z_tgt = add_tuple(z_src, zq)
                i = target_index.get((target_slot, z_tgt))
                if i is not None:
                    col[i] = (col.get(i, 0) + coeff) % P
        cols.append({i: v for i, v in col.items() if v})
    return SparseMap(len(target), len(source), cols)


def cell77(b: int, c: int, quartics: list[dict[tuple[int, int, int, int], int]]) -> dict:
    d = delta_sparse(b, c, quartics)
    r = rank_auto(d)
    source_dim = (b + 1) * len(w_basis(c - 4))
    target_dim = (b - 1) * len(w_basis(c))
    return {
        "cell": 77,
        "params": {"b": b, "c": c},
        "dims": [source_dim, target_dim],
        "ranks": [r],
        "h": [source_dim - r, target_dim - r, 0, 0],
    }


def dual_record(record: dict, cell: int) -> dict:
    h = record["h"]
    params = record["params"].copy()
    if cell == 171 and "m" in params:
        params["t"] = params.pop("m")
    return {
        "cell": cell,
        "params": params,
        "dual_of": record["cell"],
        "h": [h[3], h[2], h[1], h[0]],
    }


def compute_box(
    box: int,
    seed: int,
    cells: set[int],
    check_composition: bool = False,
    amin: int = 2,
    amax: int | None = None,
    bmin: int = 2,
    bmax: int | None = None,
    cmin: int = 4,
    cmax: int | None = None,
) -> list[dict]:
    if amax is None:
        amax = box
    if bmax is None:
        bmax = box
    if cmax is None:
        cmax = box
    f_terms, g_terms = build_fg(seed)
    quartics = delta_quartics(f_terms, g_terms)
    rows: list[dict] = []
    for a in range(amin, amax + 1):
        for b in range(bmin, bmax + 1):
            for m in (1, 2):
                if 5 in cells or 171 in cells:
                    r5 = cell5(a, b, m, g_terms)
                    if 5 in cells:
                        rows.append(r5)
                    if 171 in cells:
                        rows.append(dual_record(r5, 171))
            if 6 in cells or 170 in cells:
                r6 = cell6(a, b, f_terms, g_terms)
                if 6 in cells:
                    rows.append(r6)
                if 170 in cells:
                    rows.append(dual_record(r6, 170))
            for c in range(cmin, cmax + 1):
                if 7 in cells or 169 in cells:
                    r7 = cell7(a, b, c, f_terms, g_terms, check_composition)
                    if 7 in cells:
                        rows.append(r7)
                    if 169 in cells:
                        rows.append(dual_record(r7, 169))
    for b in range(bmin, bmax + 1):
        for c in range(cmin, cmax + 1):
            if 77 in cells or 99 in cells:
                r77 = cell77(b, c, quartics)
                if 77 in cells:
                    rows.append(r77)
                if 99 in cells:
                    rows.append(dual_record(r77, 99))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--box", type=int, default=10)
    parser.add_argument("--seed", type=int, default=7707)
    parser.add_argument("--cells", default="5,6,7,77,99,169,170,171")
    parser.add_argument("--check-composition", action="store_true")
    parser.add_argument("--amin", type=int, default=2)
    parser.add_argument("--amax", type=int)
    parser.add_argument("--bmin", type=int, default=2)
    parser.add_argument("--bmax", type=int)
    parser.add_argument("--cmin", type=int, default=4)
    parser.add_argument("--cmax", type=int)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--out")
    args = parser.parse_args()

    cells = {int(part) for part in args.cells.split(",") if part.strip()}
    rows = compute_box(
        args.box,
        args.seed,
        cells,
        args.check_composition,
        args.amin,
        args.amax,
        args.bmin,
        args.bmax,
        args.cmin,
        args.cmax,
    )
    bad_complexes = [r for r in rows if r.get("composition_nonzero_columns", 0) != 0]
    if args.json:
        payload = {"prime": P, "seed": args.seed, "box": args.box, "cells": sorted(cells), "rows": rows}
        text = json.dumps(payload, indent=2)
        if args.out:
            with open(args.out, "w", encoding="utf-8") as f:
                f.write(text)
                f.write("\n")
        else:
            print(text)
        return
    print(f"prime={P} seed={args.seed} box={args.box} records={len(rows)}")
    print(f"nonzero_composition_checks={len(bad_complexes)}")
    by_cell: dict[int, int] = {}
    nonzero: dict[int, int] = {}
    for row in rows:
        cell = row["cell"]
        by_cell[cell] = by_cell.get(cell, 0) + 1
        if any(row["h"]):
            nonzero[cell] = nonzero.get(cell, 0) + 1
    for cell in sorted(by_cell):
        print(f"cell {cell}: records={by_cell[cell]} nonzero_h={nonzero.get(cell, 0)}")
    print("sample rows:")
    for row in rows[:12]:
        print(row)


if __name__ == "__main__":
    main()
