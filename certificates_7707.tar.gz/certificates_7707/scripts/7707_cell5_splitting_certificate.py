#!/usr/bin/env python3
"""Splitting certificate for the analytic proof of CICY 7707 Cell 5.

The certificate uses the same deterministic integer specialization as
7707_unresolved_box10_rank.py, reduced modulo P=1000003.  A rank condition
holding modulo P gives a nonzero integer minor, hence a nonempty characteristic
zero open condition for the same rank condition.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib
import sys
from itertools import combinations

import sympy as sp


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"

spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)

P = rank7707.P


def z_index(z: tuple[int, int, int, int]) -> int:
    one = [i for i, e in enumerate(z) if e == 1]
    if len(one) != 1 or sum(z) != 1:
        raise ValueError(f"not a z-linear monomial: {z}")
    return one[0]


def poly_trim(poly: sp.Poly) -> sp.Poly:
    return sp.Poly(poly.as_expr(), poly.gens[0], modulus=P)


def gcd_is_one(polys: list[sp.Poly]) -> bool:
    nonzero = [p for p in polys if not p.is_zero]
    if not nonzero:
        return False
    g = nonzero[0]
    for p in nonzero[1:]:
        g = sp.gcd(g, p)
    return g.degree() == 0


def coeff_at(poly: sp.Poly, degree: int) -> int:
    return int(poly.nth(degree)) % P


def fiber_rank_conditions(g_terms: list[rank7707.Term]) -> dict[str, object]:
    """Check that the fiber maps have constant maximal rank.

    Along p_y, the four sections become four linear forms in x whose
    coefficients are quadrics in y.  Along p_x, they become four quadrics in y
    whose coefficients are linear forms in x.
    """

    t = sp.symbols("t")

    # p_y: 2 x 4 matrix of degree-2 polynomials in y.
    x_basis = rank7707.monomials(2, 1)
    py = [[sp.Poly(0, t, modulus=P) for _ in range(4)] for _ in range(2)]
    for term in g_terms:
        col = z_index(term.z)
        row = x_basis.index(term.x)
        exp = term.y[0]
        py[row][col] += sp.Poly(term.coeff * t**exp, t, modulus=P)
        py[row][col] = poly_trim(py[row][col])

    py_minors: list[sp.Poly] = []
    for c0, c1 in combinations(range(4), 2):
        det = py[0][c0] * py[1][c1] - py[0][c1] * py[1][c0]
        py_minors.append(poly_trim(det))
    py_no_finite_common_root = gcd_is_one(py_minors)
    py_no_infinity_common_root = any(coeff_at(m, 4) for m in py_minors)

    # p_x: 3 x 4 matrix of degree-1 polynomials in x.
    y_basis = rank7707.monomials(2, 2)
    px = [[sp.Poly(0, t, modulus=P) for _ in range(4)] for _ in range(3)]
    for term in g_terms:
        col = z_index(term.z)
        row = y_basis.index(term.y)
        exp = term.x[0]
        px[row][col] += sp.Poly(term.coeff * t**exp, t, modulus=P)
        px[row][col] = poly_trim(px[row][col])

    px_minors: list[sp.Poly] = []
    for cols in combinations(range(4), 3):
        mat = sp.Matrix([[px[r][c].as_expr() for c in cols] for r in range(3)])
        px_minors.append(poly_trim(sp.Poly(mat.det(), t, modulus=P)))
    px_no_finite_common_root = gcd_is_one(px_minors)
    px_no_infinity_common_root = any(coeff_at(m, 3) for m in px_minors)

    return {
        "py_rank_two_for_every_y": bool(py_no_finite_common_root and py_no_infinity_common_root),
        "py_2x2_minors_dehom_gcd_one": bool(py_no_finite_common_root),
        "py_no_common_root_at_infinity": bool(py_no_infinity_common_root),
        "px_rank_three_for_every_x": bool(px_no_finite_common_root and px_no_infinity_common_root),
        "px_3x3_minors_dehom_gcd_one": bool(px_no_finite_common_root),
        "px_no_common_root_at_infinity": bool(px_no_infinity_common_root),
    }


def contraction_record(m: int, xdeg: int, ydeg: int, label: str) -> dict[str, object]:
    _, g_terms = rank7707.build_fg(7707)
    source = rank7707.tensor_basis(m, xdeg, ydeg)
    target = rank7707.tensor_basis(m - 1, xdeg + 1, ydeg + 2)
    mat = rank7707.contraction_sparse(source, target, g_terms)
    rank = rank7707.rank_auto(mat)
    return {
        "label": label,
        "m": m,
        "twist_D": [xdeg, ydeg],
        "source_dim": len(source),
        "target_dim": len(target),
        "rank_mod_p": int(rank),
        "kernel_dim_mod_p": len(source) - int(rank),
        "coker_dim_mod_p": len(target) - int(rank),
    }


def main() -> None:
    _, g_terms = rank7707.build_fg(7707)
    records = [
        # m=1 checks for p_y*M ~= O(-2)^2 and p_x*M ~= O(-3).
        contraction_record(1, 0, 1, "m1_py_M_H0_twist_1"),
        contraction_record(1, 0, 2, "m1_py_M_H0_twist_2"),
        contraction_record(1, 2, 0, "m1_px_M_H0_twist_2"),
        contraction_record(1, 3, 0, "m1_px_M_H0_twist_3"),
        # m=2 checks for p_y*F ~= O(-4)^3.
        contraction_record(2, 0, 3, "m2_py_F_H0_twist_3"),
        contraction_record(2, 0, 4, "m2_py_F_H0_twist_4"),
        # m=2 checks for p_x*F ~= O(-6).
        contraction_record(2, 5, 0, "m2_px_F_H0_twist_5"),
        contraction_record(2, 6, 0, "m2_px_F_H0_twist_6"),
        # m=2 checks for p_x*(F(0,1)) ~= O(-4)^4.
        contraction_record(2, 3, 1, "m2_px_F01_H0_twist_3"),
        contraction_record(2, 4, 1, "m2_px_F01_H0_twist_4"),
        # The first bulk point a=3,b=4.  Since the fixed-x-degree coker is a
        # quotient generated in y-degree 0, vanishing in target y-degree 4
        # propagates to all b>=4; twisting on P1_x then gives all a>=3.
        contraction_record(2, 1, 2, "m2_bulk_first_vanishing_D_1_2"),
    ]

    payload = {
        "certificate": "CICY 7707 Cell 5 direct-image splitting certificate",
        "prime": P,
        "seed": 7707,
        "meaning": (
            "The listed ranks are computed modulo P. Full-rank/injectivity "
            "conditions modulo P give nonzero integer minors and hence "
            "nonempty characteristic-zero open conditions."
        ),
        "fiber_rank_conditions": fiber_rank_conditions(g_terms),
        "rank_records": records,
        "splitting_conclusions": {
            "p_y_star_M": "O_y(-2)^2",
            "p_x_star_M": "O_x(-3)",
            "p_y_star_Sym2M": "O_y(-4)^3",
            "R1_p_y_star_Sym2M": "O_y(4)",
            "p_x_star_Sym2M": "O_x(-6)",
            "R1_p_x_star_Sym2M": "O_x(2)^3",
            "p_x_star_Sym2M_0_1": "O_x(-4)^4",
            "R1_p_x_star_Sym2M_0_1": "0",
        },
    }

    json_path = ROOT / "7707_cell5_splitting_certificate.json"
    md_path = ROOT / "7707_cell5_splitting_certificate.md"
    json_path.write_text(json.dumps(payload, indent=2) + "\n")

    lines = [
        "# CICY 7707 Cell 5 direct-image splitting certificate",
        "",
        f"- prime: `{P}`",
        "- seed: `7707`",
        "",
        "A modular full-rank minor proves the corresponding rank condition on a",
        "nonempty characteristic-zero open set.",
        "",
        "## Fiber rank conditions",
        "",
    ]
    for key, value in payload["fiber_rank_conditions"].items():
        lines.append(f"- `{key}`: `{value}`")
    lines.extend([
        "",
        "## Global-section rank checks",
        "",
        "| label | m | D=(x,y) | source | target | rank | ker | coker |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for rec in records:
        lines.append(
            "| {label} | {m} | {D} | {source_dim} | {target_dim} | "
            "{rank_mod_p} | {kernel_dim_mod_p} | {coker_dim_mod_p} |".format(
                label=rec["label"],
                m=rec["m"],
                D=tuple(rec["twist_D"]),
                source_dim=rec["source_dim"],
                target_dim=rec["target_dim"],
                rank_mod_p=rec["rank_mod_p"],
                kernel_dim_mod_p=rec["kernel_dim_mod_p"],
                coker_dim_mod_p=rec["coker_dim_mod_p"],
            )
        )
    lines.extend([
        "",
        "## Splitting conclusions",
        "",
    ])
    for key, value in payload["splitting_conclusions"].items():
        lines.append(f"- `{key}`: `{value}`")
    md_path.write_text("\n".join(lines) + "\n")
    print(f"wrote {json_path.name} and {md_path.name}")


if __name__ == "__main__":
    main()
