#!/usr/bin/env python3
"""One-variable Hilbert-series certificates for CICY 7707 Cell 6 strips.

For fixed a, Cell 6 is a graded coker module over F_p[y0,y1].  For fixed b,
it is a graded coker module over F_p[x0,x1].  This script builds those
presentations from the same seed-7707 specialization used by the rank
verifiers, asks Singular for the Hilbert numerator of each coker, and compares
it with the numerator predicted by the direct-image splitting analysis.
"""

from __future__ import annotations

import importlib.util
import json
import pathlib
import re
import subprocess
import sys
from dataclasses import dataclass


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"
SINGULAR = "/opt/homebrew/bin/Singular"

spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)

P = rank7707.P


TensorBasis = list[tuple[tuple[int, int, int, int], tuple[int, int], tuple[int, int]]]


def compact_numerator(values: list[int]) -> dict[str, object]:
    """Return the compact numerator of sum values[n] t^n over (1-t)^2."""

    coeffs: list[int] = []
    for i, value in enumerate(values):
        prev1 = values[i - 1] if i >= 1 else 0
        prev2 = values[i - 2] if i >= 2 else 0
        coeffs.append(value - 2 * prev1 + prev2)
    while coeffs and coeffs[-1] == 0:
        coeffs.pop()
    shift = 0
    while coeffs and coeffs[0] == 0:
        coeffs.pop(0)
        shift += 1
    if not coeffs:
        return {"coeffs": [], "shift": 0}
    return {"coeffs": coeffs, "shift": shift}


def sequence_from_compact(numerator: dict[str, object], max_degree: int) -> list[int]:
    coeffs = list(numerator["coeffs"])
    shift = int(numerator["shift"])
    expanded = [0] * (max_degree + 1)
    for i, coeff in enumerate(coeffs):
        degree = shift + i
        if degree <= max_degree:
            expanded[degree] = int(coeff)
    values: list[int] = []
    for degree in range(max_degree + 1):
        values.append(
            sum(expanded[i] * (degree - i + 1) for i in range(degree + 1))
        )
    return values


def h0_p1(n: int) -> int:
    return max(n + 1, 0)


def h1_p1(n: int) -> int:
    return max(-n - 1, 0)


def balanced_split(rank: int, degree: int) -> list[int]:
    low = degree // rank
    high_count = degree - low * rank
    return [low + 1] * high_count + [low] * (rank - high_count)


def vertical_splitting(a: int) -> dict[str, list[int]]:
    if a == 2:
        return {"E": [-12, -12], "R1": [4, 4, 4, 4]}
    if a == 3:
        return {"E": [-6, -6] + [-7] * 6, "R1": [6]}
    rank = 9 * a - 20
    degree = -20 * a
    return {"E": balanced_split(rank, degree), "R1": []}


def horizontal_splitting(b: int) -> dict[str, list[int]]:
    if b == 2:
        return {"E": [], "R1": [3] * 9 + [2] * 2}
    if b == 3:
        return {"E": [-15, -15], "R1": [3] * 4}
    if b >= 8:
        return {"E": [-1] * (8 * b - 62) + [-2] * 28 + [-3] * (b + 5), "R1": []}
    rank = 9 * b - 29
    degree = -(11 * b + 9)
    return {"E": balanced_split(rank, degree), "R1": []}


def q_from_splitting(split: dict[str, list[int]], twist: int) -> int:
    return sum(h1_p1(d + twist) for d in split["E"]) + sum(
        h0_p1(d + twist) for d in split["R1"]
    )


def predicted_vertical_numerator(a: int, max_degree: int = 80) -> dict[str, object]:
    split = vertical_splitting(a)
    values = [q_from_splitting(split, b - 2) for b in range(max_degree + 1)]
    return compact_numerator(values)


def predicted_horizontal_numerator(b: int, max_degree: int = 80) -> dict[str, object]:
    split = horizontal_splitting(b)
    values = [q_from_splitting(split, a - 2) for a in range(max_degree + 1)]
    return compact_numerator(values)


def q6_formula(a: int, b: int) -> int:
    if a == 2 and b >= 14:
        return 4 * b + 12
    if a == 3 and b >= 8:
        return b + 5
    if b == 3 and a >= 17:
        return 4 * a + 8
    d = 20 * (a - 1) * (b - 1) - a * (11 * b + 9)
    return max(-d, 0)


def expected_chamber_numerator(
    label: str, actual: dict[str, object], max_degree: int = 80
) -> dict[str, object]:
    """Use actual low non-chamber degrees and the claimed formula for degree >=2."""

    values = sequence_from_compact(actual, max_degree)
    if label.startswith("vertical_a"):
        a = int(label[-2:])
        for b in range(2, max_degree + 1):
            values[b] = q6_formula(a, b)
    elif label.startswith("horizontal_b"):
        b = int(label[-2:])
        for a in range(2, max_degree + 1):
            values[a] = q6_formula(a, b)
    else:
        raise ValueError(label)
    return compact_numerator(values)


def monomial(var0: str, var1: str, exps: tuple[int, int], coeff: int) -> str:
    coeff %= P
    if coeff == 0:
        return "0"
    pieces: list[str] = []
    if exps[0]:
        pieces.append(var0 if exps[0] == 1 else f"{var0}^{exps[0]}")
    if exps[1]:
        pieces.append(var1 if exps[1] == 1 else f"{var1}^{exps[1]}")
    if not pieces:
        return str(coeff)
    return f"{coeff}*" + "*".join(pieces)


def add_poly_terms(terms: list[str]) -> str:
    nonzero = [t for t in terms if t != "0"]
    return "+".join(nonzero) if nonzero else "0"


def vertical_presentation(a: int, f_terms: list, g_terms: list) -> tuple[list[str], list[int]]:
    """Return Singular column vectors and target component weights for fixed a."""

    source = [(z, x) for z in rank7707.w_basis(3) for x in rank7707.monomials(2, a - 2)]
    f_rows = [(x,) for x in rank7707.monomials(2, a - 1)]
    g_rows = [
        (z, x)
        for z in rank7707.w_basis(2)
        for x in rank7707.monomials(2, a - 1)
    ]
    row_index: dict[tuple, int] = {}
    for row in f_rows:
        row_index[("f",) + row] = len(row_index)
    for row in g_rows:
        row_index[("g",) + row] = len(row_index)

    cols: list[list[list[str]]] = [[[] for _ in row_index] for _ in source]
    for col_idx, (z_src, x_src) in enumerate(source):
        for term in f_terms:
            z_tgt = rank7707.sub_tuple(z_src, term.z)
            if z_tgt == (0, 0, 0, 0):
                x_tgt = rank7707.add_tuple(x_src, term.x)
                i = row_index.get(("f", x_tgt))
                if i is not None:
                    cols[col_idx][i].append(monomial("y0", "y1", (0, 0), term.coeff))
        for term in g_terms:
            z_tgt = rank7707.sub_tuple(z_src, term.z)
            if z_tgt is not None:
                x_tgt = rank7707.add_tuple(x_src, term.x)
                i = row_index.get(("g", z_tgt, x_tgt))
                if i is not None:
                    cols[col_idx][i].append(monomial("y0", "y1", term.y, term.coeff))

    vectors = ["[" + ",".join(add_poly_terms(e) for e in col) + "]" for col in cols]
    weights = [2] * len(f_rows) + [0] * len(g_rows)
    return vectors, weights


def horizontal_presentation(b: int, f_terms: list, g_terms: list) -> tuple[list[str], list[int]]:
    """Return Singular column vectors and target component weights for fixed b."""

    source = [(z, y) for z in rank7707.w_basis(3) for y in rank7707.monomials(2, b - 2)]
    f_rows = [(y,) for y in rank7707.monomials(2, b - 2)]
    g_rows = [
        (z, y)
        for z in rank7707.w_basis(2)
        for y in rank7707.monomials(2, b)
    ]
    row_index: dict[tuple, int] = {}
    for row in f_rows:
        row_index[("f",) + row] = len(row_index)
    for row in g_rows:
        row_index[("g",) + row] = len(row_index)

    cols: list[list[list[str]]] = [[[] for _ in row_index] for _ in source]
    for col_idx, (z_src, y_src) in enumerate(source):
        for term in f_terms:
            z_tgt = rank7707.sub_tuple(z_src, term.z)
            if z_tgt == (0, 0, 0, 0):
                y_tgt = rank7707.add_tuple(y_src, term.y)
                i = row_index.get(("f", y_tgt))
                if i is not None:
                    cols[col_idx][i].append(monomial("x0", "x1", term.x, term.coeff))
        for term in g_terms:
            z_tgt = rank7707.sub_tuple(z_src, term.z)
            if z_tgt is not None:
                y_tgt = rank7707.add_tuple(y_src, term.y)
                i = row_index.get(("g", z_tgt, y_tgt))
                if i is not None:
                    cols[col_idx][i].append(monomial("x0", "x1", term.x, term.coeff))

    vectors = ["[" + ",".join(add_poly_terms(e) for e in col) + "]" for col in cols]
    weights = [1] * (len(f_rows) + len(g_rows))
    return vectors, weights


@dataclass
class Task:
    label: str
    variables: tuple[str, str]
    vectors: list[str]
    weights: list[int]
    predicted: dict[str, object]
    splitting: dict[str, list[int]]


def singular_script(tasks: list[Task]) -> str:
    chunks = [
        'LIB "sheafcoh.lib";',
        "option(redSB);",
    ]
    for task in tasks:
        var0, var1 = task.variables
        chunks.extend(
            [
                f'ring r_{task.label}=1000003,({var0},{var1}),dp;',
                f"module M_{task.label}=" + ",\n".join(task.vectors) + ";",
                f"intvec w_{task.label}=" + ",".join(str(w) for w in task.weights) + ";",
                f'attrib(M_{task.label},"isHomog",w_{task.label});',
                f"module S_{task.label}=std(M_{task.label});",
                f'attrib(S_{task.label},"isHomog",w_{task.label});',
                f'print("BEGIN {task.label}");',
                f'print("HILB1 " + string(hilb(S_{task.label},1)));',
                f'print("REG " + string(CM_regularity(S_{task.label})));',
                f'print("END {task.label}");',
            ]
        )
    chunks.append("quit;")
    return "\n".join(chunks) + "\n"


def parse_hilb(raw: str) -> dict[str, dict[str, object]]:
    out: dict[str, dict[str, object]] = {}
    current: str | None = None
    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("BEGIN "):
            current = line.split()[1]
            out[current] = {}
        elif line.startswith("END "):
            current = None
        elif current and line.startswith("HILB1 "):
            nums = [int(x) for x in re.findall(r"-?\d+", line[len("HILB1 ") :])]
            if nums:
                out[current]["actual"] = {"coeffs": nums[:-1], "shift": nums[-1]}
            else:
                out[current]["actual"] = {"coeffs": [], "shift": 0}
        elif current and line.startswith("REG "):
            nums = re.findall(r"-?\d+", line)
            out[current]["regularity"] = int(nums[0]) if nums else None
    return out


def main() -> None:
    f_terms, g_terms = rank7707.build_fg(7707)
    tasks: list[Task] = []
    for a in range(2, 11):
        vectors, weights = vertical_presentation(a, f_terms, g_terms)
        tasks.append(
            Task(
                label=f"vertical_a{a:02d}",
                variables=("y0", "y1"),
                vectors=vectors,
                weights=weights,
                predicted=predicted_vertical_numerator(a),
                splitting=vertical_splitting(a),
            )
        )
    for b in range(2, 11):
        vectors, weights = horizontal_presentation(b, f_terms, g_terms)
        tasks.append(
            Task(
                label=f"horizontal_b{b:02d}",
                variables=("x0", "x1"),
                vectors=vectors,
                weights=weights,
                predicted=predicted_horizontal_numerator(b),
                splitting=horizontal_splitting(b),
            )
        )

    sing_path = ROOT / "7707_cell6_strip_certificate.sing"
    sing_path.write_text(singular_script(tasks))
    result = subprocess.run(
        [SINGULAR, "-q", str(sing_path)],
        check=True,
        text=True,
        capture_output=True,
    )
    (ROOT / "7707_cell6_strip_certificate.singular.out").write_text(result.stdout)
    parsed = parse_hilb(result.stdout)

    rows = []
    for task in tasks:
        actual = parsed[task.label]["actual"]
        predicted = task.predicted
        chamber_expected = expected_chamber_numerator(task.label, actual)
        actual_values = sequence_from_compact(actual, 30)
        rows.append(
            {
                "label": task.label,
                "actual": actual,
                "splitting_full_series_prediction": predicted,
                "full_series_match": actual == predicted,
                "chamber_expected": chamber_expected,
                "chamber_match": actual == chamber_expected,
                "chamber_start_degree": 2,
                "first_chamber_values": actual_values[2:12],
                "regularity": parsed[task.label].get("regularity"),
                "target_components": len(task.weights),
                "source_generators": len(task.vectors),
                "weights": {
                    "min": min(task.weights),
                    "max": max(task.weights),
                    "counts": {str(w): task.weights.count(w) for w in sorted(set(task.weights))},
                },
                "splitting": task.splitting,
            }
        )

    payload = {
        "certificate": "CICY 7707 Cell 6 finite-width infinite-strip Hilbert certificate",
        "seed": 7707,
        "prime": P,
        "singular": SINGULAR,
        "scope": {
            "vertical": "fixed a=2..10, all b>=2",
            "horizontal": "fixed b=2..10, all a>=2",
        },
        "meaning": (
            "For each fixed strip, Singular computes the Hilbert numerator of "
            "the one-variable coker module over GF(p). The theorem only uses "
            "degrees >=2 in the free variable. Agreement with the chamber "
            "numerator proves the strip formula over this good specialization, "
            "hence nonempty characteristic-zero open rank conditions for the "
            "same finite presentation."
        ),
        "all_full_series_match": all(row["full_series_match"] for row in rows),
        "all_chamber_match": all(row["chamber_match"] for row in rows),
        "rows": rows,
    }
    json_path = ROOT / "7707_cell6_strip_certificate.json"
    json_path.write_text(json.dumps(payload, indent=2) + "\n")

    md_lines = [
        "# CICY 7707 Cell 6 finite-width strip certificate",
        "",
        f"- seed: `{payload['seed']}`",
        f"- prime: `{payload['prime']}`",
        f"- all chamber Hilbert numerators match for degree >= 2: `{payload['all_chamber_match']}`",
        f"- full graded-module match including non-chamber degrees 0 and 1: `{payload['all_full_series_match']}`",
        "",
        "The theorem only uses chamber degrees >= 2.  The full graded module",
        "contains lower-degree pieces outside the Bott chamber convention, so",
        "the full-series flag is recorded only as a diagnostic.",
        "",
        "| strip | target | source | weights | regularity | chamber | shift | coeffs |",
        "|---|---:|---:|---|---:|---|---:|---|",
    ]
    for row in rows:
        md_lines.append(
            "| {label} | {target_components} | {source_generators} | {weights} | "
            "{regularity} | {chamber_match} | {shift} | `{coeffs}` |".format(
                label=row["label"],
                target_components=row["target_components"],
                source_generators=row["source_generators"],
                weights=row["weights"]["counts"],
                regularity=row["regularity"],
                chamber_match=row["chamber_match"],
                shift=row["actual"]["shift"],
                coeffs=row["actual"]["coeffs"],
            )
        )
    md_lines.extend(
        [
            "",
            "The JSON file records the predicted splitting type for each strip.",
            "The generated Singular file is `7707_cell6_strip_certificate.sing`.",
        ]
    )
    (ROOT / "7707_cell6_strip_certificate.md").write_text("\n".join(md_lines) + "\n")
    print(f"all_chamber_match={payload['all_chamber_match']}")
    print(f"wrote {json_path.name} and 7707_cell6_strip_certificate.md")


if __name__ == "__main__":
    main()
