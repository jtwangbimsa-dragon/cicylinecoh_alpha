#!/usr/bin/env python3
"""CICY 7707 Cells 77/99, finite-b and arbitrary-c certificate.

Cell 77 is the two-term moving-resultant row

    Phi_b,c : R_{c-4}^{b+1} -> R_c^{b-1},  2 <= b <= 10, c >= 4,

where R=F_p[z0,z1,z2,z3] and the three quartics are the x-resultant
coefficients of the seed-7707 determinant-special model.  This script checks
the Hilbert numerators of coker(Phi_b) by Singular and then runs direct finite
degree rank checks for the 99 sample points 2<=b<=10, 4<=c<=14.
"""

from __future__ import annotations

import importlib.util
import json
import math
import pathlib
import re
import subprocess
import sys
import tempfile


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"
OUT_JSON = ROOT / "7707_cell77_99_c_arbitrary_certificate.json"
OUT_MD = ROOT / "7707_cell77_99_c_arbitrary_certificate.md"

spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)


P = rank7707.P
ZVARS = ["z0", "z1", "z2", "z3"]


EXPECTED_NUMERATORS: dict[int, dict[int, int]] = {
    2: {0: 1, 4: -3, 6: 1, 8: 3, 9: -2},
    3: {0: 2, 4: -4, 10: 2, 12: 4, 13: -4},
    4: {0: 3, 4: -5, 12: 1, 14: 3, 15: -2, 16: 5, 17: -6, 18: 1},
    5: {0: 4, 4: -6, 16: 2, 18: 4, 19: -4, 20: 6, 21: -8, 22: 2},
    6: {0: 5, 4: -7, 18: 1, 20: 3, 21: -2, 22: 5, 23: -6, 24: 8, 25: -10, 26: 3},
    7: {0: 6, 4: -8, 22: 2, 24: 4, 25: -4, 26: 6, 27: -8, 28: 10, 29: -12, 30: 4},
    8: {0: 7, 4: -9, 24: 1, 26: 3, 27: -2, 28: 5, 29: -6, 30: 8, 31: -10, 32: 12, 33: -14, 34: 5},
    9: {0: 8, 4: -10, 28: 2, 30: 4, 31: -4, 32: 6, 33: -8, 34: 10, 35: -12, 36: 14, 37: -16, 38: 6},
    10: {0: 9, 4: -11, 30: 1, 32: 3, 33: -2, 34: 5, 35: -6, 36: 8, 37: -10, 38: 12, 39: -14, 40: 16, 41: -18, 42: 7},
}


def p3(n: int) -> int:
    return math.comb(n + 3, 3) if n >= 0 else 0


def hf(numerator: dict[int, int], degree: int) -> int:
    return sum(coeff * p3(degree - shift) for shift, coeff in numerator.items())


def residual_tail(numerator: dict[int, int], b: int) -> dict[int, int]:
    out = dict(numerator)
    out[0] = out.get(0, 0) - (b - 1)
    out[4] = out.get(4, 0) + (b + 1)
    return {degree: coeff for degree, coeff in sorted(out.items()) if coeff}


def add_shifted(left: dict[int, int], right: dict[int, int], shift: int = 0) -> dict[int, int]:
    out = dict(left)
    for degree, coeff in right.items():
        out[degree + shift] = out.get(degree + shift, 0) + coeff
        if out[degree + shift] == 0:
            del out[degree + shift]
    return dict(sorted(out.items()))


def quotient_tail(b: int) -> dict[int, int]:
    return {4 * b: b + 1, 4 * b + 1: -(2 * b - 2), 4 * b + 2: b - 3}


def poly_from_z_form(form: dict[tuple[int, int, int, int], int]) -> str:
    pieces: list[str] = []
    for exp, coeff in sorted(form.items()):
        coeff %= P
        if not coeff:
            continue
        mon_parts = []
        for var, power in zip(ZVARS, exp):
            if power == 1:
                mon_parts.append(var)
            elif power > 1:
                mon_parts.append(f"{var}^{power}")
        monomial = "*".join(mon_parts) if mon_parts else "1"
        pieces.append(f"{coeff}*{monomial}")
    return "+".join(pieces) if pieces else "0"


def module_col(entries: list[str]) -> str:
    return "[" + ",".join(entries) + "]"


def singular_script(quartics: list[dict[tuple[int, int, int, int], int]]) -> str:
    q = [poly_from_z_form(form) for form in quartics]
    lines = [
        f"ring r={P},(z0,z1,z2,z3),dp;",
        "option(redSB);",
    ]
    for b in range(2, 11):
        cols = []
        for col in range(b + 1):
            entries = []
            for row in range(b - 1):
                offset = col - row
                entries.append(q[offset] if 0 <= offset <= 2 else "0")
            cols.append(module_col(entries))
        lines.extend(
            [
                "module M" + str(b) + "=" + ",".join(cols) + ";",
                "module G" + str(b) + "=std(M" + str(b) + ");",
                f'print("HILB_B_{b}");',
                "hilb(G" + str(b) + ");",
            ]
        )
    lines.append("quit;")
    return "\n".join(lines)


def run_singular(script: str) -> str:
    with tempfile.NamedTemporaryFile("w", suffix=".sing", delete=False) as handle:
        handle.write(script)
        path = pathlib.Path(handle.name)
    try:
        proc = subprocess.run(
            ["/opt/homebrew/bin/Singular", "-q", str(path)],
            text=True,
            capture_output=True,
            timeout=360,
            check=False,
        )
    finally:
        path.unlink(missing_ok=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-4000:] + "\n" + proc.stdout[-4000:])
    return proc.stdout


def parse_numerator(expr: str) -> dict[int, int]:
    expr = expr.replace("\n", "").replace(" ", "")
    match = re.search(r"\((.*?)\)/\(1-t\)\^4", expr)
    if not match:
        raise ValueError(expr)
    body = match.group(1)
    if body and body[0] not in "+-":
        body = "+" + body
    terms: dict[int, int] = {}
    for sign, raw in re.findall(r"([+-])([^+-]+)", body):
        if "t" in raw:
            coeff_part, degree_part = raw.split("t", 1)
            coeff = int(coeff_part) if coeff_part else 1
            degree = int(degree_part) if degree_part else 1
        else:
            coeff = int(raw)
            degree = 0
        if sign == "-":
            coeff *= -1
        terms[degree] = terms.get(degree, 0) + coeff
    return {degree: coeff for degree, coeff in sorted(terms.items()) if coeff}


def parse_singular_output(stdout: str) -> dict[int, dict[int, int]]:
    out: dict[int, dict[int, int]] = {}
    for b in range(2, 11):
        marker = f"HILB_B_{b}"
        tail = stdout.split(marker, 1)[1]
        line = next(line for line in tail.splitlines() if "/ (1-t)^4" in line)
        out[b] = parse_numerator(line)
    return out


def check_recurrence() -> list[dict]:
    rows = []
    tails = {b: residual_tail(num, b) for b, num in EXPECTED_NUMERATORS.items()}
    for b in range(4, 11):
        predicted = add_shifted({}, tails[b - 2], shift=6)
        predicted = add_shifted(predicted, quotient_tail(b), shift=0)
        rows.append(
            {
                "b": b,
                "expected_tail": tails[b],
                "recurrence_tail": predicted,
                "match": tails[b] == predicted,
            }
        )
    return rows


def direct_rank_checks(quartics: list[dict[tuple[int, int, int, int], int]]) -> list[dict]:
    rows = []
    for b in range(2, 11):
        numerator = EXPECTED_NUMERATORS[b]
        for c in range(4, 15):
            mat = rank7707.delta_sparse(b, c, quartics)
            rank = rank7707.rank_auto(mat)
            source_dim = (b + 1) * p3(c - 4)
            target_dim = (b - 1) * p3(c)
            predicted_gamma = hf(numerator, c)
            predicted_kappa = predicted_gamma + source_dim - target_dim
            rows.append(
                {
                    "b": b,
                    "c": c,
                    "rank": rank,
                    "source_dim": source_dim,
                    "target_dim": target_dim,
                    "actual_kappa": source_dim - rank,
                    "actual_gamma": target_dim - rank,
                    "predicted_kappa": predicted_kappa,
                    "predicted_gamma": predicted_gamma,
                    "match": (source_dim - rank == predicted_kappa)
                    and (target_dim - rank == predicted_gamma),
                }
            )
    return rows


def poly_to_tex(num: dict[int, int]) -> str:
    parts = []
    for degree, coeff in sorted(num.items()):
        sign = "+" if coeff > 0 else "-"
        abs_coeff = abs(coeff)
        if degree == 0:
            body = str(abs_coeff)
        else:
            coeff_text = "" if abs_coeff == 1 else str(abs_coeff)
            body = coeff_text + "t" + (f"^{{{degree}}}" if degree != 1 else "")
        parts.append((sign, body))
    if not parts:
        return "0"
    first_sign, first_body = parts[0]
    text = ("-" if first_sign == "-" else "") + first_body
    for sign, body in parts[1:]:
        text += f" {sign} {body}"
    return text


def write_markdown(payload: dict) -> None:
    lines = [
        "# CICY 7707 Cells 77/99 arbitrary-c certificate",
        "",
        f"- prime: `{payload['prime']}`",
        f"- seed: `{payload['seed']}`",
        f"- Singular numerator checks: `{payload['singular_all_match']}`",
        f"- recurrence checks for residual tails b=4..10: `{payload['recurrence_all_match']}`",
        f"- direct rank checks: `{payload['direct_rank_match_count']}` matches, `{payload['direct_rank_mismatch_count']}` mismatches",
        "",
        "For Cell 77, set",
        r"\[\gamma_b(c)=[t^c]\frac{N_b(t)}{(1-t)^4},\qquad",
        r"\kappa_b(c)=\gamma_b(c)+(b+1)P_3(c-4)-(b-1)P_3(c).\]",
        "Then",
        r"\[h^\bullet(0,-b,c)=(\kappa_b(c),\gamma_b(c),0,0),\]",
        "and Cell 99 is the Serre dual",
        r"\[h^\bullet(0,b,-c)=(0,0,\gamma_b(c),\kappa_b(c)).\]",
        "",
        "| b | N_b(t) |",
        "|---:|---|",
    ]
    for b in range(2, 11):
        lines.append(f"| {b} | `${poly_to_tex(EXPECTED_NUMERATORS[b])}` |")
    lines.extend(
        [
            "",
            "The residual tails satisfy",
            r"\[R_b=t^6R_{b-2}+t^{4b}\bigl((b+1)-(2b-2)t+(b-3)t^2\bigr),\quad b=4,\ldots,10.\]",
        ]
    )
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    f_terms, g_terms = rank7707.build_fg(7707)
    quartics = rank7707.delta_quartics(f_terms, g_terms)

    singular_nums = parse_singular_output(run_singular(singular_script(quartics)))
    singular_checks = [
        {"b": b, "computed": singular_nums[b], "expected": EXPECTED_NUMERATORS[b], "match": singular_nums[b] == EXPECTED_NUMERATORS[b]}
        for b in range(2, 11)
    ]
    recurrence_checks = check_recurrence()
    rank_checks = direct_rank_checks(quartics)
    mismatches = [row for row in rank_checks if not row["match"]]

    payload = {
        "prime": P,
        "seed": 7707,
        "cell_77": "k=(0,-b,c), 2<=b<=10, c>=4",
        "cell_99": "Serre dual k=(0,b,-c)",
        "singular_checks": singular_checks,
        "singular_all_match": all(row["match"] for row in singular_checks),
        "recurrence_checks": recurrence_checks,
        "recurrence_all_match": all(row["match"] for row in recurrence_checks),
        "direct_rank_checks": rank_checks,
        "direct_rank_match_count": len(rank_checks) - len(mismatches),
        "direct_rank_mismatch_count": len(mismatches),
        "direct_rank_mismatches": mismatches,
        "hilbert_numerators": EXPECTED_NUMERATORS,
    }
    OUT_JSON.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_markdown(payload)
    print(json.dumps({k: payload[k] for k in ["singular_all_match", "recurrence_all_match", "direct_rank_match_count", "direct_rank_mismatch_count"]}, indent=2))


if __name__ == "__main__":
    main()
