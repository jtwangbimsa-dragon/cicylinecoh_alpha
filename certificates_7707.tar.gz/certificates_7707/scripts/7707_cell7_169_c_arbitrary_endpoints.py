#!/usr/bin/env python3
"""CICY 7707 Cells 7/169, fixed 2<=a,b<=10 and arbitrary c.

The Cell 7 Serre-dual row is

    0 -> W_c U_{a-2,b-2}
      -> W_{c-3} U_{a-1,b-2} + W_{c-1} U_{a-1,b}
      -> W_{c-4} U_{a,b} -> 0.

For Cell 7 the endpoint dimensions are

    h2 = ker(left map),
    h0 = coker(right map).

This script packages both endpoints as Hilbert numerators in the z-degree c.
The h2 numerator is computed as the ordinary coker Hilbert numerator of the
transpose of the left map.  The h0 endpoint is the Cell 77 moving-resultant
residual tail, shifted by the cubic x-degree 3a.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import pathlib
import re
import subprocess
import sys
import tempfile
import time


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"
OUT_JSON = ROOT / "7707_cell7_169_c_arbitrary_endpoints.json"
OUT_MD = ROOT / "7707_cell7_169_c_arbitrary_endpoints.md"

spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)


P = rank7707.P
ZVARS = ["z0", "z1", "z2", "z3"]


CELL77_NUMERATORS: dict[int, dict[int, int]] = {
    2: {0: 1, 4: -3, 6: 1, 8: 3, 9: -2},
    3: {0: 2, 4: -4, 10: 2, 12: 4, 13: -4},
    4: {0: 3, 4: -5, 12: 1, 14: 3, 15: -2, 16: 5, 17: -6, 18: 1},
    5: {0: 4, 4: -6, 16: 2, 18: 4, 19: -4, 20: 6, 21: -8, 22: 2},
    6: {0: 5, 4: -7, 18: 1, 20: 3, 21: -2, 22: 5, 23: -6, 24: 8, 25: -10, 26: 3},
    7: {0: 6, 4: -8, 22: 2, 24: 4, 25: -4, 26: 6, 27: -8, 28: 10, 29: -12, 30: 4},
    8: {0: 7, 4: -9, 24: 1, 26: 3, 27: -2, 28: 5, 29: -6, 30: 8, 31: -10, 32: 12, 33: -14, 34: 5},
    9: {0: 8, 4: -10, 28: 2, 30: 4, 31: -4, 32: 6, 33: -8, 34: 10, 35: -12, 36: 14, 37: -16, 38: 6},
    10: {0: 9, 4: -11, 30: 1, 32: 3, 33: -2, 34: 5, 35: -6, 36: 8, 37: -10, 38: 12, 39: -14, 40: 16, 41: -18, 42: 7},
}


def p3(n: int) -> int:
    return math.comb(n + 3, 3) if n >= 0 else 0


def poly_from_term(term) -> str:
    pieces = []
    for var, power in zip(ZVARS, term.z):
        if power == 1:
            pieces.append(var)
        elif power > 1:
            pieces.append(f"{var}^{power}")
    monomial = "*".join(pieces) if pieces else "1"
    return f"{term.coeff}*{monomial}"


def module_col(entries: dict[int, str], rank: int) -> str:
    values = []
    for row in range(rank):
        value = entries.get(row, "0")
        if value.startswith("+"):
            value = value[1:]
        values.append(value)
    return "[" + ",".join(values) + "]"


def run_singular(script: str, timeout: int = 180) -> str:
    with tempfile.NamedTemporaryFile("w", suffix=".sing", delete=False) as handle:
        handle.write(script)
        path = pathlib.Path(handle.name)
    try:
        proc = subprocess.run(
            ["/opt/homebrew/bin/Singular", "-q", str(path)],
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    finally:
        path.unlink(missing_ok=True)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr[-2000:] + "\n" + proc.stdout[-2000:])
    return proc.stdout


def parse_first_hilbert_numerator(stdout: str, marker: str = "HILB_BEGIN") -> dict[int, int]:
    tail = stdout.split(marker, 1)[1] if marker in stdout else stdout
    match = re.search(r"\((.*?)\)\s*/\s*\(1-t\)\^4", tail, re.S)
    if not match:
        raise ValueError(stdout[-2000:])
    expr = match.group(1).replace("\n", "").replace(" ", "")
    if expr and expr[0] not in "+-":
        expr = "+" + expr
    terms: dict[int, int] = {}
    for sign, body in re.findall(r"([+-])([^+-]+)", expr):
        if "t" in body:
            coeff_part, degree_part = body.split("t", 1)
            coeff = int(coeff_part) if coeff_part else 1
            degree = int(degree_part) if degree_part else 1
        else:
            coeff = int(body)
            degree = 0
        if sign == "-":
            coeff = -coeff
        terms[degree] = terms.get(degree, 0) + coeff
    return {degree: coeff for degree, coeff in sorted(terms.items()) if coeff}


def hf(numerator: dict[int, int], degree: int) -> int:
    return sum(coeff * p3(degree - shift) for shift, coeff in numerator.items())


def add_num(left: dict[int, int], right: dict[int, int], scale: int = 1, shift: int = 0) -> dict[int, int]:
    out = dict(left)
    for degree, coeff in right.items():
        out[degree + shift] = out.get(degree + shift, 0) + scale * coeff
        if out[degree + shift] == 0:
            del out[degree + shift]
    return dict(sorted(out.items()))


def q2_singular_script(a: int, b: int, f_terms: list, g_terms: list) -> str:
    rows = rank7707.u_basis(a - 2, b - 2)
    row_index = {xy: i for i, xy in enumerate(rows)}
    cols = []

    for terms, xdeg, ydeg in [
        (f_terms, a - 1, b - 2),
        (g_terms, a - 1, b),
    ]:
        for x_src, y_src in rank7707.u_basis(xdeg, ydeg):
            entries: dict[int, str] = {}
            for term in terms:
                x_row = rank7707.sub_tuple(x_src, term.x)
                y_row = rank7707.sub_tuple(y_src, term.y)
                if x_row is None or y_row is None:
                    continue
                row = row_index.get((x_row, y_row))
                if row is not None:
                    entries[row] = entries.get(row, "0") + f"+({poly_from_term(term)})"
            cols.append(module_col(entries, len(rows)))

    return "\n".join(
        [
            f"ring r={P},(z0,z1,z2,z3),dp;",
            "option(redSB);",
            "module M=" + ",".join(cols) + ";",
            "module G=std(M);",
            'print("HILB_BEGIN");',
            "hilb(G);",
            "quit;",
        ]
    )


def d1_transpose_numeric_matrix(a: int, b: int, f_terms: list, g_terms: list, zpoint: tuple[int, int, int, int]):
    mid_f = [("mf", xy) for xy in rank7707.u_basis(a - 1, b - 2)]
    mid_g = [("mg", xy) for xy in rank7707.u_basis(a - 1, b)]
    rows = mid_f + mid_g
    row_index = {row: i for i, row in enumerate(rows)}
    right = rank7707.u_basis(a, b)
    matrix = [[0 for _ in right] for _ in rows]

    def eval_term(term) -> int:
        value = term.coeff % P
        for z, power in zip(zpoint, term.z):
            value = (value * pow(z % P, power, P)) % P
        return value

    for col, (x_right, y_right) in enumerate(right):
        for term in g_terms:
            x_mid = rank7707.sub_tuple(x_right, term.x)
            y_mid = rank7707.sub_tuple(y_right, term.y)
            if x_mid is None or y_mid is None:
                continue
            row = row_index.get(("mf", (x_mid, y_mid)))
            if row is not None:
                matrix[row][col] = (matrix[row][col] + eval_term(term)) % P
        for term in f_terms:
            x_mid = rank7707.sub_tuple(x_right, term.x)
            y_mid = rank7707.sub_tuple(y_right, term.y)
            if x_mid is None or y_mid is None:
                continue
            row = row_index.get(("mg", (x_mid, y_mid)))
            if row is not None:
                matrix[row][col] = (matrix[row][col] + eval_term(term)) % P
    return matrix


def rank_mod_p(matrix: list[list[int]]) -> int:
    if not matrix:
        return 0
    a = [row[:] for row in matrix]
    nrows = len(a)
    ncols = len(a[0])
    rank = 0
    for col in range(ncols):
        pivot = None
        for row in range(rank, nrows):
            if a[row][col] % P:
                pivot = row
                break
        if pivot is None:
            continue
        if pivot != rank:
            a[rank], a[pivot] = a[pivot], a[rank]
        inv = pow(a[rank][col] % P, P - 2, P)
        a[rank] = [(x * inv) % P for x in a[rank]]
        for row in range(nrows):
            if row == rank:
                continue
            factor = a[row][col] % P
            if factor:
                a[row] = [(x - factor * y) % P for x, y in zip(a[row], a[rank])]
        rank += 1
        if rank == nrows:
            break
    return rank


def q0_exceptional_numerator(f_terms: list, g_terms: list) -> dict[int, int]:
    a = b = 2
    mid_f = [("mf", xy) for xy in rank7707.u_basis(a - 1, b - 2)]
    mid_g = [("mg", xy) for xy in rank7707.u_basis(a - 1, b)]
    rows = mid_f + mid_g
    row_index = {row: i for i, row in enumerate(rows)}
    cols = []
    for x_right, y_right in rank7707.u_basis(a, b):
        entries: dict[int, str] = {}
        for term in g_terms:
            x_mid = rank7707.sub_tuple(x_right, term.x)
            y_mid = rank7707.sub_tuple(y_right, term.y)
            if x_mid is None or y_mid is None:
                continue
            row = row_index.get(("mf", (x_mid, y_mid)))
            if row is not None:
                entries[row] = entries.get(row, "0") + f"+({poly_from_term(term)})"
        for term in f_terms:
            x_mid = rank7707.sub_tuple(x_right, term.x)
            y_mid = rank7707.sub_tuple(y_right, term.y)
            if x_mid is None or y_mid is None:
                continue
            row = row_index.get(("mg", (x_mid, y_mid)))
            if row is not None:
                entries[row] = entries.get(row, "0") + f"+({poly_from_term(term)})"
        cols.append(module_col(entries, len(rows)))
    weights = ",".join(["3"] * len(mid_f) + ["1"] * len(mid_g))
    script = "\n".join(
        [
            f"ring r={P},(z0,z1,z2,z3),dp;",
            "option(redSB);",
            "module M=" + ",".join(cols) + ";",
            f'attrib(M,"isHomog",intvec({weights}));',
            "module K=syz(M);",
            "module G=std(K);",
            'print("HILB_BEGIN");',
            "hilb(G);",
            "quit;",
        ]
    )
    quotient_num = parse_first_hilbert_numerator(run_singular(script, timeout=60))
    source_rank = len(rank7707.u_basis(a, b))
    kernel_num_in_n = add_num({0: source_rank}, quotient_num, scale=-1)
    # n is c-4, so shift the numerator into the c variable.
    return {degree + 4: coeff for degree, coeff in kernel_num_in_n.items()}


def q0_numerator(a: int, b: int) -> dict[int, int]:
    """Right-endpoint coker numerator for Cell 7.

    The right endpoint reduces along the x-direction to the same
    moving-resultant residual module as Cell 77.  The low free terms
    `(b-1)-(b+1)t^4` cancel against the source-target Euler contribution, so
    only the residual tail of the Cell 77 numerator remains, shifted by `3a`.
    """
    tail = {degree: coeff for degree, coeff in CELL77_NUMERATORS[b].items() if degree > 4}
    return {degree + 3 * a: coeff for degree, coeff in tail.items()}


def euler_chi(a: int, b: int, c: int) -> int:
    return (
        (a - 1) * (b - 1) * p3(c)
        - a * (b - 1) * p3(c - 3)
        - a * (b + 1) * p3(c - 1)
        + (a + 1) * (b + 1) * p3(c - 4)
    )


def format_num(num: dict[int, int]) -> str:
    if not num:
        return "0"
    parts = []
    for degree, coeff in sorted(num.items()):
        sign = "+" if coeff > 0 else "-"
        mag = abs(coeff)
        if degree == 0:
            term = str(mag)
        elif degree == 1:
            term = ("" if mag == 1 else str(mag)) + "t"
        else:
            term = ("" if mag == 1 else str(mag)) + f"t^{degree}"
        parts.append((sign, term))
    first_sign, first_term = parts[0]
    text = ("" if first_sign == "+" else "-") + first_term
    for sign, term in parts[1:]:
        text += f" {sign} {term}"
    return text


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    started = time.time()
    f_terms, g_terms = rank7707.build_fg(7707)
    records = []
    box_bad = []
    for a in range(2, 11):
        for b in range(2, 11):
            t0 = time.time()
            q2_num = parse_first_hilbert_numerator(
                run_singular(q2_singular_script(a, b, f_terms, g_terms), timeout=args.timeout)
            )
            q0_num = q0_numerator(a, b)
            q0_cert = {
                "method": "t^(3a) times Cell 77 moving-resultant residual tail R_b(t)",
                "cell77_numerator": CELL77_NUMERATORS[b],
                "shift": 3 * a,
            }

            for c in range(4, 11):
                q0 = hf(q0_num, c)
                q2 = hf(q2_num, c)
                h1 = q0 + q2 - euler_chi(a, b, c)
                expected_e = -euler_chi(a, b, c)
                expected = [0, max(expected_e, 0), max(-expected_e, 0), 0]
                got = [q0, h1, q2, 0]
                if got != expected:
                    box_bad.append({"a": a, "b": b, "c": c, "got": got, "expected": expected})

            records.append(
                {
                    "a": a,
                    "b": b,
                    "q0_num": q0_num,
                    "q2_num": q2_num,
                    "q0_certificate": q0_cert,
                    "seconds": round(time.time() - t0, 3),
                }
            )
            print(f"a={a} b={b} q0={format_num(q0_num)} q2_terms={len(q2_num)} sec={records[-1]['seconds']}", flush=True)

    payload = {
        "cell": "7/169",
        "seed": 7707,
        "prime": P,
        "range": {"a": [2, 10], "b": [2, 10], "c": "arbitrary >=4"},
        "convention": "q0=h0 endpoint coker(d1); q2=h2 endpoint coker(transpose d0); h1=q0+q2-chi",
        "q0_formula": "N_q0(a,b;t)=t^(3a)*(N_77,b(t)-((b-1)-(b+1)t^4))",
        "records": records,
        "box10_mismatches": box_bad,
        "box10_verified": not box_bad,
        "seconds": round(time.time() - started, 3),
    }

    md_lines = [
        "# CICY 7707 Cells 7 and 169: c-arbitrary endpoint numerators",
        "",
        "For fixed `2 <= a,b <= 10` and arbitrary `c >= 4`, define",
        "",
        "\\[q_0(a,b,c)=h^0(X,\\mathcal O_X(-a,-b,c)),\\qquad q_2(a,b,c)=h^2(X,\\mathcal O_X(-a,-b,c)).\\]",
        "",
        "Both are computed first as endpoint coker Hilbert functions:",
        "",
        "- `q0` is the right endpoint `coker(d1)`.",
        "- `q2` is the left endpoint kernel, computed as the coker of the transpose of `d0`.",
        "",
        "Then",
        "",
        "\\[h^1=q_0+q_2-\\chi(-a,-b,c).\\]",
        "",
        "Cell 169 is obtained by Serre duality:",
        "",
        "\\[h^\\bullet(a,b,-c)=(0,q_2,q_0+q_2-\\chi,q_0).\\]",
        "",
        "- q0 formula: `N_q0(a,b;t)=t^(3a) R_b(t)`, where `R_b` is the Cell 77 residual tail.",
        f"- box-10 verification mismatches: `{len(box_bad)}`",
        f"- total seconds: `{payload['seconds']}`",
        "",
        "Here `P3(n)=binomial(n+3,3)` for `n>=0`, otherwise `0`, and",
        "`HF_N(c)=[t^c] N(t)/(1-t)^4`.",
        "",
        "## q0 endpoint",
        "",
        "Let `N_77,b(t)` be the Cell 77 coker numerator and write",
        "",
        "\\[N_{77,b}(t)=(b-1)-(b+1)t^4+R_b(t).\\]",
        "",
        "Then",
        "",
        "\\[N_{q0,a,b}(t)=t^{3a}R_b(t).\\]",
        "",
        "## q2 endpoint numerators",
        "",
        "| a | b | N_q2(t) |",
        "|---:|---:|---|",
    ]
    for rec in records:
        md_lines.append(f"| {rec['a']} | {rec['b']} | `{format_num(rec['q2_num'])}` |")

    if args.write:
        OUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        OUT_MD.write_text("\n".join(md_lines) + "\n", encoding="utf-8")
        print(OUT_JSON)
        print(OUT_MD)
    else:
        print(json.dumps(payload, indent=2))

    if box_bad:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
