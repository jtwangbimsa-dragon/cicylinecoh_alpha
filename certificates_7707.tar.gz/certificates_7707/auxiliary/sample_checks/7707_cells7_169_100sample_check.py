#!/usr/bin/env python3
"""100-sample formula-vs-matrix-rank checks for CICY 7707 Cells 7 and 169."""

from __future__ import annotations

import importlib.util
import json
import pathlib
import sys
import time


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"
ENDPOINT_PATH = ROOT / "7707_cell7_169_c_arbitrary_endpoints.py"
ENDPOINT_JSON = ROOT / "7707_cell7_169_c_arbitrary_endpoints.json"
OUT_JSON = ROOT / "7707_cells7_169_100sample_check.json"
OUT_MD = ROOT / "7707_cells7_169_100sample_check.md"


spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)

spec2 = importlib.util.spec_from_file_location("endpoints7707", ENDPOINT_PATH)
endpoints = importlib.util.module_from_spec(spec2)
sys.modules["endpoints7707"] = endpoints
assert spec2.loader is not None
spec2.loader.exec_module(endpoints)


def normalize_num(num: dict) -> dict[int, int]:
    return {int(degree): int(coeff) for degree, coeff in num.items() if int(coeff)}


def dual(h: list[int]) -> list[int]:
    return [h[3], h[2], h[1], h[0]]


def sample_params() -> list[tuple[int, int, int]]:
    params = [(a, b, 4) for a in range(2, 11) for b in range(2, 11)]
    tail = [
        (2, 2, 5),
        (2, 2, 6),
        (2, 2, 7),
        (2, 2, 8),
        (2, 2, 9),
        (2, 2, 10),
        (2, 2, 11),
        (2, 2, 12),
        (2, 2, 13),
        (2, 2, 14),
        (2, 3, 11),
        (3, 2, 11),
        (3, 3, 11),
        (2, 4, 11),
        (4, 2, 11),
        (2, 5, 11),
        (5, 2, 11),
        (3, 4, 11),
        (4, 3, 11),
    ]
    params.extend(tail)
    if len(params) != 100 or len(set(params)) != 100:
        raise AssertionError("sample list must contain 100 unique triples")
    return params


def endpoint_q2_nums() -> dict[tuple[int, int], dict[int, int]]:
    payload = json.loads(ENDPOINT_JSON.read_text(encoding="utf-8"))
    return {
        (int(rec["a"]), int(rec["b"])): normalize_num(rec["q2_num"])
        for rec in payload["records"]
    }


def formula_cell7(a: int, b: int, c: int, q2_nums: dict[tuple[int, int], dict[int, int]]) -> list[int]:
    q0 = endpoints.hf(endpoints.q0_numerator(a, b), c)
    q2 = endpoints.hf(q2_nums[(a, b)], c)
    h1 = q0 + q2 - endpoints.euler_chi(a, b, c)
    return [q0, h1, q2, 0]


def check() -> dict:
    f_terms, g_terms = rank7707.build_fg(7707)
    q2_nums = endpoint_q2_nums()
    rows = []
    rank_cache: dict[tuple[int, int, int], dict] = {}
    started = time.time()

    for index, (a, b, c) in enumerate(sample_params(), start=1):
        t0 = time.time()
        rank_record = rank7707.cell7(a, b, c, f_terms, g_terms)
        rank_record["seconds"] = round(time.time() - t0, 6)
        rank_cache[(a, b, c)] = rank_record

        formula_h = formula_cell7(a, b, c, q2_nums)
        rank_h = rank_record["h"]
        rows.append(
            {
                "sample": index,
                "cell": 7,
                "k": [-a, -b, c],
                "params": {"a": a, "b": b, "c": c},
                "formula_h": formula_h,
                "rank_h": rank_h,
                "match": formula_h == rank_h,
                "dims": rank_record["dims"],
                "ranks": rank_record["ranks"],
                "rank_seconds": rank_record["seconds"],
            }
        )
        print(
            f"{index:03d}/100 Cell7 a={a} b={b} c={c} "
            f"match={formula_h == rank_h} h={rank_h} sec={rank_record['seconds']:.3f}",
            flush=True,
        )

    for index, (a, b, c) in enumerate(sample_params(), start=1):
        rank_h = dual(rank_cache[(a, b, c)]["h"])
        formula_h = dual(formula_cell7(a, b, c, q2_nums))
        rows.append(
            {
                "sample": index,
                "cell": 169,
                "k": [a, b, -c],
                "params": {"a": a, "b": b, "c": c},
                "dual_of_sample": index,
                "formula_h": formula_h,
                "rank_h": rank_h,
                "match": formula_h == rank_h,
            }
        )

    by_cell = {}
    for cell in [7, 169]:
        cell_rows = [row for row in rows if row["cell"] == cell]
        by_cell[str(cell)] = {
            "samples": len(cell_rows),
            "matches": sum(row["match"] for row in cell_rows),
            "mismatches": sum(not row["match"] for row in cell_rows),
        }

    mismatches = [row for row in rows if not row["match"]]
    return {
        "seed": 7707,
        "prime": rank7707.P,
        "sampling": {
            "cell7": "100 triples: all 81 pairs 2<=a,b<=10 at c=4, plus 19 tail points up to c=14",
            "cell169": "the Serre-dual 100 line bundles (a,b,-c) using the same rank records",
        },
        "summary": by_cell,
        "all_match": not mismatches,
        "mismatches": mismatches,
        "rows": rows,
        "seconds": round(time.time() - started, 6),
    }


def write_md(payload: dict) -> None:
    lines = [
        "# CICY 7707 Cells 7/169: 100-sample formula-vs-rank check",
        "",
        f"- seed: `{payload['seed']}`",
        f"- prime: `{payload['prime']}`",
        f"- all match: `{payload['all_match']}`",
        f"- total seconds: `{payload['seconds']}`",
        "",
        "| cell | samples | matches | mismatches |",
        "|---:|---:|---:|---:|",
    ]
    for cell in ["7", "169"]:
        summary = payload["summary"][cell]
        lines.append(
            f"| {cell} | {summary['samples']} | {summary['matches']} | {summary['mismatches']} |"
        )
    lines.extend(
        [
            "",
            "The 100 Cell 7 samples cover all 81 pairs `2<=a,b<=10` at `c=4`,",
            "plus 19 tail samples with `c>4`, including `c=11..14`.",
            "Cell 169 uses the Serre-dual line bundles `(a,b,-c)` for the same",
            "100 triples.",
            "",
            "| sample | cell 7 k | formula h | rank h | match |",
            "|---:|---|---|---|---|",
        ]
    )
    for row in [r for r in payload["rows"] if r["cell"] == 7]:
        lines.append(
            f"| {row['sample']} | `{row['k']}` | `{row['formula_h']}` | "
            f"`{row['rank_h']}` | `{row['match']}` |"
        )
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    payload = check()
    OUT_JSON.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    write_md(payload)
    print(
        json.dumps(
            {
                "out_json": str(OUT_JSON),
                "out_md": str(OUT_MD),
                "summary": payload["summary"],
                "all_match": payload["all_match"],
                "mismatches": len(payload["mismatches"]),
                "seconds": payload["seconds"],
            },
            indent=2,
        )
    )
    if not payload["all_match"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
