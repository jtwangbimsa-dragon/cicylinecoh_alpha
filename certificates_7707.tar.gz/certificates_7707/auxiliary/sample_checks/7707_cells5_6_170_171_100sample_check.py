#!/usr/bin/env python3
"""Sample formula-vs-rank checks for CICY 7707 Cells 5, 6, 170, 171."""

from __future__ import annotations

import importlib.util
import json
import pathlib
import random
import sys
import time


ROOT = pathlib.Path(__file__).resolve().parent
RANK_PATH = ROOT / "7707_unresolved_box10_rank.py"

spec = importlib.util.spec_from_file_location("rank7707", RANK_PATH)
rank7707 = importlib.util.module_from_spec(spec)
sys.modules["rank7707"] = rank7707
assert spec.loader is not None
spec.loader.exec_module(rank7707)


def pos(n: int) -> int:
    return max(n, 0)


def h_cell5_formula(a: int, b: int, m: int) -> list[int]:
    if m == 1:
        d = 3 * a * b - 5 * a - 4 * b + 4
        return [0, pos(-d), pos(d), 0]

    if a == 2 and b <= 5:
        return [0, 18 - 2 * b, 0, 0]
    if a == 2 and b >= 6:
        return [0, b + 3, 3 * b - 15, 0]
    if b == 2 and a >= 3:
        return [0, 2 * a + 10 + pos(a - 7), pos(a - 7), 0]

    d = 6 * a * b - 14 * a - 10 * b + 10
    return [0, pos(-d), pos(d), 0]


def h_cell6_formula(a: int, b: int) -> list[int]:
    if a == 2 and b >= 14:
        return [0, 4 * b + 12, 2 * b - 26, 0]
    if a == 3 and b >= 8:
        return [0, b + 5, 8 * b - 62, 0]
    if b == 3 and a >= 17:
        return [0, 4 * a + 8, 2 * a - 32, 0]

    d = 20 * (a - 1) * (b - 1) - a * (11 * b + 9)
    return [0, pos(-d), pos(d), 0]


def dual(h: list[int]) -> list[int]:
    return [h[3], h[2], h[1], h[0]]


def h_rank_cell5(a: int, b: int, m: int, g_terms: list) -> list[int]:
    left = rank7707.tensor_basis(m, a - 2, b - 2)
    right = rank7707.tensor_basis(m - 1, a - 1, b)
    d = rank7707.contraction_sparse(left, right, g_terms)
    r = rank7707.rank_auto(d)
    return [0, len(right) - r, len(left) - r, 0]


def h_rank_cell6(a: int, b: int, f_terms: list, g_terms: list) -> list[int]:
    left = rank7707.tensor_basis(3, a - 2, b - 2)
    t_f = rank7707.tensor_basis(0, a - 1, b - 2)
    t_g = rank7707.tensor_basis(2, a - 1, b)
    d = rank7707.block_v([
        rank7707.contraction_sparse(left, t_f, f_terms),
        rank7707.contraction_sparse(left, t_g, g_terms),
    ])
    r = rank7707.rank_auto(d)
    return [0, len(t_f) + len(t_g) - r, len(left) - r, 0]


def sample_cell5_params() -> list[dict]:
    params: list[tuple[int, int, int]] = []
    # Boundary strips that caused the non-maximal-rank corrections.
    for b in range(2, 26):
        params.append((2, b, 2))
    for a in range(3, 26):
        params.append((a, 2, 2))
    # Include m=1 broadly and interior m=2 points.
    rng = random.Random(770705)
    seen = set(params)
    while len(params) < 100:
        a = rng.randint(2, 22)
        b = rng.randint(2, 22)
        m = rng.choice([1, 2])
        key = (a, b, m)
        if key not in seen:
            seen.add(key)
            params.append(key)
    return [{"a": a, "b": b, "m": m} for a, b, m in params[:100]]


def sample_cell6_params() -> list[dict]:
    params: list[tuple[int, int]] = []
    # Cover both exceptional strips: a=3,b>=8 and a=2,b>=14.
    for b in range(2, 31):
        params.append((2, b))
    for b in range(2, 31):
        params.append((3, b))
    for a in range(2, 31):
        params.append((a, 3))
    rng = random.Random(770706)
    seen = set(params)
    while len(params) < 100:
        a = rng.randint(2, 18)
        b = rng.randint(2, 18)
        key = (a, b)
        if key not in seen:
            seen.add(key)
            params.append(key)
    return [{"a": a, "b": b} for a, b in params[:100]]


def check() -> dict:
    f_terms, g_terms = rank7707.build_fg(7707)
    cell5_params = sample_cell5_params()
    cell6_params = sample_cell6_params()
    rows = []
    started = time.time()

    cell5_rank_cache: dict[tuple[int, int, int], list[int]] = {}
    cell6_rank_cache: dict[tuple[int, int], list[int]] = {}

    for params in cell5_params:
        a, b, m = params["a"], params["b"], params["m"]
        rank_h = h_rank_cell5(a, b, m, g_terms)
        cell5_rank_cache[(a, b, m)] = rank_h
        formula_h = h_cell5_formula(a, b, m)
        rows.append({
            "cell": 5,
            "k": [-a, -b, m],
            "params": params,
            "formula_h": formula_h,
            "rank_h": rank_h,
            "match": formula_h == rank_h,
        })

    for params in cell5_params:
        a, b, t = params["a"], params["b"], params["m"]
        rank_h = dual(cell5_rank_cache[(a, b, t)])
        formula_h = dual(h_cell5_formula(a, b, t))
        rows.append({
            "cell": 171,
            "k": [a, b, -t],
            "params": {"a": a, "b": b, "t": t},
            "formula_h": formula_h,
            "rank_h": rank_h,
            "match": formula_h == rank_h,
        })

    for params in cell6_params:
        a, b = params["a"], params["b"]
        rank_h = h_rank_cell6(a, b, f_terms, g_terms)
        cell6_rank_cache[(a, b)] = rank_h
        formula_h = h_cell6_formula(a, b)
        rows.append({
            "cell": 6,
            "k": [-a, -b, 3],
            "params": params,
            "formula_h": formula_h,
            "rank_h": rank_h,
            "match": formula_h == rank_h,
        })

    for params in cell6_params:
        a, b = params["a"], params["b"]
        rank_h = dual(cell6_rank_cache[(a, b)])
        formula_h = dual(h_cell6_formula(a, b))
        rows.append({
            "cell": 170,
            "k": [a, b, -3],
            "params": params,
            "formula_h": formula_h,
            "rank_h": rank_h,
            "match": formula_h == rank_h,
        })

    by_cell = {}
    for cell in [5, 171, 6, 170]:
        cell_rows = [row for row in rows if row["cell"] == cell]
        by_cell[str(cell)] = {
            "samples": len(cell_rows),
            "matches": sum(row["match"] for row in cell_rows),
            "mismatches": sum(not row["match"] for row in cell_rows),
        }

    return {
        "seed": 7707,
        "prime": rank7707.P,
        "sampling": {
            "cell5_and_171": "100 shared (a,b,m/t) points; includes a=2 and b=2 boundary strips, plus random points in 2..30",
            "cell6_and_170": "100 shared (a,b) points; includes a=2 and a=3 exceptional strips, plus random points in 2..30",
        },
        "summary": by_cell,
        "all_match": all(row["match"] for row in rows),
        "mismatches": [row for row in rows if not row["match"]],
        "rows": rows,
        "seconds": round(time.time() - started, 6),
    }


def main() -> None:
    out = ROOT / "7707_cells5_6_170_171_100sample_check.json"
    payload = check()
    out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "out": str(out),
        "summary": payload["summary"],
        "all_match": payload["all_match"],
        "mismatches": len(payload["mismatches"]),
        "seconds": payload["seconds"],
    }, indent=2))
    if not payload["all_match"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
