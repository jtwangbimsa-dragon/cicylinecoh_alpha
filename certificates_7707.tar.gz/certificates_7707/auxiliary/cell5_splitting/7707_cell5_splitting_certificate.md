# CICY 7707 Cell 5 direct-image splitting certificate

- prime: `1000003`
- seed: `7707`

A modular full-rank minor proves the corresponding rank condition on a
nonempty characteristic-zero open set.

## Fiber rank conditions

- `py_rank_two_for_every_y`: `True`
- `py_2x2_minors_dehom_gcd_one`: `True`
- `py_no_common_root_at_infinity`: `True`
- `px_rank_three_for_every_x`: `True`
- `px_3x3_minors_dehom_gcd_one`: `True`
- `px_no_common_root_at_infinity`: `True`

## Global-section rank checks

| label | m | D=(x,y) | source | target | rank | ker | coker |
|---|---:|---:|---:|---:|---:|---:|---:|
| m1_py_M_H0_twist_1 | 1 | (0, 1) | 8 | 8 | 8 | 0 | 0 |
| m1_py_M_H0_twist_2 | 1 | (0, 2) | 12 | 10 | 10 | 2 | 0 |
| m1_px_M_H0_twist_2 | 1 | (2, 0) | 12 | 12 | 12 | 0 | 0 |
| m1_px_M_H0_twist_3 | 1 | (3, 0) | 16 | 15 | 15 | 1 | 0 |
| m2_py_F_H0_twist_3 | 2 | (0, 3) | 40 | 48 | 40 | 0 | 8 |
| m2_py_F_H0_twist_4 | 2 | (0, 4) | 50 | 56 | 47 | 3 | 9 |
| m2_px_F_H0_twist_5 | 2 | (5, 0) | 60 | 84 | 60 | 0 | 24 |
| m2_px_F_H0_twist_6 | 2 | (6, 0) | 70 | 96 | 69 | 1 | 27 |
| m2_px_F01_H0_twist_3 | 2 | (3, 1) | 80 | 80 | 80 | 0 | 0 |
| m2_px_F01_H0_twist_4 | 2 | (4, 1) | 100 | 96 | 96 | 4 | 0 |
| m2_bulk_first_vanishing_D_1_2 | 2 | (1, 2) | 60 | 60 | 60 | 0 | 0 |

## Splitting conclusions

- `p_y_star_M`: `O_y(-2)^2`
- `p_x_star_M`: `O_x(-3)`
- `p_y_star_Sym2M`: `O_y(-4)^3`
- `R1_p_y_star_Sym2M`: `O_y(4)`
- `p_x_star_Sym2M`: `O_x(-6)`
- `R1_p_x_star_Sym2M`: `O_x(2)^3`
- `p_x_star_Sym2M_0_1`: `O_x(-4)^4`
- `R1_p_x_star_Sym2M_0_1`: `0`
