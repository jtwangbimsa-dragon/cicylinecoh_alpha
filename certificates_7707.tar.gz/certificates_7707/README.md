# CICY 7707 certificate package

This package collects the certificate files needed for the current CICY 7707
finite-width and finite-box formulae in `paper_version.tex`.

It is a CAS/Python/Singular certificate package, not a Lean verification
package.

## Contents

- `core/cell6_strip/`
  Certificates for the finite-width strip
  `k=(-a,-b,3)` with `2<=a<=10` or `2<=b<=10`, and the Serre-dual range.

- `core/cell77_99_arbitrary_c/`
  Certificates for the finite `b`-box
  `k=(0,-b,c)`, `2<=b<=10`, `c>=4`, and the Serre-dual range.

- `core/cell7_169_endpoints/`
  Certificates for the finite `(a,b)`-box
  `k=(-a,-b,c)`, `2<=a,b<=10`, `c>=4`, and the Serre-dual range.
  The subdirectory `7707_cell7_169_q2_singular_certs/` contains the raw
  Singular inputs and outputs for all 81 endpoint pairs.

- `auxiliary/cell5_splitting/`
  Splitting certificate for the analytic `m=1,2` range.  This is not a
  finite-box theorem, but it is included because it is part of the 7707 map
  package.

- `auxiliary/sample_checks/`
  Formula-vs-rank sample checks for cells `5/6/170/171` and `7/169`.

- `scripts/`
  Replay/generation scripts copied together with the shared rank helper
  `7707_unresolved_box10_rank.py`.  These scripts use exact finite-field
  arithmetic and Singular where indicated.

## Replay Commands

Run from this package directory:

```bash
python3 scripts/7707_cell5_splitting_certificate.py
python3 scripts/7707_cell6_strip_certificate.py
python3 scripts/7707_cell77_99_c_arbitrary_certificate.py
python3 scripts/7707_cell7_169_c_arbitrary_endpoints.py
python3 scripts/7707_cell7_169_q2_singular_certificates.py --write
python3 scripts/7707_cells5_6_170_171_100sample_check.py
python3 scripts/7707_cells7_169_100sample_check.py
```

The Singular-based scripts expect Singular at `/opt/homebrew/bin/Singular`,
matching the recorded ledgers.

## Status Summary

- Cell 6 finite-width strips: chamber Hilbert numerators match for all strips.
- Cells 77/99 finite `b`-box: Singular numerator checks, residual-tail
  recurrence checks, and 99 direct rank checks all pass.
- Cells 7/169 finite `(a,b)`-box: q0 comes from the cell 77 residual tail;
  q2 has 81 Singular endpoint numerators, all matching the endpoint ledger;
  100 rank samples for cell 7 and 100 Serre-dual samples for cell 169 all pass.
- Cell 5 analytic splitting: finite-field rank/minor certificate records the
  required splitting conditions for the `m=1,2` analytic range.

