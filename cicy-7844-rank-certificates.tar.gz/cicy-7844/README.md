# CICY 7844 rank certificates

This directory contains replayable finite-field pivot certificates for the
right endpoint cokernel used for CICY 7844,

\[
\left[
\begin{array}{c|cc}
\mathbb P^2&2&1\\
\mathbb P^3&2&2
\end{array}
\right].
\]

The certified map is the right endpoint map in the \(\mathbb P^2\)-top row,
after quotienting first by the \(G\)-block:

\[
C_1(b)/\operatorname{im}(C_2(b)\to C_1(b))
\longrightarrow
C_0(b).
\]

Equivalently, the certificate proves the rank of the induced \(F\)-block on

\[
C_0(b)/\operatorname{im}G.
\]

## Contents

- `right-endpoint/pivot-gf2/`: 104 JSON certificates, one for each
  \((r,b)\) with \(3\le r\le 15\) and \(0\le b\le B_r+1\).
- `right-endpoint/pivot-gf2/manifest.json`: summary of all certificates.
- `right-endpoint/verify_and_generate.py`: generator and verifier.

The values of \(B_r\) are

\[
\begin{array}{c|ccccccccccccc}
r&3&4&5&6&7&8&9&10&11&12&13&14&15\\
\hline
B_r&2&2&3&4&5&5&6&7&7&8&9&10&10 .
\end{array}
\]

Thus each row contains certificates for \(b=0,\ldots,B_r+1\), giving

\[
\sum_{r=3}^{15}(B_r+2)=104
\]

certificates.

## What A Certificate Stores

Each JSON file stores:

- the finite field, here \(\mathbb F_2\);
- the seeds determining the specialized \(G\)- and \(F\)-coefficients;
- the dimensions of \(C_0\), the \(G\)-block, the \(F\)-block, and \(C_2\);
- the stored pivot columns and pivot rows for the \(G\)-block;
- the stored pivot columns and pivot rows for the induced \(F\)-block;
- the resulting cokernel dimension and the expected cokernel dimension.

The verifier does not search for pivots.  It rebuilds only the columns listed
in the certificate and replays the recorded pivots.

All matrices are specialized over \(\mathbb Z\) and then reduced modulo \(2\).
A replayed pivot certificate gives a nonzero minor over \(\mathbb F_2\).  Hence
the same integer minor is nonzero, so the corresponding generic
characteristic-zero matrix has at least this rank.

## Verification

From a downloaded archive, unpack it and enter the package directory:

```bash
tar -xzf cicy-7844-rank-certificates.tar.gz
cd cicy-7844
shasum -a 256 -c checksums.sha256
```

Verify one certificate:

```bash
python3 right-endpoint/verify_and_generate.py \
  --verify right-endpoint/pivot-gf2/r15_b11.json
```

The expected output contains `"ok": true`.

Regenerate the full set:

```bash
python3 right-endpoint/verify_and_generate.py \
  --r-min 3 --r-max 15 \
  --out-dir right-endpoint/pivot-gf2
```

On the machine used to generate these files, the full generation took about
336 seconds.  The largest individual case was \(r=15,b=11\), taking about
95 seconds.  Verification of a stored certificate is faster than searching
for pivots, because the pivot columns are already recorded.

## Rank Logic

For each \((r,b)\), the certificate first proves

\[
\operatorname{rank}G=\dim(\text{\(G\)-source}),
\]

so

\[
\dim(C_0/\operatorname{im}G)=\dim C_0-\operatorname{rank}G.
\]

It then proves a lower bound for the induced \(F\)-rank by replaying the
stored \(F\)-pivots.  The matching upper bound is

\[
\min\left\{
\dim(C_0/\operatorname{im}G),
\dim F-\dim C_2+K_{r,2}(b)
\right\}.
\]

In the certified range here, \(b<6r\), so \(K_{r,2}(b)=0\).  Once the replayed
pivots reach this upper bound, the rank is exact, and the cokernel dimension is
certified.

The range is finite for the following reason.  At \(b=6r\), the Euler
characteristic corrected by the left kernel term is already negative:

\[
G_r(6r)-K_{r,2}(6r)<0.
\]

For all \(b\ge 6r+1\), the same corrected expression is constant and equal to

\[
G_r(b)-K_{r,2}(b)=-8r(3r^2-2)<0.
\]

Thus no positive right-endpoint cokernel can occur after the certified range;
the listed finite set of \((r,b)\) is enough.
