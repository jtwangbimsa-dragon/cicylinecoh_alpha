#!/usr/bin/env python3
r"""Replayable GF(2) pivot certificates for the CICY 7844 right endpoint.

This script uses a GF(2) specialization of the three quadratic coefficients of
the \(x\)-linear equation \(G\), and records pivot columns for the
quotient-first computation

    C1/im(C2) -> C0/im(G).

The output certificates are not rank ledgers: they store enough pivot data for
an independent verifier to replay the rank lower bound without searching for
pivots.  The matching upper bound is the source/target dimension bound.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import random
import time
from functools import lru_cache
from pathlib import Path


PRIME = 2


@dataclass(frozen=True)
class CertConfig:
    r: int
    b: int
    g_seed: int
    f_seed: int


@lru_cache(maxsize=None)
def monoms(nvars: int, deg: int) -> tuple[tuple[int, ...], ...]:
    if deg < 0:
        return ()
    if nvars == 1:
        return ((deg,),)
    out: list[tuple[int, ...]] = []
    for i in range(deg + 1):
        for tail in monoms(nvars - 1, deg - i):
            out.append((i,) + tail)
    return tuple(out)


def add_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...]:
    return tuple(x + y for x, y in zip(a, b))


def sub_exp(a: tuple[int, ...], b: tuple[int, ...]) -> tuple[int, ...] | None:
    out = tuple(x - y for x, y in zip(a, b))
    if any(x < 0 for x in out):
        return None
    return out


def leq_exp(a: tuple[int, ...], b: tuple[int, ...]) -> bool:
    return all(x <= y for x, y in zip(a, b))


def binom2(n: int) -> int:
    return n * (n - 1) // 2


def hilb_p(n: int) -> int:
    if n < 0:
        return 0
    return (n + 3) * (n + 2) * (n + 1) // 6


def kernel_k(r: int, b: int) -> int:
    if b < 6 * r:
        return 0
    n = b - 6 * r
    return binom2(r + 2) * hilb_p(n) - r * r * hilb_p(n - 2) + binom2(r - 1) * hilb_p(n - 4)


def g_expected(r: int, b: int) -> int:
    return binom2(r - 1) * hilb_p(b) - r * r * hilb_p(b - 2) + binom2(r + 2) * hilb_p(b - 4)


def expected_coker(r: int, b: int) -> int:
    return max(g_expected(r, b) - kernel_k(r, b), 0)


def b_r(r: int) -> int:
    hits = [b for b in range(0, 6 * r + 1) if g_expected(r, b) - kernel_k(r, b) > 0]
    return max(hits) if hits else -1


def dimensions(r: int, b: int) -> dict[str, int]:
    return {
        "C0_rows": binom2(r - 1) * hilb_p(b),
        "G_cols": binom2(r) * hilb_p(b - 2),
        "F_cols": binom2(r + 1) * hilb_p(b - 2),
        "C2_dim": binom2(r + 2) * hilb_p(b - 4),
    }


def row_index(r: int, b: int) -> dict[tuple[tuple[int, ...], tuple[int, ...]], int]:
    t0 = monoms(3, r - 3)
    sb = monoms(4, b)
    return {(tx, sy): i for i, (tx, sy) in enumerate((tx, sy) for tx in t0 for sy in sb)}


def gf2_g_coeffs(seed: int) -> list[dict[tuple[int, ...], int]]:
    rng = random.Random(seed)
    quads: list[dict[tuple[int, ...], int]] = []
    y2 = monoms(4, 2)
    for _ in range(3):
        q = {ym: 1 for ym in y2 if rng.randrange(2)}
        if not q:
            q[y2[rng.randrange(len(y2))]] = 1
        quads.append(q)
    return quads


def gf2_f_coeffs(seed: int) -> dict[tuple[int, ...], int]:
    rng = random.Random(seed)
    coeffs: dict[tuple[int, ...], int] = {}
    for xm in monoms(3, 2):
        for ym in monoms(4, 2):
            if rng.randrange(2):
                coeffs[xm + ym] = 1
    return coeffs


def lowbit_index(mask: int) -> int:
    return (mask & -mask).bit_length() - 1


def reduce_mask(mask: int, basis: list[int]) -> int | None:
    while mask:
        pivot = lowbit_index(mask)
        row = basis[pivot]
        if row == 0:
            basis[pivot] = mask
            return pivot
        mask ^= row
    return None


def g_column_mask(
    r: int,
    b: int,
    col_index: int,
    rows: dict[tuple[tuple[int, ...], tuple[int, ...]], int],
    g_coeffs: list[dict[tuple[int, ...], int]],
) -> int:
    tg = monoms(3, r - 2)
    sbm2 = monoms(4, b - 2)
    beta = tg[col_index // len(sbm2)]
    sy0 = sbm2[col_index % len(sbm2)]
    x1 = monoms(3, 1)
    mask = 0
    for i, ex in enumerate(x1):
        alpha = sub_exp(beta, ex)
        if alpha is None:
            continue
        for yterm in g_coeffs[i]:
            row = rows.get((alpha, add_exp(sy0, yterm)))
            if row is not None:
                mask ^= 1 << row
    return mask


def f_column_mask(
    r: int,
    b: int,
    col_index: int,
    rows: dict[tuple[tuple[int, ...], tuple[int, ...]], int],
    coeffs: dict[tuple[int, ...], int],
) -> int:
    tf = monoms(3, r - 1)
    sbm2 = monoms(4, b - 2)
    gamma = tf[col_index // len(sbm2)]
    sy0 = sbm2[col_index % len(sbm2)]
    mask = 0
    for x2 in monoms(3, 2):
        if not leq_exp(x2, gamma):
            continue
        alpha = sub_exp(gamma, x2)
        assert alpha is not None
        for y2 in monoms(4, 2):
            if not coeffs.get(x2 + y2, 0):
                continue
            row = rows.get((alpha, add_exp(sy0, y2)))
            if row is not None:
                mask ^= 1 << row
    return mask


def target_f_rank(r: int, b: int, dims: dict[str, int], rank_g: int) -> int:
    quotient_dim = dims["C0_rows"] - rank_g
    source_bound = dims["F_cols"] - dims["C2_dim"] + kernel_k(r, b)
    return min(quotient_dim, source_bound)


def make_certificate(config: CertConfig) -> dict[str, object]:
    start = time.time()
    dims = dimensions(config.r, config.b)
    rows = row_index(config.r, config.b)
    basis = [0] * dims["C0_rows"]

    g_pivots: list[dict[str, int]] = []
    g_coeffs = gf2_g_coeffs(config.g_seed)
    for col in range(dims["G_cols"]):
        pivot = reduce_mask(g_column_mask(config.r, config.b, col, rows, g_coeffs), basis)
        if pivot is not None:
            g_pivots.append({"col": col, "row": pivot})
    if len(g_pivots) != dims["G_cols"]:
        raise RuntimeError(f"G block was not injective for r={config.r}, b={config.b}")

    need = target_f_rank(config.r, config.b, dims, len(g_pivots))
    coeffs = gf2_f_coeffs(config.f_seed)
    f_pivots: list[dict[str, int]] = []
    scanned_f_cols = 0
    for col in range(dims["F_cols"]):
        scanned_f_cols += 1
        pivot = reduce_mask(f_column_mask(config.r, config.b, col, rows, coeffs), basis)
        if pivot is not None:
            f_pivots.append({"col": col, "row": pivot})
            if len(f_pivots) == need:
                break

    if len(f_pivots) != need:
        raise RuntimeError(
            f"seeds G={config.g_seed}, F={config.f_seed} found only {len(f_pivots)} F pivots, "
            f"need {need}, r={config.r}, b={config.b}"
        )

    quotient_dim = dims["C0_rows"] - len(g_pivots)
    coker = quotient_dim - len(f_pivots)
    return {
        "format": "cicy-7844-gf2-pivot-certificate-v1",
        "prime": PRIME,
        "specialization": {
            "G_seed": config.g_seed,
            "G_coefficients": "three deterministic GF(2) quadrics generated by Python random.Random(G_seed)",
            "F_seed": config.f_seed,
            "F_coefficients": "deterministic GF(2) coefficients generated by Python random.Random(seed)",
        },
        "r": config.r,
        "b": config.b,
        "dimensions": dims,
        "rank_bounds": {
            "rank_G": len(g_pivots),
            "quotient_dim": quotient_dim,
            "source_bound_after_C2": dims["F_cols"] - dims["C2_dim"] + kernel_k(config.r, config.b),
            "certified_F_rank": len(f_pivots),
            "certified_total_rank": len(g_pivots) + len(f_pivots),
            "certified_coker": coker,
            "expected_coker": expected_coker(config.r, config.b),
        },
        "search_stats": {
            "scanned_F_cols": scanned_f_cols,
            "elapsed_sec": round(time.time() - start, 4),
        },
        "pivots": {
            "G": g_pivots,
            "F": f_pivots,
        },
    }


def verify_certificate(cert: dict[str, object]) -> dict[str, object]:
    if cert.get("format") != "cicy-7844-gf2-pivot-certificate-v1":
        return {"ok": False, "reason": "unknown certificate format"}
    r = int(cert["r"])
    b = int(cert["b"])
    g_seed = int(cert["specialization"]["G_seed"])
    f_seed = int(cert["specialization"]["F_seed"])
    dims = dimensions(r, b)
    if dims != cert["dimensions"]:
        return {"ok": False, "reason": "dimension mismatch", "expected": dims, "actual": cert["dimensions"]}

    rows = row_index(r, b)
    basis = [0] * dims["C0_rows"]
    g_coeffs = gf2_g_coeffs(g_seed)
    for step, item in enumerate(cert["pivots"]["G"]):
        col = int(item["col"])
        expected_row = int(item["row"])
        pivot = reduce_mask(g_column_mask(r, b, col, rows, g_coeffs), basis)
        if pivot != expected_row:
            return {"ok": False, "block": "G", "step": step, "expected_row": expected_row, "actual_row": pivot}

    coeffs = gf2_f_coeffs(f_seed)
    for step, item in enumerate(cert["pivots"]["F"]):
        col = int(item["col"])
        expected_row = int(item["row"])
        pivot = reduce_mask(f_column_mask(r, b, col, rows, coeffs), basis)
        if pivot != expected_row:
            return {"ok": False, "block": "F", "step": step, "expected_row": expected_row, "actual_row": pivot}

    rb = cert["rank_bounds"]
    rank_g = len(cert["pivots"]["G"])
    rank_f = len(cert["pivots"]["F"])
    quotient_dim = dims["C0_rows"] - rank_g
    source_bound = dims["F_cols"] - dims["C2_dim"] + kernel_k(r, b)
    f_upper = min(quotient_dim, source_bound)
    coker = quotient_dim - rank_f
    checks = {
        "rank_G": rank_g == rb["rank_G"] == dims["G_cols"],
        "F_rank_hits_upper_bound": rank_f == rb["certified_F_rank"] == f_upper,
        "coker": coker == rb["certified_coker"] == expected_coker(r, b),
    }
    return {"ok": all(checks.values()), "checks": checks, "coker": coker, "rank_G": rank_g, "rank_F": rank_f}


def write_certificate(cert: dict[str, object], out_dir: Path) -> Path:
    r = int(cert["r"])
    b = int(cert["b"])
    path = out_dir / f"r{r:02d}_b{b:02d}.json"
    path.write_text(json.dumps(cert, indent=2, sort_keys=True), encoding="utf-8")
    return path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--r-min", type=int, default=3)
    parser.add_argument("--r-max", type=int, default=15)
    parser.add_argument("--b", type=int, default=None)
    parser.add_argument("--seed", type=int, default=7844)
    parser.add_argument("--max-seed-tries", type=int, default=200)
    parser.add_argument("--out-dir", type=Path, default=Path("rank_certificates/cicy-7844/right-endpoint/pivot-gf2"))
    parser.add_argument("--verify", type=Path, default=None)
    args = parser.parse_args()

    if args.verify is not None:
        cert = json.loads(args.verify.read_text(encoding="utf-8"))
        print(json.dumps(verify_certificate(cert), indent=2, sort_keys=True))
        return

    args.out_dir.mkdir(parents=True, exist_ok=True)
    manifest: list[dict[str, object]] = []
    for r in range(args.r_min, args.r_max + 1):
        b_values = [args.b] if args.b is not None else range(0, b_r(r) + 2)
        for b in b_values:
            base_seed = args.seed + 1000 * r + b
            last_error = None
            cert = None
            for attempt in range(args.max_seed_tries):
                g_seed = base_seed + 1_000_000 * attempt
                f_seed = base_seed + 2_000_000 * attempt + 123_457
                try:
                    cert = make_certificate(CertConfig(r=r, b=b, g_seed=g_seed, f_seed=f_seed))
                    break
                except RuntimeError as exc:
                    last_error = exc
            if cert is None:
                raise RuntimeError(f"no successful seed for r={r}, b={b}") from last_error
            result = verify_certificate(cert)
            if not result["ok"]:
                raise RuntimeError(f"self verification failed for r={r}, b={b}: {result}")
            path = write_certificate(cert, args.out_dir)
            rb = cert["rank_bounds"]
            stats = cert["search_stats"]
            row = {
                "r": r,
                "b": b,
                "file": path.name,
                "rank_G": rb["rank_G"],
                "rank_F": rb["certified_F_rank"],
                "coker": rb["certified_coker"],
                "expected_coker": rb["expected_coker"],
                "scanned_F_cols": stats["scanned_F_cols"],
                "elapsed_sec": stats["elapsed_sec"],
            }
            manifest.append(row)
            print(
                f"r={r:02d} b={b:02d} G={row['rank_G']} F={row['rank_F']} "
                f"coker={row['coker']} scannedF={row['scanned_F_cols']} "
                f"sec={row['elapsed_sec']} file={path.name}",
                flush=True,
            )

    manifest_path = args.out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    print(f"wrote {manifest_path}")


if __name__ == "__main__":
    main()
