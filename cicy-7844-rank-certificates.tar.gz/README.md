# CICY line cohomology certificates

This repository stores machine-checkable certificates for line-bundle
cohomology calculations, organized by CICY configuration.

## Available certificates

- `cicy-7844/`: replayable GF(2) pivot certificates for the right-endpoint
  cokernel of CICY 7844.
